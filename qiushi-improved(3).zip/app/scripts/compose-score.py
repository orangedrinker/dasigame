"""Render seven original, seamless chamber-score loops. No sampled recordings.
Requires Python + numpy and ffmpeg. Output: public/audio/score-*.mp3.
"""
from pathlib import Path
import numpy as np
import subprocess, wave, tempfile
SR = 32000
ROOT = Path(__file__).resolve().parents[1]
# BPM, tonic MIDI, melody (relative semitones; -99 = rest), chord roots, strings, percussion
SCORES = {
 'archive': (68, 60, [0,4,7,9,7,4,2,-99,0,4,7,12,9,7,4,2], [0,9,5,7], .20, .00),
 'wartime': (88, 57, [0,3,7,5,3,0,-2,-99,0,3,7,10,7,5,3,-2], [0,5,8,7], .33, .13),
 'sorrow': (60, 57, [7,3,0,-99,5,3,-2,-99,3,0,-2,-99,0,3,2,-99], [0,8,5,7], .27, .00),
 'lantern': (74, 62, [0,2,4,7,9,7,4,-99,2,4,7,12,9,7,4,2], [0,9,5,7], .26, .02),
 'rain': (80, 57, [0,3,5,7,5,3,0,-99,-2,0,3,5,3,0,-2,-99], [0,8,5,7], .36, .08),
 'alarm': (96, 57, [0,3,0,7,5,3,-2,-99,0,3,7,10,7,5,3,-2], [0,5,8,7], .37, .15),
 'modern': (84, 60, [0,4,7,12,9,7,4,2,4,7,9,12,14,12,7,4], [0,9,5,7], .24, .04),
}
def hz(m): return 440 * 2 ** ((m-69)/12)
def render(name, spec):
 bpm, root, melody, chords, strings, drum = spec
 beat = 60/bpm; duration = 32*beat; n = round(duration*SR)
 out = np.zeros((n,2), np.float64)
 def add(t, length, midi, amp, kind='piano', pan=0):
  count = round(length*SR); x = np.arange(count)/SR; freq=hz(midi)
  if kind=='piano':
   sig = sum((1/h**1.7)*np.sin(2*np.pi*freq*h*(1+.00015*h*h)*x)*np.exp(-x*(1.1+h*.35)) for h in range(1,7))
   env = np.minimum(x/.008,1)*np.minimum((length-x)/.18,1)
  else:
   sig = sum(np.sin(2*np.pi*freq*h*x + .015*np.sin(2*np.pi*4.5*x))/h**2.3 for h in range(1,7))
   env = np.minimum(x/.6,1)*np.minimum((length-x)/.9,1)
  sig *= np.maximum(0,env)*amp
  pos=(np.arange(count)+round(t*SR))%n
  out[pos,0] += sig*np.sqrt((1-pan)/2)
  out[pos,1] += sig*np.sqrt((1+pan)/2)
 minor=name in ('wartime','rain','sorrow','alarm')
 for bar in range(8):
  chord=chords[bar%4]; third=3 if minor else 4
  for k,interval in enumerate([0,third,7]): add(bar*4*beat,4.5*beat,root-12+chord+interval,strings*.28,'strings',(k-1)*.45)
  for k,interval in enumerate([0,7,12,7]): add((bar*4+k)*beat,2*beat,root-12+chord+interval,.12,'piano',-.3)
 for j,note in enumerate(melody):
  if note != -99: add(j*2*beat,2.8*beat,root+12+note,.24,'piano',.18)
 if drum:
  rng=np.random.default_rng(1937)
  for b in range(32):
   x=np.arange(int(.24*SR))/SR
   sig=(np.sin(2*np.pi*(48*x+10*(1-np.exp(-x*20))))*.8+rng.normal(0,.05,len(x)))*np.exp(-x*22)*drum
   pos=(np.arange(len(x))+round(b*beat*SR))%n
   out[pos,:] += sig[:,None]*(1 if b%4==0 else .38)
 dry=out.copy()
 for seconds,g in [(.11,.16),(.23,.12),(.37,.09),(.53,.06),(.79,.04)]: out += np.roll(dry,round(seconds*SR),axis=0)[:,::-1]*g
 out *= .78/max(.9,np.max(np.abs(out)))
 pcm=np.int16(np.clip(out,-1,1)*32767)
 path=ROOT/'public'/'audio'/f'score-{name}.mp3'
 with tempfile.TemporaryDirectory(dir=ROOT) as td:
  wav=Path(td)/'score.wav'
  with wave.open(str(wav),'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
  subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a','112k',str(path)],check=True)
 print(f'{name}: {duration:.2f}s, {bpm} BPM')
if __name__=='__main__':
 for name,spec in SCORES.items(): render(name,spec)
