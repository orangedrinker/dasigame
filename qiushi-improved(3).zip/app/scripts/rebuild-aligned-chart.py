#!/usr/bin/env python3
"""Build note attacks from confirmed per-character alignment, reusing visual style.

The template supplies lane/pitch colors and the beat/count-in, not vocal timings.
Every sung note uses an aligned character attack; phrase openings receive a
two-lane chord. The original instrumental intro note remains at its file time.
"""
import argparse
import copy
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--template', type=Path, required=True)
    parser.add_argument('--phrases', type=Path, required=True)
    parser.add_argument('--lyrics', type=Path, required=True)
    parser.add_argument('--intro-offset', type=float, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    template = json.loads(args.template.read_text())
    phrases = json.loads(args.phrases.read_text())
    confirmed = [line.strip() for line in args.lyrics.read_text().splitlines() if line.strip()]
    if [p['text'] for p in phrases] != confirmed:
        raise ValueError('Aligned phrases must exactly match the confirmed lyrics')
    styles = [n for n in template['notes'] if not n['lyric'].startswith('前奏')]
    chars = [(pi, ci, char) for pi, phrase in enumerate(phrases) for ci, char in enumerate(phrase['chars'])]
    if len(chars) != sum(map(len, confirmed)):
        raise ValueError('Alignment must include every confirmed character')
    intro = copy.deepcopy(template['notes'][0])
    if not intro['lyric'].startswith('前奏'):
        raise ValueError('Template has no expected instrumental intro note')
    intro['lyric'] = '前奏'
    intro['vocal'] = False
    intro['chord'] = False
    intro['chordLane'] = None
    notes = [intro]
    lyrics = []
    previous_time = -1
    previous_lane = intro['lane']
    for index, (phrase_index, char_index, entry) in enumerate(chars):
        phrase = phrases[phrase_index]
        if not phrase['start'] <= entry['start'] < entry['end'] <= phrase['end'] <= template['duration']:
            raise ValueError(f'Character interval is outside phrase/recording: {entry}')
        if entry['start'] <= previous_time:
            raise ValueError(f'Character attacks must strictly increase: {entry}')
        previous_time = entry['start']
        style = styles[round(index * (len(styles) - 1) / max(1, len(chars) - 1))]
        lane = style['lane']
        if lane == previous_lane:
            lane = (lane + 1) % 4
        previous_lane = lane
        chord = char_index == 0
        notes.append({
            'time': entry['start'],
            'duration': round(min(.95, max(.1, (entry['end'] - entry['start']) * .82)), 4),
            'pitch': style['pitch'],
            'lyric': entry['char'],
            'lane': lane,
            'chord': chord,
            'chordLane': (lane + 2) % 4 if chord else None,
            'vocal': True,
        })
        lyrics.append({'time': entry['start'], 'char': entry['char'], 'phrase': phrase_index})
    result = {
        'duration': template['duration'],
        'beat': template['beat'],
        'source': '浙江大学文琴合唱团《浙江大学校歌》；完整确认歌词 + Demucs 人声强制对齐',
        'vocalOrigin': args.intro_offset,
        'notes': notes,
        'lyrics': lyrics,
    }
    args.output.write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':')) + '\n')
    print(f'Built {len(chars)} aligned vocal attacks, {len(phrases)} phrase-opening chords, 1 preserved intro note')


if __name__ == '__main__':
    main()
