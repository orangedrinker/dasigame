/**
 * build-single.mjs — pack the built game into one portable HTML file.
 *
 * The app loads `/art/*` and `/audio/*` at runtime, which only works when the page is served
 * over HTTP. For phones this script inlines the bundle, the stylesheet and every asset as data
 * URLs into a single .html, so the file can be copied to a phone and opened directly, offline.
 *
 * Usage: node scripts/build-single.mjs [distDir] [outFile]
 */
import { readFile, writeFile, readdir, mkdir } from 'node:fs/promises'
import { dirname, extname, join } from 'node:path'

const dist = process.argv[2] ?? 'dist'
const outFile = process.argv[3] ?? '单文件版/求是-文军长征.html'

const MIME = {
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.ogg': 'audio/ogg',
}

const html = await readFile(join(dist, 'index.html'), 'utf8')
const scriptSrc = html.match(/<script[^>]+src="([^"]+)"/)?.[1]
const styleHref = html.match(/<link[^>]+rel="stylesheet"[^>]+href="([^"]+)"/)?.[1]
if (!scriptSrc) throw new Error('no module script found in dist/index.html')

const resolve = (href) => join(dist, href.replace(/^\.?\//, ''))
const js = await readFile(resolve(scriptSrc), 'utf8')
let css = styleHref ? await readFile(resolve(styleHref), 'utf8') : ''

/** Inline every public asset as a data URL, keyed by the path the app asks for. */
const assets = {}
let assetBytes = 0
for (const dir of ['art', 'audio']) {
  let entries = []
  try {
    entries = await readdir(join(dist, dir))
  } catch {
    continue
  }
  for (const name of entries) {
    const type = MIME[extname(name).toLowerCase()]
    if (!type) continue
    const buffer = await readFile(join(dist, dir, name))
    assetBytes += buffer.length
    assets[`/${dir}/${name}`] = `data:${type};base64,${buffer.toString('base64')}`
  }
}

// The stylesheet still holds static url('/art/…') references: point them at the inlined copies.
for (const [path, dataUrl] of Object.entries(assets)) {
  css = css.split(path).join(dataUrl)
}

const safeJson = JSON.stringify(assets).replace(/</g, '\\u003c')
const safeJs = js.replace(/<\/script/gi, '<\\/script')
const safeCss = css.replace(/<\/style/gi, '<\\/style')

const page = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
<meta name="theme-color" content="#142930" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
<meta name="description" content="求是·文军长征：走进浙江大学西迁校史，在剧情抉择、物资装箱、护送跑酷、路线规划、防空掩护与校歌音游中完成旅程。" />
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='3' fill='%23b95542'/%3E%3Ctext x='16' y='22' text-anchor='middle' font-size='18' fill='%23f1e5cb'%3E求%3C/text%3E%3C/svg%3E" />
<title>求是 · 文军长征</title>
<style>${safeCss}</style>
</head>
<body>
<div id="root"></div>
<script>window.__ASSET_MAP__=${safeJson};</script>
<script type="module">${safeJs}</script>
</body>
</html>
`

await mkdir(dirname(outFile), { recursive: true })
await writeFile(outFile, page)
const mb = (n) => (n / 1024 / 1024).toFixed(2)
console.log(`single-file build: ${outFile}`)
console.log(`  html ${mb(Buffer.byteLength(page))} MB  (js ${mb(Buffer.byteLength(js))} MB, css ${mb(css.length)} MB, assets ${mb(assetBytes)} MB raw, ${Object.keys(assets).length} files)`)
