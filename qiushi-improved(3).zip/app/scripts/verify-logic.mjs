// Bundle the TypeScript regression tests for Node's built-in test runner.
import { build } from 'esbuild'
import { mkdtemp, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
const directory=await mkdtemp(join(process.cwd(),'.logic-check-'))
try {
 const file=join(directory,'tests.mjs')
 await build({entryPoints:['tests/progression.test.ts'],outfile:file,bundle:true,platform:'node',format:'esm',define:{'import.meta.env.VITE_GAME_EDITION':'"formal"'}})
 const result=spawnSync(process.execPath,['--test',file],{stdio:'inherit',timeout:30000})
 process.exitCode=result.status??1
} finally { await rm(directory,{recursive:true,force:true}) }
