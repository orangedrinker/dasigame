@echo off
rem One-click local preview for the built game in dist\.
rem ES modules and audio cannot load from file:// URLs, so the build needs a static HTTP server.
setlocal
cd /d "%~dp0dist"
if not exist "index.html" (
  echo [error] dist\index.html not found - run "npm run build" first.
  pause
  exit /b 1
)
set "PORT=8080"

rem 1) Python bundled with the DeepSeek Harness runtime on this machine
if exist "C:\Users\OseasyVM\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" set "PY=C:\Users\OseasyVM\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if defined PY goto :run

rem 2) the py launcher
py -3 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if defined PY goto :run

rem 3) python on PATH, ignoring the Microsoft Store stub that cannot run scripts
python -c "import sys" >nul 2>nul
if not errorlevel 1 set "PY=python"
if defined PY goto :run

echo [error] Python 3 not found. Install Python, then run this file again.
echo         Or serve the dist folder with any static server, e.g. "npx serve dist".
pause
exit /b 1

:run
start "qiushi preview %PORT%" /min %PY% -m http.server %PORT% --bind 127.0.0.1
timeout /t 2 >nul
start "" "http://127.0.0.1:%PORT%/"
echo.
echo   Game URL : http://127.0.0.1:%PORT%/
echo   Stop     : close the "qiushi preview %PORT%" window
echo   Phone/LAN: change --bind 127.0.0.1 to --bind 0.0.0.0, then open http://YOUR-IP:%PORT%/
echo.
pause
