// This marker is changed for each delivered snapshot so previews retain their intended flow.
export const BUILD_EDITION: 'brief' | 'formal' = 'formal'
