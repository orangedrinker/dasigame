export type GameEvent =
  | { type: 'gameover'; score: number }
  | { type: 'complete'; score: number; seals: number }
  | { type: 'paused'; paused: boolean }
  | { type: 'reset' }
  | { type: 'rhythm-result'; score: number; combo: number; accuracy: number; perfect: number; good: number; miss: number }

export type GameHandle = {
  jump: () => void
  setDuck: (value: boolean) => void
  setPaused: (value: boolean) => void
  restart: () => void
  start: () => void
  hitLane: (lane: number, pressed?: boolean) => void
  toggleMute: () => boolean
}
