/**
 * asset.ts — resolve a public asset path (`/art/…`, `/audio/…`).
 *
 * A normal build serves those files from the web root. The single-file phone build writes the
 * same files into `window.__ASSET_MAP__` as data URLs and loads this page from a local file,
 * where `/art/…` cannot be fetched; every loader therefore goes through `assetUrl`.
 */
type AssetMap = Record<string, string>

export function assetUrl(path: string): string {
  const map = (globalThis as { __ASSET_MAP__?: AssetMap }).__ASSET_MAP__
  return (map && map[path]) || path
}
