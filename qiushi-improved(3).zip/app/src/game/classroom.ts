// A continuous route from the left source to the right classroom. Every tile is reversible by rotation.
export const BASE = [[1,3],[1,2],[1,3],[2,3],[0,1],[0,2],[0,2],[0,2],[0,2],[0,2],[0,3],[0,2],[0,1],[0,3],[1,3],[1,3]]
export function connectedTiles(turns: number[]) {
 const dirs = BASE.map((ports,i) => ports.map(d => (d+turns[i])%4))
 const found = new Set<number>(); const queue = dirs[0].includes(3) ? [0] : []
 while(queue.length) {const i=queue.shift()!;if(found.has(i))continue;found.add(i)
  for(const d of dirs[i]) {const row=Math.floor(i/4),col=i%4;const nr=row+[-1,0,1,0][d],nc=col+[0,1,0,-1][d]; if(nr<0||nr>3||nc<0||nc>3)continue;const j=nr*4+nc;if(dirs[j].includes((d+2)%4)&&!found.has(j))queue.push(j)}
 }
 return {found, solved:found.has(15)&&dirs[15].includes(1)}
}
