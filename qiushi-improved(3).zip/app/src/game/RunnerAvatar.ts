import Phaser from 'phaser'

type Point = { x: number; y: number }
type Color = [number, number, number]

const mix = (a: number, b: number, t: number) => a + (b - a) * t
const point = (x: number, y: number): Point => ({ x, y })

/** Painted figure.
 *
 * The runner used to be a flat vector silhouette drawn with Phaser Graphics. It is now painted
 * with a 2D canvas at PAINT_SCALE× and sampled down to the game's pixel size: every limb is a
 * shaded cylinder, the robe carries soft folds, and edges are painted rather than inked — so the
 * character reads as a small oil study inside the painted scenery instead of an illustration on
 * top of it. The articulated skeleton (and therefore every animation) is unchanged. */
const PAINT_SCALE = 3
const BOX = { w: 132, h: 120, ox: 64, oy: 106 }

const SKIN_LIT: Color = [174, 146, 118]
const SKIN_MID: Color = [138, 110, 87]
const SKIN_DARK: Color = [84, 60, 47]

const ROBE_LIT: Color = [92, 111, 121]
const ROBE_MID: Color = [62, 80, 90]
const ROBE_DARK: Color = [37, 51, 60]
const ROBE_DEEP: Color = [26, 36, 44]

const TROUSER_LIT: Color = [64, 77, 85]
const TROUSER_MID: Color = [43, 55, 63]
const TROUSER_DARK: Color = [25, 33, 39]

const SHOE_LIT: Color = [56, 57, 52]
const SHOE_MID: Color = [30, 32, 31]
const SHOE_DARK: Color = [18, 21, 21]

const HAIR_LIT: Color = [82, 69, 56]
const HAIR_MID: Color = [45, 38, 32]
const HAIR_DARK: Color = [22, 19, 17]

const BAG_LIT: Color = [130, 100, 64]
const BAG_MID: Color = [94, 71, 45]
const BAG_DARK: Color = [52, 39, 25]

const SHIRT: Color = [178, 164, 138]
const SHIRT_DARK: Color = [122, 108, 86]

/** Key light matches the painted skies: warm, from the upper right. */
const LIGHT = { x: 0.62, y: -0.78 }

const css = (c: Color, a = 1) => `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a})`

function tracePoly(ctx: CanvasRenderingContext2D, points: Point[]) {
  ctx.beginPath()
  ctx.moveTo(points[0].x, points[0].y)
  for (const p of points.slice(1)) ctx.lineTo(p.x, p.y)
  ctx.closePath()
}

function fillPoly(ctx: CanvasRenderingContext2D, points: Point[], style: string | CanvasGradient) {
  tracePoly(ctx, points)
  ctx.fillStyle = style
  ctx.fill()
}

/** Paint a limb as a lit cylinder: body gradient, dark trailing edge, soft highlight. */
function cylinder(
  ctx: CanvasRenderingContext2D,
  a: Point,
  b: Point,
  width: number,
  lit: Color,
  mid: Color,
  dark: Color,
) {
  const dx = b.x - a.x
  const dy = b.y - a.y
  const len = Math.hypot(dx, dy) || 1
  let nx = -dy / len
  let ny = dx / len
  if (nx * LIGHT.x + ny * LIGHT.y < 0) {
    nx = -nx
    ny = -ny
  }
  const half = width / 2
  const g = ctx.createLinearGradient(a.x - nx * half, a.y - ny * half, a.x + nx * half, a.y + ny * half)
  g.addColorStop(0, css(dark))
  g.addColorStop(0.5, css(mid))
  g.addColorStop(1, css(lit))
  ctx.strokeStyle = g
  ctx.lineWidth = width
  ctx.beginPath()
  ctx.moveTo(a.x, a.y)
  ctx.lineTo(b.x, b.y)
  ctx.stroke()

  ctx.strokeStyle = css(dark, 0.55)
  ctx.lineWidth = width * 0.2
  ctx.beginPath()
  ctx.moveTo(a.x - nx * half * 0.82, a.y - ny * half * 0.82)
  ctx.lineTo(b.x - nx * half * 0.82, b.y - ny * half * 0.82)
  ctx.stroke()

  ctx.strokeStyle = css(lit, 0.3)
  ctx.lineWidth = width * 0.24
  ctx.beginPath()
  ctx.moveTo(a.x + nx * half * 0.55, a.y + ny * half * 0.55)
  ctx.lineTo(b.x + nx * half * 0.55, b.y + ny * half * 0.55)
  ctx.stroke()
}

/** Soft brush dabs are drawn from one cached sprite per colour: creating a radial gradient
 *  for every dab on every frame is what made the painted figure expensive. */
const dabSprites = new Map<string, HTMLCanvasElement>()

function dabSprite(color: Color): HTMLCanvasElement | null {
  const key = color.join(',')
  const cached = dabSprites.get(key)
  if (cached) return cached
  const canvas = document.createElement('canvas')
  canvas.width = 64
  canvas.height = 64
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  g.addColorStop(0, css(color, 1))
  g.addColorStop(0.55, css(color, 0.5))
  g.addColorStop(1, css(color, 0))
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 64, 64)
  dabSprites.set(key, canvas)
  return canvas
}

/** A soft brush dab: a radial smear that fades out, used to break smooth gradients
 *  into something that reads as paint rather than plastic. */
function softDab(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rx: number,
  ry: number,
  rotation: number,
  color: Color,
  alpha: number,
) {
  const sprite = dabSprite(color)
  if (!sprite) return
  ctx.save()
  ctx.translate(x, y)
  ctx.rotate(rotation)
  ctx.globalAlpha = alpha
  ctx.drawImage(sprite, -rx, -ry, rx * 2, ry * 2)
  ctx.globalAlpha = 1
  ctx.restore()
}

/** Trim a hip-to-ankle path at the robe hem, so a bent knee can never poke through the cloth. */
function belowHem(points: Point[], hem: number): Point[] {
  const kept: Point[] = []
  for (let i = 0; i < points.length; i += 1) {
    const p = points[i]
    if (p.y >= hem) {
      if (kept.length === 0 && i > 0) {
        const prev = points[i - 1]
        const t = (hem - prev.y) / (p.y - prev.y)
        kept.push(point(prev.x + (p.x - prev.x) * t, hem))
      }
      kept.push(p)
    } else if (kept.length > 0) {
      break
    }
  }
  return kept
}

/** Two-bone IK: returns the forward-bent knee for a hip/foot pair. */
function knee(hip: Point, foot: Point, thigh: number, shin: number): Point {
  const dx = foot.x - hip.x
  const dy = foot.y - hip.y
  const distance = Math.hypot(dx, dy) || 1
  const reach = Math.min(thigh + shin - 0.6, Math.max(1, distance))
  const ux = dx / distance
  const uy = dy / distance
  const along = (reach * reach + thigh * thigh - shin * shin) / (2 * reach)
  const lift = Math.sqrt(Math.max(0, thigh * thigh - along * along))
  return point(hip.x + ux * along + uy * lift, hip.y + uy * along - ux * lift)
}

let avatarCount = 0

export class RunnerAvatar {
  readonly art: Phaser.GameObjects.Image
  private texture: Phaser.Textures.CanvasTexture
  private ctx: CanvasRenderingContext2D
  private grain: CanvasPattern | null = null
  private crouch = 0
  private land = 0

  constructor(scene: Phaser.Scene) {
    const key = `runner-avatar-${avatarCount++}`
    if (scene.textures.exists(key)) scene.textures.remove(key)
    const texture = scene.textures.createCanvas(key, BOX.w * PAINT_SCALE, BOX.h * PAINT_SCALE)
    if (!texture) throw new Error('canvas texture unavailable')
    this.texture = texture
    this.ctx = texture.getContext()
    this.art = scene.add
      .image(0, 0, key)
      .setOrigin(BOX.ox / BOX.w, BOX.oy / BOX.h)
      .setDisplaySize(BOX.w, BOX.h)
    this.grain = makeGrain()
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.texture.destroy())
  }

  landed() {
    this.land = 1
  }

  /** Scale the painted figure relative to its in-game size (the game uses 1). */
  setScaleFactor(factor: number) {
    this.art.setScale((BOX.w / this.texture.width) * factor)
    return this.art
  }

  draw(dt: number, time: number, running: boolean, airborne: boolean, ducking: boolean, vy: number, accent: number) {
    this.crouch = mix(this.crouch, ducking ? 1 : 0, 1 - Math.exp(-dt * 22))
    this.land = Math.max(0, this.land - dt * 6)
    const ctx = this.ctx
    ctx.setTransform(1, 0, 0, 1, 0, 0)
    ctx.clearRect(0, 0, this.texture.width, this.texture.height)
    ctx.setTransform(PAINT_SCALE, 0, 0, PAINT_SCALE, BOX.ox * PAINT_SCALE, BOX.oy * PAINT_SCALE)
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.globalCompositeOperation = 'source-over'

    const c = this.crouch
    const phase = time * 15
    const bob = running && !airborne ? (1 - Math.abs(Math.cos(phase))) * 2.8 : airborne ? 0 : Math.sin(time * 1.7) * 0.6
    const sink = this.land * 3.2
    const lean = running && !airborne ? 2.6 : 1

    // ---- skeleton --------------------------------------------------------------
    const hip = point(mix(-1, -3.5, c), mix(-45 + bob + sink, -15, c))
    const waist = point(mix(0.4, 0, c), mix(-54 + bob + sink, -21, c))
    const shoulder = point(mix(2.4 + lean * 0.5, 3.2, c), mix(-70 + bob + sink, -31, c))
    const head = point(mix(4.6 + lean, 6.2, c), mix(-83 + bob + sink, -44, c))

    const swing = running ? Math.sin(phase) * 10 : 1.6
    // the hem lifts with the jump, so tucked feet stay readable under the cloth
    const hemY = mix(-23, -5, c) - (airborne ? 4 : 0)
    const trail = airborne ? 5 : running ? 4 : 1
    const sway = running && !airborne ? Math.sin(phase + 0.5) * 1.8 : Math.sin(time * 1.6) * 0.7

    const footAt = (front: boolean): Point => {
      const p = phase + (front ? 0 : Math.PI)
      let f = running
        ? point(Math.sin(p) * 16, -Math.max(0, Math.cos(p)) * 11)
        : point(front ? 8 : -8, 0)
      if (airborne) f = front ? point(14, -13 - Math.min(2, Math.abs(vy) / 420)) : point(-12, -4)
      return point(mix(f.x, front ? 11 : -11, c), mix(f.y, -0.5, c))
    }

    const ankleFor = (foot: Point) => point(foot.x, foot.y - 3.4)

    // ---- back legs, satchel, far arm -------------------------------------------
    const paintLeg = (front: boolean) => {
      const foot = footAt(front)
      const ankle = ankleFor(foot)
      const kneePoint = knee(hip, ankle, 22, 23)
      const visible = belowHem([hip, kneePoint, ankle], hemY - 0.5)
      if (visible.length < 2) return
      const lit: Color = front ? TROUSER_LIT : [64, 76, 82]
      const mid: Color = front ? TROUSER_MID : [40, 51, 58]
      const dark: Color = front ? TROUSER_DARK : [22, 30, 35]
      for (let i = 0; i < visible.length - 1; i += 1) {
        const width = i === 0 ? (front ? 8.6 : 8) : front ? 6.6 : 6.2
        cylinder(ctx, visible[i], visible[i + 1], width, lit as Color, mid as Color, dark as Color)
      }
      ctx.globalCompositeOperation = 'source-atop'
      const last = visible[visible.length - 1]
      const first = visible[0]
      softDab(ctx, first.x + 1.4, first.y + 6, 3.4, 7, 0.2, lit as Color, front ? 0.18 : 0.1)
      softDab(ctx, last.x - 2.2, last.y - 6, 2.6, 5.4, -0.25, dark as Color, 0.16)
      ctx.globalCompositeOperation = 'source-over'
      if (visible.length > 2) {
        ctx.fillStyle = css(mid as Color, 0.55)
        ctx.beginPath()
        ctx.arc(visible[1].x, visible[1].y, (front ? 6.2 : 5.8) / 2, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    paintLeg(false)

    const bagX = hip.x - 9
    const bagY = mix(-49, -18, c)
    const bagG = ctx.createLinearGradient(bagX - 7, bagY - 8, bagX + 7, bagY + 8)
    bagG.addColorStop(0, css(BAG_DARK))
    bagG.addColorStop(0.55, css(BAG_MID))
    bagG.addColorStop(1, css(BAG_LIT))
    ctx.beginPath()
    ctx.ellipse(bagX, bagY, 6.6, 8.2, 0.04, 0, Math.PI * 2)
    ctx.fillStyle = bagG
    ctx.fill()
    ctx.strokeStyle = css(BAG_DARK, 0.6)
    ctx.lineWidth = 0.8
    ctx.stroke()
    // flap and stitching
    ctx.beginPath()
    ctx.ellipse(bagX, bagY - 3.2, 6.5, 5.2, 0.04, Math.PI * 0.98, Math.PI * 2.02)
    ctx.fillStyle = css(BAG_DARK, 0.85)
    ctx.fill()
    ctx.strokeStyle = css([150, 122, 84], 0.3)
    ctx.lineWidth = 0.5
    ctx.beginPath()
    ctx.moveTo(bagX - 5.6, bagY - 1.4)
    ctx.quadraticCurveTo(bagX, bagY + 0.6, bagX + 5.6, bagY - 1.6)
    ctx.stroke()
    // two book spines peeking out
    ctx.fillStyle = css([206, 190, 158])
    ctx.fillRect(bagX - 3.2, bagY - 11.6, 2.6, 4.4)
    ctx.fillStyle = css([124, 78, 66])
    ctx.fillRect(bagX + 0.4, bagY - 11, 2.4, 3.8)

    const paintArm = (front: boolean) => {
      const root = point(shoulder.x + (front ? 1 : -1.2), shoulder.y + 3.4)
      const elbow = front
        ? point(mix(shoulder.x + 1.8 + swing * 0.62, shoulder.x + 4.4, c), mix(shoulder.y + 15.4, shoulder.y + 9, c))
        : point(mix(shoulder.x - 1.6 - swing * 0.62, shoulder.x + 2.2, c), mix(shoulder.y + 15.4, shoulder.y + 9, c))
      const wrist = front
        ? point(mix(elbow.x + 0.6 + swing * 0.22, elbow.x + 6.2, c), mix(elbow.y + 14, elbow.y + 8.6, c))
        : point(mix(elbow.x + 0.2 - swing * 0.22, elbow.x + 3.2, c), mix(elbow.y + 13.6, elbow.y + 8, c))
      const sleeveLit = front ? ROBE_LIT : ROBE_DARK
      const sleeveMid = front ? ROBE_MID : ROBE_DARK
      const sleeveDark = front ? ROBE_DARK : ROBE_DEEP
      cylinder(ctx, root, elbow, front ? 8.6 : 7.8, sleeveLit, sleeveMid, sleeveDark)
      cylinder(ctx, elbow, wrist, front ? 6.8 : 6.2, sleeveLit, sleeveMid, sleeveDark)
      // hand
      const handG = ctx.createRadialGradient(wrist.x + 0.8, wrist.y - 1, 0.4, wrist.x, wrist.y + 0.4, 4)
      handG.addColorStop(0, css([196, 166, 134]))
      handG.addColorStop(0.65, css(SKIN_MID))
      handG.addColorStop(1, css(SKIN_DARK))
      ctx.beginPath()
      ctx.ellipse(wrist.x + 0.3, wrist.y + 1.3, 2.1, 2.5, 0.2, 0, Math.PI * 2)
      ctx.fillStyle = handG
      ctx.fill()
    }

    paintArm(false)

    // ---- robe -------------------------------------------------------------------
    // The front panel drapes over whichever leg is leading, so a forward stride always reads as
    // cloth over a leg rather than a shin poking out of the robe's edge.
    const leadX = Math.max(footAt(true).x, footAt(false).x)
    const frontHip = Math.max(hip.x + 8.2, leadX * 0.55)
    const hemBack = point(hip.x - 9 - trail + sway, hemY - 1.4)
    const hemFront = point(Math.max(hip.x + 10.4 + sway, leadX + 2.4), hemY - 2.6)
    const hemNotch = point(hip.x + 1.2 + sway, hemY + 0.4)
    const robe = [
      point(shoulder.x - 6.6, shoulder.y + 3.6),
      point(waist.x - 6.8, waist.y),
      point(hip.x - 8, mix(-38, -12, c)),
      hemBack,
      hemNotch,
      hemFront,
      point(frontHip, mix(-38, -12, c)),
      point(waist.x + 6.6, waist.y - 2),
      point(shoulder.x + 8, shoulder.y + 8),
      point(shoulder.x + 4.4, shoulder.y - 2),
      point(shoulder.x - 2.6, shoulder.y - 3),
    ]
    const robeG = ctx.createLinearGradient(shoulder.x - 8, 0, shoulder.x + 10, 0)
    robeG.addColorStop(0, css(ROBE_DEEP))
    robeG.addColorStop(0.3, css(ROBE_DARK))
    robeG.addColorStop(0.68, css(ROBE_MID))
    robeG.addColorStop(1, css(ROBE_LIT))
    fillPoly(ctx, robe, robeG)
    const depthG = ctx.createLinearGradient(0, shoulder.y, 0, hemY)
    depthG.addColorStop(0, 'rgba(240,238,225,0.10)')
    depthG.addColorStop(0.45, 'rgba(0,0,0,0)')
    depthG.addColorStop(1, 'rgba(10,16,20,0.42)')
    fillPoly(ctx, robe, depthG)
    tracePoly(ctx, robe)
    ctx.strokeStyle = css(ROBE_DEEP, 0.5)
    ctx.lineWidth = 0.7
    ctx.stroke()

    // cloth folds: painted with soft darks and a light catch, not outlines
    const folds: [Point, Point, Point, number][] = [
      [point(waist.x - 4.2, waist.y + 2), point(hip.x - 4.8, hemY - 8), point(hemBack.x + 2.4, hemBack.y + 0.6), 0.3],
      [point(waist.x - 0.6, waist.y + 2.6), point(hip.x - 0.8, hemY - 6), point(hemNotch.x + 0.6, hemNotch.y - 1), 0.22],
      [point(waist.x + 3, waist.y + 1.6), point(hip.x + 3.6, hemY - 7), point(hemFront.x - 2.6, hemFront.y + 0.4), 0.26],
      [point(waist.x + 5.4, waist.y + 1), point(hip.x + 6, hemY - 9), point(hemFront.x - 0.8, hemFront.y - 1), 0.0],
    ]
    for (const [a, b, d, alpha] of folds) {
      ctx.strokeStyle = alpha > 0 ? css(ROBE_DEEP, alpha) : css([186, 199, 196], 0.16)
      ctx.lineWidth = alpha > 0 ? 1.5 : 1.1
      ctx.beginPath()
      ctx.moveTo(a.x, a.y)
      ctx.quadraticCurveTo(b.x, b.y, d.x, d.y)
      ctx.stroke()
    }
    // lining visible along the hem
    ctx.strokeStyle = css([16, 22, 27], 0.55)
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(hemBack.x, hemBack.y + 1)
    ctx.lineTo(hemNotch.x, hemNotch.y)
    ctx.lineTo(hemFront.x, hemFront.y + 1)
    ctx.stroke()

    // brushwork: broad light and dark dabs so the cloth is painted, not airbrushed
    const robeDabs: [number, number, number, number, number, Color, number][] = [
      [0.24, 0.2, 5.5, 10, -0.28, [176, 194, 198], 0.12],
      [0.16, 0.52, 4.6, 9, -0.18, [22, 32, 40], 0.16],
      [0.34, 0.68, 4.2, 8, 0.24, [18, 26, 33], 0.2],
      [0.52, 0.34, 5.8, 11, 0.14, [186, 202, 204], 0.1],
      [0.62, 0.62, 4.8, 9, -0.2, [16, 24, 30], 0.18],
      [0.44, 0.86, 5.4, 7.5, 0.34, [200, 210, 206], 0.08],
      [0.72, 0.22, 4.4, 8.5, -0.32, [190, 204, 206], 0.09],
      [0.86, 0.46, 4.6, 9.5, 0.2, [206, 214, 208], 0.08],
    ]
    ctx.globalCompositeOperation = 'source-atop'
    for (const [tx, ty, rx, ry, rot, color, alpha] of robeDabs) {
      const x = mix(shoulder.x - 6, hemFront.x, tx) + sway * 0.4
      const y = mix(shoulder.y + 6, hemY, ty)
      softDab(ctx, x, y, rx, ry, rot, color, alpha)
    }
    ctx.globalCompositeOperation = 'source-over'

    // sash
    const sashG = ctx.createLinearGradient(waist.x - 7, 0, waist.x + 7, 0)
    sashG.addColorStop(0, css([22, 30, 33]))
    sashG.addColorStop(1, css([46, 58, 60]))
    ctx.beginPath()
    ctx.moveTo(waist.x - 6.6, waist.y - 2.6)
    ctx.quadraticCurveTo(waist.x, waist.y - 3.6, waist.x + 6.2, waist.y - 3.8)
    ctx.lineTo(waist.x + 5.8, waist.y + 1.4)
    ctx.quadraticCurveTo(waist.x, waist.y + 0.6, waist.x - 6.4, waist.y + 2)
    ctx.closePath()
    ctx.fillStyle = sashG
    ctx.fill()
    ctx.strokeStyle = css([160, 172, 168], 0.18)
    ctx.lineWidth = 0.6
    ctx.beginPath()
    ctx.moveTo(waist.x - 6.2, waist.y - 2.2)
    ctx.quadraticCurveTo(waist.x, waist.y - 3.2, waist.x + 5.8, waist.y - 3.2)
    ctx.stroke()

    // cross-body strap
    ctx.strokeStyle = css([78, 58, 36], 0.95)
    ctx.lineWidth = 3.6
    ctx.beginPath()
    ctx.moveTo(shoulder.x + 3.2, shoulder.y - 0.6)
    ctx.quadraticCurveTo(waist.x - 1, waist.y - 9, waist.x - 3.4, waist.y + 1.4)
    ctx.stroke()
    ctx.strokeStyle = css([176, 148, 108], 0.35)
    ctx.lineWidth = 0.8
    ctx.beginPath()
    ctx.moveTo(shoulder.x + 4.2, shoulder.y - 0.2)
    ctx.quadraticCurveTo(waist.x, waist.y - 9, waist.x - 2.6, waist.y + 1.2)
    ctx.stroke()

    // chest badge, keeping each level's accent colour
    ctx.beginPath()
    ctx.arc(shoulder.x + 3.6, shoulder.y + 5.6, 1.5, 0, Math.PI * 2)
    ctx.fillStyle = css([229, 180, 91], 0.92)
    ctx.fill()
    ctx.beginPath()
    ctx.arc(shoulder.x + 3.2, shoulder.y + 5.2, 0.6, 0, Math.PI * 2)
    ctx.fillStyle = 'rgba(26,32,36,0.5)'
    ctx.fill()

    // ---- near leg, shoes, near arm ---------------------------------------------
    paintLeg(true)

    const paintShoe = (front: boolean) => {
      const foot = footAt(front)
      const shoeG = ctx.createLinearGradient(foot.x - 4, foot.y - 4, foot.x + 8, foot.y)
      shoeG.addColorStop(0, css(front ? SHOE_LIT : SHOE_DARK))
      shoeG.addColorStop(0.6, css(front ? SHOE_MID : SHOE_DARK))
      shoeG.addColorStop(1, css(SHOE_DARK))
      ctx.beginPath()
      ctx.moveTo(foot.x - 3.6, foot.y - 4.4)
      ctx.quadraticCurveTo(foot.x - 1.4, foot.y - 5.2, foot.x + 2.4, foot.y - 3.6)
      ctx.quadraticCurveTo(foot.x + 7.6, foot.y - 3, foot.x + 9.4, foot.y - 1.4)
      ctx.quadraticCurveTo(foot.x + 10, foot.y, foot.x + 8.4, foot.y + 0.2)
      ctx.lineTo(foot.x - 3.2, foot.y + 0.4)
      ctx.quadraticCurveTo(foot.x - 4.2, foot.y - 1.6, foot.x - 3.6, foot.y - 4.4)
      ctx.closePath()
      ctx.fillStyle = shoeG
      ctx.fill()
      ctx.strokeStyle = css([12, 15, 15], 0.5)
      ctx.lineWidth = 0.5
      ctx.stroke()
      ctx.strokeStyle = css([120, 118, 104], 0.18)
      ctx.lineWidth = 0.6
      ctx.beginPath()
      ctx.moveTo(foot.x - 2, foot.y - 0.4)
      ctx.lineTo(foot.x + 7.6, foot.y - 0.2)
      ctx.stroke()
    }

    // reconnect the ankle so a lifted foot never floats away from its shin
    const paintAnkle = (front: boolean) => {
      const foot = footAt(front)
      const ankle = ankleFor(foot)
      const top = Math.max(ankle.y - 3.4, hemY - 1)
      if (top < ankle.y - 2) return
      const lit: Color = front ? TROUSER_MID : [52, 64, 70]
      const mid: Color = front ? TROUSER_DARK : [36, 45, 50]
      const dark: Color = [18, 24, 28]
      cylinder(ctx, point(ankle.x + 0.4, top), ankle, front ? 7 : 6.4, lit, mid, dark)
    }

    paintAnkle(false)
    paintShoe(false)
    paintAnkle(true)
    paintShoe(true)

    paintArm(true)

    // ---- neck, collar, head -----------------------------------------------------
    cylinder(ctx, point(head.x - 1, head.y + 4), point(head.x - 0.6, shoulder.y + 0.6), 5, SKIN_MID, SKIN_MID, SKIN_DARK)
    // ivory collar of the inner shirt
    ctx.beginPath()
    ctx.moveTo(shoulder.x - 4, shoulder.y + 1.6)
    ctx.quadraticCurveTo(shoulder.x - 2.4, shoulder.y - 5.6, shoulder.x + 1.4, shoulder.y - 6.6)
    ctx.quadraticCurveTo(shoulder.x + 4.6, shoulder.y - 5.2, shoulder.x + 6, shoulder.y - 1)
    ctx.quadraticCurveTo(shoulder.x + 1, shoulder.y + 1.6, shoulder.x - 4, shoulder.y + 1.6)
    ctx.closePath()
    const collarG = ctx.createLinearGradient(shoulder.x - 4, shoulder.y - 6, shoulder.x + 5, shoulder.y + 1)
    collarG.addColorStop(0, css(SHIRT))
    collarG.addColorStop(1, css(SHIRT_DARK))
    ctx.fillStyle = collarG
    ctx.fill()
    // dark stand collar over it
    ctx.beginPath()
    ctx.moveTo(shoulder.x - 3, shoulder.y + 2)
    ctx.quadraticCurveTo(shoulder.x - 1.6, shoulder.y - 4.2, shoulder.x + 1.2, shoulder.y - 5)
    ctx.quadraticCurveTo(shoulder.x + 4, shoulder.y - 3.8, shoulder.x + 5.4, shoulder.y + 0.4)
    ctx.quadraticCurveTo(shoulder.x + 1, shoulder.y + 2.4, shoulder.x - 3, shoulder.y + 2)
    ctx.closePath()
    const bandG = ctx.createLinearGradient(shoulder.x - 3, shoulder.y - 5, shoulder.x + 5, shoulder.y + 1)
    bandG.addColorStop(0, css(ROBE_DEEP))
    bandG.addColorStop(1, css(ROBE_DARK))
    ctx.fillStyle = bandG
    ctx.fill()
    ctx.strokeStyle = css([214, 196, 162], 0.45)
    ctx.lineWidth = 0.5
    ctx.beginPath()
    ctx.moveTo(shoulder.x - 1.2, shoulder.y - 4.4)
    ctx.quadraticCurveTo(shoulder.x + 1.6, shoulder.y - 5.2, shoulder.x + 4.4, shoulder.y - 3.4)
    ctx.stroke()

    // head: a small painted skull, warm on the light side, cool in the shadow
    const hx = head.x
    const hy = head.y
    // neck shadow, so the head sits on the collar instead of floating above it
    ctx.beginPath()
    ctx.ellipse(hx - 0.6, hy + 5.4, 3.2, 2.2, 0, 0, Math.PI * 2)
    ctx.fillStyle = css(SKIN_DARK, 0.4)
    ctx.fill()
    const faceG = ctx.createRadialGradient(hx + 2, hy - 2.6, 0.5, hx - 0.3, hy + 1, 7.4)
    faceG.addColorStop(0, css([198, 168, 136]))
    faceG.addColorStop(0.4, css(SKIN_LIT))
    faceG.addColorStop(0.78, css(SKIN_MID))
    faceG.addColorStop(1, css(SKIN_DARK))
    ctx.beginPath()
    ctx.ellipse(hx, hy, 4.4, 5.7, -0.05, 0, Math.PI * 2)
    ctx.fillStyle = faceG
    ctx.fill()
    // jaw and cheek: soft shadows, no outline
    ctx.beginPath()
    ctx.ellipse(hx + 0.8, hy + 3.6, 3, 2.2, 0.1, 0, Math.PI * 2)
    ctx.fillStyle = css(SKIN_MID, 0.3)
    ctx.fill()
    ctx.beginPath()
    ctx.ellipse(hx - 2.2, hy + 0.8, 2.1, 4.4, 0.05, 0, Math.PI * 2)
    ctx.fillStyle = css(SKIN_DARK, 0.3)
    ctx.fill()
    // nose profile
    ctx.beginPath()
    ctx.moveTo(hx + 3.9, hy - 1.6)
    ctx.quadraticCurveTo(hx + 4.8, hy + 0.3, hx + 3.7, hy + 1.4)
    ctx.quadraticCurveTo(hx + 4.2, hy + 0.3, hx + 3.5, hy - 1.2)
    ctx.fillStyle = css([104, 72, 56], 0.32)
    ctx.fill()
    // hair: short, covering the crown and the back of the skull, with a warm sheen
    const hairG = ctx.createLinearGradient(hx - 4.4, hy - 6, hx + 4, hy + 1)
    hairG.addColorStop(0, css(HAIR_DARK))
    hairG.addColorStop(0.5, css(HAIR_MID))
    hairG.addColorStop(1, css(HAIR_LIT))
    ctx.beginPath()
    ctx.moveTo(hx - 4.8, hy + 1.6)
    ctx.quadraticCurveTo(hx - 5.4, hy - 3.2, hx - 3.6, hy - 5.8)
    ctx.quadraticCurveTo(hx - 1.2, hy - 7.8, hx + 1.8, hy - 7)
    ctx.quadraticCurveTo(hx + 3.8, hy - 6.2, hx + 3.8, hy - 4)
    ctx.quadraticCurveTo(hx + 2.2, hy - 4.4, hx + 0.4, hy - 5)
    ctx.quadraticCurveTo(hx - 2, hy - 4.6, hx - 3.4, hy - 2.4)
    ctx.quadraticCurveTo(hx - 3.9, hy - 0.6, hx - 3.6, hy + 1.2)
    ctx.closePath()
    ctx.fillStyle = hairG
    ctx.fill()
    ctx.strokeStyle = css([150, 128, 100], 0.28)
    ctx.lineWidth = 0.55
    ctx.beginPath()
    ctx.moveTo(hx - 2.6, hy - 4.6)
    ctx.quadraticCurveTo(hx - 0.4, hy - 5.6, hx + 2, hy - 5)
    ctx.stroke()
    // brow, eye, mouth: quiet and level
    ctx.strokeStyle = css([48, 39, 33], 0.5)
    ctx.lineWidth = 0.8
    ctx.beginPath()
    ctx.moveTo(hx + 1.2, hy - 2.4)
    ctx.quadraticCurveTo(hx + 2.8, hy - 2.9, hx + 3.7, hy - 2.6)
    ctx.stroke()
    ctx.beginPath()
    ctx.ellipse(hx + 2.7, hy - 0.7, 1, 0.75, 0, 0, Math.PI * 2)
    ctx.fillStyle = css([34, 27, 23], 0.88)
    ctx.fill()
    ctx.beginPath()
    ctx.arc(hx + 3, hy - 1, 0.28, 0, Math.PI * 2)
    ctx.fillStyle = 'rgba(255,250,238,0.55)'
    ctx.fill()
    ctx.strokeStyle = css([120, 80, 64], 0.55)
    ctx.lineWidth = 0.7
    ctx.beginPath()
    ctx.moveTo(hx + 2.9, hy + 2.4)
    ctx.quadraticCurveTo(hx + 3.8, hy + 2.6, hx + 4.3, hy + 2.2)
    ctx.stroke()
    // ear, tucked under the hair
    ctx.beginPath()
    ctx.ellipse(hx - 2.9, hy + 0.7, 1.2, 1.7, 0.1, 0, Math.PI * 2)
    ctx.fillStyle = css(SKIN_MID, 0.6)
    ctx.fill()

    // ---- light pass: warm rim from the sky, cool bounce underneath ---------------
    ctx.lineWidth = 1.1
    ctx.strokeStyle = css([232, 190, 120], 0.26)
    ctx.beginPath()
    ctx.moveTo(hx - 4, hy - 1.2)
    ctx.quadraticCurveTo(hx - 4.4, hy - 4, hx - 2.8, hy - 5.8)
    ctx.stroke()
    ctx.strokeStyle = css([232, 190, 120], 0.16)
    ctx.beginPath()
    ctx.moveTo(shoulder.x - 6.4, shoulder.y + 4)
    ctx.quadraticCurveTo(waist.x - 6.6, waist.y - 8, hip.x - 7.6, hemY - 12)
    ctx.stroke()
    // accent tint along the lit shoulder, so each level's colour still registers
    const accentRgb: Color = [(accent >> 16) & 255, (accent >> 8) & 255, accent & 255]
    ctx.strokeStyle = css(accentRgb, 0.16)
    ctx.lineWidth = 1
    ctx.beginPath()
    ctx.moveTo(shoulder.x + 6.2, shoulder.y + 4)
    ctx.lineTo(shoulder.x + 7.2, shoulder.y + 12)
    ctx.stroke()

    // ---- lit edges: soft accumulation of sky light, never a drawn outline ---------
    const WARM: Color = [240, 210, 162]
    ctx.globalCompositeOperation = 'source-atop'
    softDab(ctx, hx + 2.8, hy - 3.6, 2.6, 4.6, 0.2, WARM, 0.3)
    softDab(ctx, shoulder.x + 6.4, shoulder.y + 7, 3.4, 6.4, 0.15, WARM, 0.22)
    softDab(ctx, waist.x + 6, waist.y - 8, 3.8, 9, 0.1, WARM, 0.16)
    softDab(ctx, hemFront.x - 1.6, hemFront.y - 8, 3, 8, 0.08, WARM, 0.14)
    const frontFoot = footAt(true)
    softDab(ctx, frontFoot.x + 1, frontFoot.y - 12, 2.4, 8, 0, WARM, 0.14)
    softDab(ctx, frontFoot.x + 4, frontFoot.y - 2.4, 4, 2.6, 0, WARM, 0.16)
    softDab(ctx, shoulder.x + 4.4, shoulder.y + 6, 2.4, 3.2, 0, accentRgb, 0.16)
    ctx.globalCompositeOperation = 'source-over'

    if (this.grain) {
      ctx.globalCompositeOperation = 'source-atop'
      ctx.globalAlpha = 0.16
      ctx.fillStyle = this.grain
      ctx.fillRect(-BOX.ox, -BOX.oy, BOX.w, BOX.h)
      ctx.globalAlpha = 1
      ctx.globalCompositeOperation = 'source-over'
    }

    this.texture.refresh()
  }
}

/** Fine canvas grain, so the figure shares the texture of the painted backgrounds. */
function makeGrain(): CanvasPattern | null {
  const size = 48
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const ctx = canvas.getContext('2d')
  if (!ctx) return null
  const image = ctx.createImageData(size, size)
  for (let i = 0; i < image.data.length; i += 4) {
    const v = 128 + (Math.random() - 0.5) * 70
    image.data[i] = v
    image.data[i + 1] = v
    image.data[i + 2] = v
    image.data[i + 3] = 255
  }
  ctx.putImageData(image, 0, 0)
  return ctx.createPattern(canvas, 'repeat')
}
