import { INTERLUDES, INTRO, LEVELS, type NovelScript } from './content'
import { BUILD_EDITION } from './edition-build'

const envEdition = import.meta.env.VITE_GAME_EDITION
export const isBrief = envEdition ? envEdition === 'brief' : BUILD_EDITION === 'brief'
export const editionName = isBrief ? '简要体验版' : '正式分享版'

const BRIEF_INTRO: NovelScript = {
  title: '序章 · 西迁抉择',
  nodes: [
    {
      id: 'brief-a1', speaker: '竺可桢', chapter: '自述', date: '1937年11月', place: '杭州', scene: 'archive',
      text: '炮声渐近，图书、仪器与师生都在等待去向。我半生记录风云，此刻必须写下一项不能再由观测回答的选择：怎样让一所大学在战火中继续存在？', next: 'brief-a2',
    },
    {
      id: 'brief-a2', speaker: '竺可桢', chapter: '启程', date: '离校前夕', place: '杭州码头', scene: 'evacuation',
      text: '船位有限，我把位置先让给书箱；名单未尽，我留下接应最后一批师生。校舍可以失去，课堂不能中断。', next: 'brief-a3',
    },
    {
      id: 'brief-a3', speaker: '竺可桢', chapter: '抉择 · 同行', date: '汽笛响起之前', place: '启程', scene: 'evacuation',
      text: '最后一段路程即将开始。我可以独自回到书斋，也可以与师生共同启程。',
      choices: [
        { label: '回到气象研究', detail: '假设结局：把一生留给风云与观测', ending: 'scholar' },
        { label: '护送书箱，与师生共同启程', detail: '进入简要西迁旅程', ending: 'main' },
      ],
    },
  ],
}

const BRIEF_INTERLUDES: Record<number, NovelScript> = {
  0: {
    title: '途中 · 课堂不能中断',
    nodes: [
      { id: 'brief-j1', speaker: '竺可桢', chapter: '西迁自述', date: '1937—1940年', place: '西行途中', scene: 'evacuation', text: '从建德到泰和，从宜山到湄潭，车船与脚步把断开的路线重新接起。警报之后复课，庙宇之中求证，漫长的西迁终于守住了一所大学。', next: 'brief-j2' },
      { id: 'brief-j2', speaker: '竺可桢', chapter: '回到今天', date: '跨越八十余年', place: '浙江大学', scene: 'modern', text: '今日安放的课桌，曾被人从战火中一路护送。旧路已远，两问仍在回响。' },
    ],
  },
  4: {
    title: '终章前 · 大不自多',
    nodes: [
      { id: 'brief-z1', speaker: '竺可桢', chapter: '两问回响', date: '今天', place: '求是园', scene: 'modern', text: '“第一，到浙大来做什么？第二，将来毕业后要做什么样的人？”', quote: true, next: 'brief-z2' },
      { id: 'brief-z2', speaker: '竺可桢', chapter: '最后的取舍', date: '校歌墙前', place: '今天', scene: 'modern', text: '大不自多，海纳江河。我可以在此合上日记，也可以把校歌交给后来者。',
        choices: [
          { label: '合上日记', detail: '支线结局：把答案留给后来者', ending: 'archive' },
          { label: '让校歌响起', detail: '进入校歌音游', next: 'brief-z3' },
        ] },
      { id: 'brief-z3', speaker: '竺可桢', chapter: '终章', date: '现在', place: '把节拍交给后来者', scene: 'modern', text: '愿每一个音符都不只是准确的敲击，也是你们对“求是”二字的回答。' },
    ],
  },
}

export const activeIntro = isBrief ? BRIEF_INTRO : INTRO

export function activeInterlude(level: number): NovelScript {
  return (isBrief ? BRIEF_INTERLUDES[level] : INTERLUDES[level]) ?? INTERLUDES[level]
}

export function activeLevel(level: number) {
  const config = LEVELS[level]
  if (!isBrief) return config
  if (level === 0) return { ...config, duration: 16, speed: 300, relaxed: true }
  if (level === 4) return { ...config, duration: 14 }
  return config
}

export function nextRunnerLevel(level: number): number | null {
  if (isBrief) return level === 0 ? 4 : null
  return level < 4 ? level + 1 : null
}
