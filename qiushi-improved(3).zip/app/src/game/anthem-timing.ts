import chartData from './anthem-chart.json'

// Seconds from the start of the decoded recording to the first sung character.
// Demucs acoustic onset: 28.5125s, rounded to the requested 0.1s precision.
export const introOffset = 28.5

// Remove the chart's own anchor once. A retimed chart records its measured
// vocalOrigin; the original chart falls back to its first timestamped lyric.
export const chartVocalOrigin = (chartData as { vocalOrigin?: number }).vocalOrigin ?? chartData.lyrics[0].time

export function vocalTime(contextTime: number, startAt: number, outputLatency: number): number {
  return contextTime - startAt - outputLatency - introOffset
}

export function recordingTime(songTime: number): number {
  return songTime + introOffset
}

export function activePhraseIndex(phrases: ReadonlyArray<{ start: number; end: number }>, fileTime: number): number {
  return phrases.findIndex((phrase) => fileTime >= phrase.start && fileTime < phrase.end)
}
