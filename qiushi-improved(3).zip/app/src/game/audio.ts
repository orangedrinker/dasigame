/** Recorded sound assets with a synthesized fallback, plus adaptive atmosphere. */
import { readPreferences } from './preferences'
import { assetUrl } from './asset'
export type SfxId = 'move' | 'doubleJump' | 'land' | 'hit' | 'pickup' | 'ui' | 'explosion' | 'win' | 'lose' | 'step' | 'tick' | 'page' | 'scene'
export type MusicMood = 'wartime' | 'modern' | 'archive' | 'sorrow' | 'lantern' | 'rain' | 'alarm'

const MUTE_KEY = 'game.muted'
const scoreCache = new Map<string, AudioBuffer>()
const SAMPLE_PATHS: Partial<Record<SfxId, string>> = {
  move: '/audio/jump.mp3',
  doubleJump: '/audio/jump.mp3',
  land: '/audio/jump.mp3',
  hit: '/audio/hit.mp3',
  pickup: '/audio/pickup.mp3',
  ui: '/audio/ui.mp3',
  explosion: '/audio/explosion.mp3',
}

function readMuted(): boolean {
  try { return localStorage.getItem(MUTE_KEY) === '1' } catch { return false }
}

function writeMuted(value: boolean): void {
  try { localStorage.setItem(MUTE_KEY, value ? '1' : '0') } catch { /* the in-memory setting still works */ }
}

export class AudioSystem {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private musicOutput: GainNode | null = null
  private track: { source: AudioBufferSourceNode; gain: GainNode } | null = null
  private retiring = new Set<{ source: AudioBufferSourceNode; gain: GainNode }>()
  private requestId = 0
  private disposed = false
  private samples = new Map<string, AudioBuffer>()
  private sampleLoads = new Map<string, Promise<void>>()
  private interfaceCleanup?: () => void
  private currentMood: MusicMood | null = null
  muted = false

  private readonly unlock = () => {
    this.ensureCtx()
    this.detachUnlock()
  }

  private readonly syncMute = (event: Event) => {
    this.muted = (event as CustomEvent<boolean>).detail
    this.updateVolumes()
  }

  private readonly updateVolumes = () => {
    const prefs = readPreferences()
    if (this.master) this.master.gain.value = this.muted ? 0 : .5 * prefs.effects
    if (this.musicOutput) this.musicOutput.gain.value = this.muted ? 0 : .65 * prefs.music
  }

  constructor(withInterfaceSounds = false) {
    this.muted = readMuted()
    window.addEventListener('pointerdown', this.unlock)
    window.addEventListener('keydown', this.unlock)
    window.addEventListener('game-mute-change', this.syncMute)
    window.addEventListener('game-preferences-change', this.updateVolumes)
    if (withInterfaceSounds) {
      const onButton = (event: PointerEvent) => {
        const button = (event.target as Element | null)?.closest('button')
        if (button && !button.disabled) this.sfx('ui')
      }
      window.addEventListener('pointerdown', onButton)
      this.interfaceCleanup = () => window.removeEventListener('pointerdown', onButton)
    }
  }

  private detachUnlock(): void {
    window.removeEventListener('pointerdown', this.unlock)
    window.removeEventListener('keydown', this.unlock)
  }

  private detachMuteSync(): void {
    window.removeEventListener('game-mute-change', this.syncMute)
    window.removeEventListener('game-preferences-change', this.updateVolumes)
  }

  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    this.detachUnlock()
    this.detachMuteSync()
    this.interfaceCleanup?.()
    this.stopMusic(false)
    this.musicOutput?.disconnect()
    this.master?.disconnect()
    this.master = null
    const ctx = this.ctx
    this.ctx = null
    if (ctx && ctx.state !== 'closed') void ctx.close()
  }

  /** Warm up before the first gameplay key so input never pays decode/init costs. */
  prepare(): void {
    if (!this.disposed && !this.muted) this.ensureCtx()
  }

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext()
      this.master = this.ctx.createGain()
      this.master.connect(this.ctx.destination)
      this.musicOutput = this.ctx.createGain()
      this.musicOutput.connect(this.ctx.destination)
      this.updateVolumes()
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume()
    this.preloadSamples()
    return this.ctx
  }

  private preloadSamples(): void {
    const ctx = this.ctx
    if (!ctx || this.disposed) return
    Object.entries(SAMPLE_PATHS).forEach(([id, path]) => {
      if (!path || this.samples.has(path) || this.sampleLoads.has(path)) return
      const load = fetch(assetUrl(path))
        .then((response) => {
          if (!response.ok) throw new Error(`Audio asset ${response.status}`)
          return response.arrayBuffer()
        })
        .then((data) => ctx.decodeAudioData(data))
        .then((buffer) => { if (!this.disposed) this.samples.set(path, buffer) })
        .catch(() => { /* synthesized effects remain available if an asset cannot load */ })
        .finally(() => { this.sampleLoads.delete(path) })
      this.sampleLoads.set(path, load)
    })
  }

  private playSample(id: SfxId, buffer: AudioBuffer): void {
    if (!this.ctx || !this.master) return
    const source = this.ctx.createBufferSource()
    const gain = this.ctx.createGain()
    source.buffer = buffer
    source.playbackRate.value = id === 'doubleJump' ? 1.22 : id === 'land' ? 0.76 : 1
    gain.gain.value = id === 'ui' ? 0.55 : id === 'explosion' ? 0.68 : id === 'land' ? 0.28 : 0.62
    source.connect(gain).connect(this.master)
    source.start()
  }

  toggleMute(): boolean {
    this.muted = !this.muted
    writeMuted(this.muted)
    this.updateVolumes()
    window.dispatchEvent(new CustomEvent('game-mute-change', { detail: this.muted }))
    return this.muted
  }

  sfx(id: SfxId): void {
    if (this.disposed || this.muted) return
    const ctx = this.ensureCtx()
    if (!this.master) return
    const path = SAMPLE_PATHS[id]
    const sample = path ? this.samples.get(path) : undefined
    if (sample) {
      this.playSample(id, sample)
      return
    }
    const t = ctx.currentTime
    if (id === 'page' || id === 'scene') {
      // Page turn / scene transition: a soft noise sweep rather than a pitched blip.
      if (id === 'page') this.noiseSweep(t, 0.26, 0.05, 1500, 420)
      else this.noiseSweep(t, 0.55, 0.045, 320, 900)
      return
    }
    const spec: Record<SfxId, [type: OscillatorType, f0: number, f1: number, dur: number, gain: number]> = {
      move: ['triangle', 220, 180, 0.08, 0.12],
      doubleJump: ['triangle', 330, 540, 0.12, 0.15],
      land: ['triangle', 120, 72, 0.07, 0.09],
      hit: ['square', 160, 60, 0.12, 0.25],
      pickup: ['sine', 660, 990, 0.12, 0.22],
      ui: ['sine', 440, 520, 0.05, 0.15],
      explosion: ['sawtooth', 105, 28, 0.48, 0.32],
      win: ['sine', 523, 1046, 0.5, 0.28],
      lose: ['sawtooth', 220, 55, 0.6, 0.26],
      step: ['triangle', 100, 58, 0.055, 0.05],
      tick: ['square', 2100, 1500, 0.02, 0.014],
      page: ['sine', 440, 440, 0.01, 0], // handled above
      scene: ['sine', 440, 440, 0.01, 0], // handled above
    }
    const [type, f0, f1, dur, g] = spec[id]
    const osc = ctx.createOscillator()
    const env = ctx.createGain()
    osc.type = type
    osc.frequency.setValueAtTime(f0, t)
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur)
    env.gain.setValueAtTime(g, t)
    env.gain.exponentialRampToValueAtTime(0.001, t + dur)
    osc.connect(env).connect(this.master)
    osc.start(t)
    osc.stop(t + dur)
    if (id === 'explosion') this.noiseBurst(t, 0.42, 0.15)
  }

  private noiseBurst(at: number, duration: number, volume: number) {
    this.noiseSweep(at, duration, volume, 950, 120, 'lowpass')
  }

  private noiseSweep(at: number, duration: number, volume: number, f0: number, f1: number, filterType: BiquadFilterType = 'lowpass') {
    if (!this.ctx || !this.master) return
    const length = Math.floor(this.ctx.sampleRate * duration)
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate)
    const channel = buffer.getChannelData(0)
    let seed = 9173
    for (let i = 0; i < length; i += 1) {
      seed = (seed * 16807) % 2147483647
      channel[i] = ((seed / 2147483647) * 2 - 1) * (1 - i / length)
    }
    const source = this.ctx.createBufferSource()
    const filter = this.ctx.createBiquadFilter()
    const gain = this.ctx.createGain()
    source.buffer = buffer
    filter.type = filterType
    filter.frequency.setValueAtTime(f0, at)
    filter.frequency.exponentialRampToValueAtTime(Math.max(40, f1), at + duration)
    gain.gain.setValueAtTime(volume, at)
    gain.gain.exponentialRampToValueAtTime(0.001, at + duration)
    source.connect(filter).connect(gain).connect(this.master)
    source.start(at)
  }

  /** Original rendered chamber loops. New scenes crossfade over 800ms. */
  playMusic(mood: MusicMood): void {
    if (this.disposed || this.currentMood === mood) return
    this.currentMood = mood
    const request = ++this.requestId
    const ctx = this.ensureCtx()
    const load = async () => {
      let buffer = scoreCache.get(mood)
      if (!buffer) {
        const response = await fetch(assetUrl(`/audio/score-${mood}.mp3`))
        if (!response.ok) throw new Error(`Score ${response.status}`)
        buffer = await ctx.decodeAudioData(await response.arrayBuffer())
        scoreCache.set(mood, buffer)
      }
      if (this.disposed || request !== this.requestId || !this.musicOutput) return
      this.fadeTrack()
      const source = ctx.createBufferSource()
      const gain = ctx.createGain()
      source.buffer = buffer
      source.loop = true
      source.connect(gain).connect(this.musicOutput)
      gain.gain.setValueAtTime(0, ctx.currentTime)
      gain.gain.linearRampToValueAtTime(.8, ctx.currentTime + .8)
      source.start()
      this.track = { source, gain }
    }
    void load().catch(() => { if (request === this.requestId) this.currentMood = null })
  }
  startMusic(mood: MusicMood = 'wartime') { this.playMusic(mood) }
  private fadeTrack(fade = true) {
    const track = this.track
    if (!track || !this.ctx) return
    this.track = null
    const at = this.ctx.currentTime
    track.gain.gain.cancelScheduledValues(at)
    track.gain.gain.setValueAtTime(track.gain.gain.value, at)
    track.gain.gain.linearRampToValueAtTime(0, at + (fade ? .8 : .01))
    this.retiring.add(track)
    track.source.onended = () => { track.source.disconnect(); track.gain.disconnect(); this.retiring.delete(track) }
    try { track.source.stop(at + (fade ? .85 : .02)) } catch { /* already stopped */ }
  }
  setPaused(paused: boolean) {
    if (!this.ctx) return
    if (paused && this.ctx.state === 'running') void this.ctx.suspend()
    if (!paused && this.ctx.state === 'suspended') void this.ctx.resume()
  }
  stopMusic(fade = true) {
    ++this.requestId
    this.currentMood = null
    this.fadeTrack(fade)
    if (!fade) for (const track of this.retiring) {
      try { track.source.stop() } catch { /* already stopped */ }
      track.source.disconnect(); track.gain.disconnect()
    }
  }
}
export const uiAudio = new AudioSystem(true)
