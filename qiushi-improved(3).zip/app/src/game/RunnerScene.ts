import Phaser from 'phaser'
import { RunnerAvatar } from './RunnerAvatar'
import { assetUrl } from './asset'
import { AudioSystem, type MusicMood } from './audio'
import type { LevelConfig } from './content'
import type { GameEvent } from './types'

type ObstacleKind = 'mine' | 'barrier' | 'shell' | 'rock'
type Obstacle = {
  obj: Phaser.GameObjects.Container
  kind: ObstacleKind
  w: number
  h: number
  hit: boolean
}
type Seal = { obj: Phaser.GameObjects.Container; taken: boolean }
type Spawn = { time: number; kind: ObstacleKind | 'seal' | 'sealHigh' }

const BACKGROUNDS = ['jiande', 'taihe', 'yishan', 'meitan', 'modern']
/** 每关的音乐氛围：建德/泰和为战时跋涉，宜山叠加风雨与警报，湄潭转为灯火暖意，现代校园明亮。 */
const LEVEL_MOODS: MusicMood[] = ['wartime', 'wartime', 'rain', 'lantern', 'modern']

/** Fixed physics step (120Hz): motion speed stays uniform even when the frame rate fluctuates. */
const PHYSICS_STEP = 1 / 120
/** A jump pressed slightly before landing still fires on touchdown. */
const JUMP_BUFFER = 0.13
/** A jump pressed just after running off the ground still counts as a ground jump. */
const COYOTE_TIME = 0.1

function seeded(seed: number) {
  let n = seed >>> 0
  return () => {
    n += 0x6d2b79f5
    let t = n
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export class RunnerScene extends Phaser.Scene {
  private configData!: { level: LevelConfig; levelIndex: number; onEvent: (event: GameEvent) => void }
  private player!: Phaser.GameObjects.Container
  private avatar!: RunnerAvatar
  private idleClock = 0
  private previousBottom = 0
  private playerShadow!: Phaser.GameObjects.Ellipse
  private groundY = 0
  private playerBottom = 0
  private vy = 0
  private jumpsLeft = 2
  private ducking = false
  private touchDuck = false
  private onGround = true
  private obstacles: Obstacle[] = []
  private seals: Seal[] = []
  private plan: Spawn[] = []
  private planIndex = 0
  private elapsed = 0
  private health = 3
  private score = 0
  private sealCount = 0
  private invincible = 0
  private ended = false
  private paused = false
  private started = false
  private hud!: Phaser.GameObjects.Graphics
  private titleText!: Phaser.GameObjects.Text
  private statText!: Phaser.GameObjects.Text
  private hintText!: Phaser.GameObjects.Text
  private progressText!: Phaser.GameObjects.Text
  private audio!: AudioSystem
  private far!: Phaser.GameObjects.TileSprite
  private near!: Phaser.GameObjects.TileSprite
  private shade!: Phaser.GameObjects.Rectangle
  private weather?: Phaser.GameObjects.Graphics
  private keyDown?: Phaser.Input.Keyboard.Key
  private keyP?: Phaser.Input.Keyboard.Key
  private keyEsc?: Phaser.Input.Keyboard.Key
  private hudClock = 0
  private artilleryClock = 2
  private effectRandom: () => number = () => 0.5
  private musicStartTimer = 0
  private lastStatText = ''
  private lastProgressText = ''
  private footstepPhase = 0
  private stepAcc = 0
  private jumpBuffer = 0
  private lastGrounded = -1
  private duckHeld = false
  private readonly nativeKeyDown = (event: KeyboardEvent) => this.onNativeKeyDown(event)
  private readonly nativeKeyUp = (event: KeyboardEvent) => this.onNativeKeyUp(event)

  constructor() {
    super('runner')
  }

  init(data: { level: LevelConfig; levelIndex: number; onEvent: (event: GameEvent) => void }) {
    this.configData = data
    this.audio = new AudioSystem()
    this.obstacles = []
    this.seals = []
    this.plan = []
    this.planIndex = 0
    this.elapsed = 0
    this.health = 3
    this.score = 0
    this.sealCount = 0
    this.invincible = 0
    this.ended = false
    this.paused = false
    this.started = false
    this.ducking = false
    this.touchDuck = false
    this.vy = 0
    this.jumpsLeft = 2
    this.onGround = true
    this.stepAcc = 0
    this.footstepPhase = 0
    this.jumpBuffer = 0
    this.lastGrounded = -1
    this.duckHeld = false
    this.artilleryClock = 1.6
    window.clearTimeout(this.musicStartTimer)
    this.musicStartTimer = 0
    this.lastStatText = ''
    this.lastProgressText = ''
    this.effectRandom = seeded(7127 + data.levelIndex * 977)
  }

  preload() {
    const background = BACKGROUNDS[this.configData.levelIndex] ?? BACKGROUNDS[0]
    this.load.image('runner-bg', assetUrl(`/art/${background}.webp`))
    this.load.image('painted-rock', assetUrl('/art/rock.webp'))
    this.load.image('painted-mine', assetUrl('/art/mine.webp'))
  }

  create() {
    const level = this.configData.level
    this.cameras.main.setBackgroundColor(level.modern ? 0x18262b : 0x080d10)
    this.groundY = Math.round(this.scale.height * (this.scale.width < 600 ? 0.7 : 0.75))
    this.playerBottom = this.groundY
    this.audio.prepare()
    this.createLandscape()
    this.createPlayer()
    this.createHud()
    this.drawHud()
    this.createPlan()
    this.createInput()
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this)
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this)
    window.__GAME_READY__ = true
    window.__gameProbe = () => ({
      x: this.player?.x ?? 0,
      y: this.playerBottom,
      z: 0,
      health: this.health,
      grounded: this.onGround,
      ducking: this.ducking,
      elapsed: this.elapsed,
      jumpsLeft: this.jumpsLeft,
      obstacles: this.obstacles.map((obstacle) => ({ x: obstacle.obj.x, kind: obstacle.kind })),
    })
  }

  private createLandscape() {
    const w = this.scale.width
    const h = this.scale.height
    const level = this.configData.level
    this.far = this.add.tileSprite(0, 0, w, h, 'runner-bg').setOrigin(0, 0).setDepth(-30)
    this.layoutBackground()
    this.shade = this.add.rectangle(0, 0, w, h, 0x020608, level.modern ? 0.08 : 0.25).setOrigin(0, 0).setDepth(-25)

    const vignette = this.add.graphics().setDepth(-24)
    const bandHeight = Math.max(70, h * 0.14) / 7
    for (let i = 0; i < 7; i += 1) {
      const alpha = (level.modern ? 0.15 : 0.38) * (1 - i / 7)
      vignette.fillStyle(0x010304, alpha)
      vignette.fillRect(0, i * bandHeight, w, bandHeight + 1)
    }
    vignette.fillStyle(0x010304, level.modern ? 0.08 : 0.2)
    vignette.fillRect(0, 0, Math.max(35, w * 0.06), h)
    vignette.fillRect(w - Math.max(35, w * 0.06), 0, Math.max(35, w * 0.06), h)

    if (!this.textures.exists('mud-ground')) {
      const near = this.add.graphics()
      near.fillStyle(0x111817, 1)
      near.fillRect(0, 0, 512, 160)
      near.fillStyle(0x29302a, 0.85)
      near.fillRect(0, 0, 512, 5)
      near.lineStyle(2, 0x7c7158, 0.22)
      for (let x = 8; x < 512; x += 37) {
        near.beginPath()
        near.moveTo(x, 13 + (x % 4) * 4)
        near.lineTo(x + 23, 10 + (x % 3) * 5)
        near.strokePath()
      }
      near.fillStyle(0x050909, 0.34)
      for (let x = 0; x < 512; x += 53) near.fillEllipse(x + 17, 52 + (x % 5) * 13, 42, 9)
      near.generateTexture('mud-ground', 512, 160)
      near.destroy()
    }
    this.near = this.add.tileSprite(0, this.groundY, w, Math.max(160, h - this.groundY), 'mud-ground').setOrigin(0, 0).setDepth(5)

    if (this.configData.levelIndex === 2) {
      this.weather = this.add.graphics().setDepth(20)
      this.weather.lineStyle(1, 0xb8c4c2, 0.24)
      for (let i = 0; i < 85; i += 1) {
        const x = (i * 83) % Math.max(1, w)
        const y = (i * 47) % Math.max(1, h)
        this.weather.beginPath()
        this.weather.moveTo(x, y)
        this.weather.lineTo(x - 10, y + 28)
        this.weather.strokePath()
      }
    }
  }

  private layoutBackground() {
    if (!this.far) return
    const scale = Math.max(this.scale.width / 1600, this.scale.height / 840)
    this.far.setSize(this.scale.width, this.scale.height).setTileScale(scale, scale)
  }

  private createPlayer() {
    const x = Math.max(74, this.scale.width * 0.15)
    this.playerShadow = this.add.ellipse(x, this.groundY + 5, 64, 13, 0x000000, 0.48).setDepth(8)
    this.player = this.add.container(x, this.groundY).setDepth(10)
    this.avatar = new RunnerAvatar(this)
    this.player.add(this.avatar.art)
    this.previousBottom = this.groundY
    this.idleClock = 0
  }

  private createHud() {
    const pad = this.scale.width < 600 ? 18 : 32
    this.titleText = this.add.text(pad, 24, `${this.configData.level.year}  ${this.configData.level.name}`, {
      resolution: 2, fontFamily: 'Noto Serif SC, Songti SC, serif', fontSize: this.scale.width < 600 ? '19px' : '25px', color: '#fff8e9', fontStyle: 'bold',
    }).setDepth(30).setStroke('#071013', 3).setShadow(0, 2, '#000000', 6)
    this.statText = this.add.text(this.scale.width - pad, 26, '', {
      resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: this.scale.width < 600 ? '15px' : '18px', color: '#fff8e9', align: 'right', fontStyle: 'bold',
    }).setOrigin(1, 0).setDepth(30).setStroke('#071013', 2).setShadow(0, 2, '#000000', 5)
    this.hintText = this.add.text(this.scale.width / 2, 64, '空格 / ↑ 二段跳跃    ↓ 下蹲    P 暂停', {
      resolution: 2, fontFamily: 'Noto Sans SC, sans-serif', fontSize: '15px', color: '#fff8e9', fontStyle: 'bold',
    }).setOrigin(0.5, 0).setDepth(30).setStroke('#071013', 3).setShadow(0, 2, '#000000', 5).setAlpha(this.scale.width < 600 ? 0 : 1)
    this.progressText = this.add.text(this.scale.width / 2, this.scale.width < 600 ? 62 : 28, '0%', {
      resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: '14px', color: '#fff8e9', fontStyle: 'bold',
    }).setOrigin(0.5, 0).setDepth(30).setStroke('#071013', 2).setShadow(0, 2, '#000000', 4)
    this.hud = this.add.graphics().setDepth(29)
  }

  private createInput() {
    if (this.input.keyboard) {
      this.keyDown = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.DOWN)
      this.keyP = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.P)
      this.keyEsc = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC)
    }
    // Native window listeners fire on the DOM event itself; Phaser's keyboard plugin only
    // dispatches its queued events once per game step, which adds up to a full frame of input lag.
    window.addEventListener('keydown', this.nativeKeyDown)
    window.addEventListener('keyup', this.nativeKeyUp)
    window.addEventListener('blur', this.handleBlur)
    document.addEventListener('visibilitychange', this.handleVisibility)
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      if (pointer.y < this.scale.height * 0.72) this.jump()
    })
  }

  private readonly handleBlur = () => { if (this.started && !this.ended) this.setPaused(true) }
  private readonly handleVisibility = () => { if (document.hidden) this.handleBlur() }

  private onNativeKeyDown(event: KeyboardEvent) {
    if ((event.target as Element | null)?.closest('dialog, input, select, button')) return
    if (['Space', 'ArrowUp', 'ArrowDown'].includes(event.code)) event.preventDefault()
    if ((event.code === 'Space' || event.code === 'ArrowUp') && !event.repeat) this.jump()
    if (event.code === 'ArrowDown') {
      this.duckHeld = true
      this.ducking = this.onGround && !this.paused && !this.ended
    }
    if ((event.code === 'KeyP' || event.code === 'Escape') && !event.repeat) this.setPaused(!this.paused)
  }

  private onNativeKeyUp(event: KeyboardEvent) {
    if (event.code !== 'ArrowDown') return
    event.preventDefault()
    this.duckHeld = false
    this.ducking = this.touchDuck && this.onGround && !this.paused && !this.ended
  }

  private createPlan() {
    const level = this.configData.level
    const index = this.configData.levelIndex
    const random = seeded(1937 + index * 83)
    let time = 2.05
    while (time < level.duration - 1.25) {
      if (level.modern) {
        this.plan.push({ time, kind: random() > 0.48 ? 'sealHigh' : 'seal' })
        time += 1.02 + random() * 0.48
        continue
      }
      const roll = random()
      let kind: ObstacleKind = 'rock'
      if (index === 0) kind = roll > 0.72 ? 'mine' : roll > 0.4 ? 'barrier' : 'rock'
      if (index === 1) kind = roll > 0.76 ? 'shell' : roll > 0.49 ? 'mine' : roll > 0.24 ? 'barrier' : 'rock'
      if (index === 2) kind = roll > 0.55 ? 'shell' : roll > 0.27 ? 'mine' : 'rock'
      if (index === 3) kind = roll > 0.72 ? 'shell' : roll > 0.43 ? 'mine' : 'rock'
      this.plan.push({ time, kind })
      const clusterGap = index === 0 ? 0.38 : 0.34
      const clusterThreshold = index === 0 ? 0.68 : 0.52
      if (!level.relaxed && kind !== 'shell' && random() > clusterThreshold && time + clusterGap < level.duration - 1.25) {
        this.plan.push({ time: time + clusterGap, kind: random() > 0.48 ? 'mine' : 'rock' })
      }
      if (random() > 0.34) this.plan.push({ time: time + 0.48, kind: random() > 0.57 ? 'sealHigh' : 'seal' })
      const baseGap = [1.5, 1.32, 1.18, 1.08][index] ?? 1.2
      time += level.relaxed ? 2.05 + random() * 0.35 : Math.max(0.96, baseGap) + random() * 0.42
    }
    this.plan.sort((a, b) => a.time - b.time)
  }

  private spawn(kind: Spawn['kind']) {
    if (kind === 'seal' || kind === 'sealHigh') {
      const y = this.groundY - (kind === 'sealHigh' ? 142 : 92)
      const obj = this.add.container(this.scale.width + 50, y).setDepth(8)
      const glow = this.add.circle(0, 0, 19, this.configData.level.accent, 0.16)
      const diamond = this.add.rectangle(0, 0, 18, 18, this.configData.level.accent).setRotation(Math.PI / 4)
      const core = this.add.circle(0, 0, 4, 0xffedb5)
      obj.add([glow, diamond, core])
      this.seals.push({ obj, taken: false })
      return
    }
    const dims: Record<ObstacleKind, [number, number]> = {
      mine: [50, 32], barrier: [46, 72], shell: [58, 22], rock: [64, 52],
    }
    const [w, h] = dims[kind]
    const bottom = kind === 'shell' ? this.groundY - 58 : this.groundY
    const obj = this.add.container(this.scale.width + 70, bottom - h / 2).setDepth(9)
    if (kind === 'mine') {
      const mine = this.add.image(0, -4, 'painted-mine').setDisplaySize(59, 52)
      const warning = this.add.circle(14, -14, 3, 0xd86b43, 0.8)
      this.tweens.add({ targets: warning, alpha: 0.15, duration: 240, yoyo: true, repeat: -1 })
      obj.add([mine, warning])
    } else if (kind === 'rock' || kind === 'barrier') {
      const rock = this.add.image(0, kind === 'barrier' ? -5 : 0, 'painted-rock')
      rock.setDisplaySize(kind === 'barrier' ? 62 : 82, kind === 'barrier' ? 92 : 67)
      obj.add(rock)
    } else {
      obj.add(this.add.ellipse(0, 0, w, h, 0x252a2c).setStrokeStyle(2, 0xa96142))
      const flame = this.add.triangle(-39, 0, -19, -11, -19, 11, -57, 0, 0xe26337, 0.9)
      const core = this.add.triangle(-30, 0, -18, -6, -18, 6, -43, 0, 0xffc06a, 0.9)
      obj.add([flame, core])
    }
    this.obstacles.push({ obj, kind, w, h, hit: false })
  }

  jump() {
    if (this.paused || this.ended) return
    // A press that cannot fire right now is remembered briefly: landing within the buffer
    // window takes off on the exact touchdown step, so late-presses never feel eaten.
    this.jumpBuffer = JUMP_BUFFER
    this.tryBufferedJump()
  }

  private tryBufferedJump() {
    if (this.jumpBuffer <= 0 || this.paused || this.ended) return
    // Coyote time: a press within a few frames of leaving the ground still counts as a ground jump.
    const groundedJump = this.onGround || (this.jumpsLeft === 2 && this.elapsed - this.lastGrounded <= COYOTE_TIME)
    if (!groundedJump && this.jumpsLeft <= 0) return // stays buffered; retried on landing
    this.jumpBuffer = 0
    const firstStart = !this.started
    this.started = true
    // Physics always runs before effects: a slow audio device cannot delay takeoff.
    this.vy = groundedJump ? -850 : -770
    this.jumpsLeft = groundedJump ? 1 : 0
    this.onGround = false
    this.ducking = false
    if (firstStart && !this.audio.muted) {
      window.clearTimeout(this.musicStartTimer)
      this.musicStartTimer = window.setTimeout(() => {
        this.musicStartTimer = 0
        if (!this.ended) this.audio.startMusic(this.musicMood())
      }, 48)
    }
    this.audio.sfx(groundedJump ? 'move' : 'doubleJump')
    if (!groundedJump) {
      const ring = this.add.ellipse(this.player.x, this.playerBottom - 10, 42, 13).setStrokeStyle(2, 0xe9c77c, 0.72).setDepth(8)
      this.tweens.add({ targets: ring, scaleX: 2.1, scaleY: 1.7, alpha: 0, duration: 240, onComplete: () => ring.destroy() })
    }
  }

  setDuck(value: boolean) {
    this.touchDuck = value
    this.ducking = (value || this.duckHeld || Boolean(this.keyDown?.isDown)) && this.onGround && !this.paused && !this.ended
  }

  setPaused(value: boolean) {
    if (this.ended) return
    if (this.paused === value) return
    this.paused = value
    this.audio.setPaused(value)
    if (value) { this.duckHeld = false; this.touchDuck = false; this.ducking = false }
    this.configData.onEvent({ type: 'paused', paused: value })
  }

  private musicMood(): MusicMood {
    return LEVEL_MOODS[this.configData.levelIndex] ?? 'wartime'
  }

  toggleMute() {
    const muted = this.audio.toggleMute()
    if (!muted && this.started) this.audio.startMusic(this.musicMood())
    return muted
  }

  private currentSpeed() {
    const level = this.configData.level
    return level.speed * Math.min(1.2, 1 + this.elapsed / level.duration * 0.2)
  }

  update(_time: number, delta: number) {
    if (!this.player || this.paused || this.ended) return
    const frameDt = Math.min(delta / 1000, 0.1)
    this.idleClock += frameDt
    if (!this.started) {
      this.animatePlayer(frameDt)
      return
    }
    // Gameplay advances in fixed 120Hz steps: a dropped frame slows nothing down,
    // it just runs more steps, so obstacle speed and jump arcs stay uniform.
    this.stepAcc += frameDt
    let steps = 0
    while (this.stepAcc >= PHYSICS_STEP && steps < 12) {
      this.stepAcc -= PHYSICS_STEP
      this.stepPhysics(PHYSICS_STEP)
      steps += 1
      if (this.ended) { this.stepAcc = 0; break }
    }
    if (steps >= 12) this.stepAcc = 0

    // Per-frame presentation only: parallax, squash/stretch, shadow, HUD.
    const speed = this.currentSpeed()
    this.far.tilePositionX += speed * frameDt * 0.035
    this.near.tilePositionX += speed * frameDt * 0.5
    if (this.weather) this.weather.y = (this.weather.y + speed * frameDt * 0.72) % 40
    this.player.y = Phaser.Math.Linear(this.previousBottom, this.playerBottom, this.stepAcc / PHYSICS_STEP)
    const jumpHeight = Math.max(0, this.groundY - this.playerBottom)
    this.playerShadow.setPosition(this.player.x, this.groundY + 5)
    this.playerShadow.setScale(Math.max(0.45, 1 - jumpHeight / 280), Math.max(0.55, 1 - jumpHeight / 340))
    this.playerShadow.alpha = Math.max(0.15, 0.48 - jumpHeight / 400)
    this.animatePlayer(frameDt)

    // 脚步声：与奔跑摆动同一相位，每个半步一声轻响
    if (this.started && this.onGround && !this.ducking) {
      const phase = Math.floor((this.elapsed * 15) / Math.PI)
      if (phase !== this.footstepPhase) {
        this.footstepPhase = phase
        this.audio.sfx('step')
      }
    }

    this.hudClock += frameDt
    if (this.hudClock > 0.1) {
      this.hudClock = 0
      this.drawHud()
    }
  }

  private stepPhysics(dt: number) {
    this.elapsed += dt
    this.jumpBuffer = Math.max(0, this.jumpBuffer - dt)
    this.invincible = Math.max(0, this.invincible - dt)
    const level = this.configData.level
    const speed = this.currentSpeed()

    if (!level.modern) {
      this.artilleryClock -= dt
      if (this.artilleryClock <= 0) {
        this.spawnArtillery()
        this.artilleryClock = 2.1 + this.effectRandom() * 2.5
      }
    }

    while (this.planIndex < this.plan.length && this.plan[this.planIndex].time <= this.elapsed) {
      this.spawn(this.plan[this.planIndex].kind)
      this.planIndex += 1
    }

    this.ducking = (this.touchDuck || this.duckHeld || Boolean(this.keyDown?.isDown)) && this.onGround
    this.previousBottom = this.playerBottom
    this.vy += 1850 * dt
    this.playerBottom += this.vy * dt
    if (this.onGround) this.lastGrounded = this.elapsed
    if (this.playerBottom >= this.groundY) {
      const landed = !this.onGround
      this.playerBottom = this.groundY
      this.vy = 0
      this.onGround = true
      this.jumpsLeft = 2
      this.lastGrounded = this.elapsed
      if (landed) { this.audio.sfx('land'); this.avatar.landed() }
      this.tryBufferedJump()
    }

    const playerW = this.ducking ? 54 : 34
    const playerH = this.ducking ? 42 : 94
    const px = this.player.x
    const pTop = this.playerBottom - playerH

    for (let i = this.obstacles.length - 1; i >= 0; i -= 1) {
      const ob = this.obstacles[i]
      ob.obj.x -= speed * dt
      if (ob.kind === 'shell') ob.obj.rotation = Math.sin(this.elapsed * 13 + i) * 0.035
      if (ob.obj.x < -100) {
        ob.obj.destroy()
        this.obstacles.splice(i, 1)
        continue
      }
      const obBottom = ob.obj.y + ob.h / 2
      const overlap = px + playerW / 2 > ob.obj.x - ob.w / 2 && px - playerW / 2 < ob.obj.x + ob.w / 2 && this.playerBottom > obBottom - ob.h && pTop < obBottom
      if (overlap && !ob.hit && this.invincible <= 0) {
        ob.hit = true
        this.takeHit()
      }
    }

    for (let i = this.seals.length - 1; i >= 0; i -= 1) {
      const seal = this.seals[i]
      seal.obj.x -= speed * dt
      seal.obj.rotation += dt * 0.8
      seal.obj.scale = 1 + Math.sin(this.elapsed * 5 + i) * 0.08
      if (seal.obj.x < -50) {
        seal.obj.destroy()
        this.seals.splice(i, 1)
        continue
      }
      const dx = seal.obj.x - px
      const dy = seal.obj.y - (this.playerBottom - playerH * 0.55)
      if (!seal.taken && Math.abs(dx) < 40 && Math.abs(dy) < 48) {
        seal.taken = true
        this.sealCount += 1
        this.score += 120
        this.audio.sfx('pickup')
        this.tweens.add({ targets: seal.obj, scale: 1.8, alpha: 0, duration: 180, onComplete: () => seal.obj.destroy() })
        this.seals.splice(i, 1)
      }
    }

    if (this.elapsed >= level.duration) {
      this.ended = true
      this.score += this.health * 250 + Math.round(level.duration * 10)
      this.audio.sfx('win')
      this.cameras.main.flash(350, 238, 220, 174)
      this.configData.onEvent({ type: 'complete', score: this.score, seals: this.sealCount })
    }
  }

  private spawnArtillery() {
    const w = this.scale.width
    const x = w * (0.52 + this.effectRandom() * 0.42)
    const y = this.groundY - 80 - this.effectRandom() * Math.max(80, this.groundY * 0.38)
    const tracer = this.add.rectangle(x + 110, y - 70, 150, 3, 0xeaa061, 0.65).setOrigin(1, 0.5).setRotation(0.48).setDepth(-18)
    this.tweens.add({ targets: tracer, x: x + 12, y: y - 6, alpha: 0, duration: 240, onComplete: () => tracer.destroy() })
    this.time.delayedCall(170, () => {
      if (this.ended) return
      this.createExplosion(x, y, false)
      if (this.effectRandom() > 0.42) this.audio.sfx('explosion')
    })
  }

  private createExplosion(x: number, y: number, close: boolean) {
    const flash = this.add.circle(x, y, close ? 18 : 10, 0xffd28a, 0.96).setDepth(close ? 15 : -17)
    const fire = this.add.circle(x, y, close ? 30 : 19, 0xc64d28, 0.8).setDepth(close ? 14 : -18)
    this.tweens.add({ targets: flash, scale: close ? 4.8 : 3.4, alpha: 0, duration: 260, onComplete: () => flash.destroy() })
    this.tweens.add({ targets: fire, scale: close ? 3.2 : 2.5, alpha: 0, duration: 430, onComplete: () => fire.destroy() })
    for (let i = 0; i < 7; i += 1) {
      const angle = this.effectRandom() * Math.PI * 2
      const distance = 25 + this.effectRandom() * (close ? 85 : 55)
      const smoke = this.add.circle(x, y, 10 + this.effectRandom() * 13, i % 2 ? 0x242827 : 0x4a453b, 0.6).setDepth(close ? 13 : -19)
      this.tweens.add({
        targets: smoke,
        x: x + Math.cos(angle) * distance,
        y: y + Math.sin(angle) * distance - 34,
        scale: 2.2,
        alpha: 0,
        duration: 650 + this.effectRandom() * 450,
        onComplete: () => smoke.destroy(),
      })
    }
  }

  private animatePlayer(dt: number) {
    this.avatar.draw(dt, this.started ? this.elapsed : this.idleClock, this.started, !this.onGround, this.ducking, this.vy, this.configData.level.accent)
    this.player.alpha = this.invincible > 0 && Math.sin(this.invincible * 32) > 0 ? .3 : 1
  }

  private takeHit() {
    this.health -= 1
    this.invincible = 1.35
    this.score = Math.max(0, this.score - 100)
    this.audio.sfx('explosion')
    this.createExplosion(this.player.x + 24, this.playerBottom - 34, true)
    this.cameras.main.shake(230, 0.016)
    this.cameras.main.flash(130, 222, 91, 67)
    if (this.health <= 0) {
      this.ended = true
      this.audio.sfx('lose')
      this.configData.onEvent({ type: 'gameover', score: this.score })
    }
  }

  private drawHud() {
    const w = this.scale.width
    const progress = Math.min(1, this.elapsed / this.configData.level.duration)
    const stat = `灯火 ${'◆'.repeat(Math.max(0, this.health))}${'◇'.repeat(Math.max(0, 3 - this.health))}\n${String(this.score).padStart(5, '0')}  印记 ${this.sealCount}`
    const progressLabel = `${Math.floor(progress * 100)}%`
    if (stat !== this.lastStatText) {
      this.lastStatText = stat
      this.statText.setText(stat)
    }
    if (progressLabel !== this.lastProgressText) {
      this.lastProgressText = progressLabel
      this.progressText.setText(progressLabel)
    }
    this.hud.clear()
    this.hud.fillStyle(0x03090c, 0.7)
    this.hud.fillRect(w < 600 ? 8 : 20, 14, Math.min(w * 0.62, 430), 48)
    if (w >= 600) this.hud.fillRect(w / 2 - 205, 57, 410, 35)
    this.hud.fillStyle(0x071013, 0.78)
    this.hud.fillRect(w * 0.25, w < 600 ? 88 : 52, w * 0.5, 5)
    this.hud.fillStyle(this.configData.level.accent, 1)
    this.hud.fillRect(w * 0.25, w < 600 ? 88 : 52, w * 0.5 * progress, 5)
  }

  private onResize(gameSize: Phaser.Structs.Size) {
    const oldGround = this.groundY
    this.groundY = Math.round(gameSize.height * (gameSize.width < 600 ? 0.7 : 0.75))
    const diff = this.groundY - oldGround
    this.playerBottom += diff
    this.previousBottom += diff
    this.player.x = Math.max(74, gameSize.width * 0.15)
    this.layoutBackground()
    this.shade.setSize(gameSize.width, gameSize.height)
    this.near.setSize(gameSize.width, Math.max(160, gameSize.height - this.groundY)).setPosition(0, this.groundY)
    this.titleText.setPosition(gameSize.width < 600 ? 18 : 32, 24)
    this.statText.setPosition(gameSize.width - (gameSize.width < 600 ? 18 : 32), 26)
    this.progressText.setPosition(gameSize.width / 2, gameSize.width < 600 ? 62 : 28)
    this.hintText.setPosition(gameSize.width / 2, 64).setAlpha(gameSize.width < 600 ? 0 : 1)
  }

  private shutdown() {
    window.clearTimeout(this.musicStartTimer)
    this.musicStartTimer = 0
    this.scale.off(Phaser.Scale.Events.RESIZE, this.onResize, this)
    window.removeEventListener('keydown', this.nativeKeyDown)
    window.removeEventListener('keyup', this.nativeKeyUp)
    window.removeEventListener('blur', this.handleBlur)
    document.removeEventListener('visibilitychange', this.handleVisibility)
    this.audio.dispose()
    delete window.__gameProbe
    window.__GAME_READY__ = false
  }
}
