export type NovelChoice = {
  label: string
  detail?: string
  next?: string
  ending?: EndingId
}

export type NovelScene =
  | 'archive'
  | 'hangzhou'
  | 'evacuation'
  | 'jiande'
  | 'taihe'
  | 'family'
  | 'yishan'
  | 'shelter'
  | 'meitan'
  | 'modern'

export type NovelNode = {
  id: string
  speaker: string
  text: string
  chapter: string
  date: string
  place: string
  scene: NovelScene
  quote?: boolean
  note?: string
  choices?: NovelChoice[]
  next?: string
}

export type NovelScript = {
  title: string
  nodes: NovelNode[]
}

const FIRST_PERSON_NOTE = '以竺可桢第一视角进行历史题材演绎；内心活动与假设分支不是日记原文。'

export const INTRO: NovelScript = {
  title: '序章 · 国难中的选择',
  nodes: [
    {
      id: 'a1', speaker: '竺可桢', chapter: '自述', date: '1936年', place: '杭州', scene: 'archive',
      text: '我半生测量风云，以为科学最要紧的是如实记录。来到浙大以后才明白，记录之外还有责任：国家多难，一所大学应当把什么样的人交给未来？',
      note: FIRST_PERSON_NOTE, next: 'a2',
    },
    {
      id: 'a2', speaker: '竺可桢', chapter: '抉择一 · 受命', date: '1936年4月', place: '校长办公室', scene: 'hangzhou',
      text: '校长之约摆在案头。回到书斋，我可以继续专研气象；留下，则要把一所学校的安危放在自己肩头。',
      choices: [
        { label: '谢绝校长之约，回到气象研究', detail: '假设结局：把一生留给风云与观测', ending: 'scholar' },
        { label: '接受任命，与浙大师生共进退', detail: '历史主线：承担起一所大学的责任', next: 'a3' },
      ],
    },
    {
      id: 'a3', speaker: '竺可桢', chapter: '战火逼近', date: '1937年11月', place: '杭州校园', scene: 'hangzhou',
      text: '炮声一天比一天近。楼道里堆满木箱，图书、仪器和师生的行李都在等待去向。我仍问学生：到浙大来做什么？将来毕业后要做什么样的人？可此刻，我必须先回答自己的两问。',
      note: '“竺可桢两问”为公开史料中的著名讲话内容；此处情境为剧情演绎。', next: 'a4',
    },
    {
      id: 'a4', speaker: '竺可桢', chapter: '抉择二 · 去留', date: '1937年11月', place: '离校前夕', scene: 'hangzhou',
      text: '有人劝我，杭州不能没有主持校务的人；也有人说，只有立刻西迁，学校才有继续上课的可能。留下是坚守，离开也是坚守。',
      choices: [
        { label: '留在杭州，守住眼前的校舍', detail: '假设结局：与孤城共存', ending: 'hangzhou' },
        { label: '组织西迁，把课堂带到安全的地方', detail: '历史主线：校舍可以失去，大学不能停办', next: 'b1' },
      ],
    },
    {
      id: 'b1', speaker: '竺可桢', chapter: '装箱', date: '1937年11月', place: '图书与仪器暂存处', scene: 'evacuation',
      text: '船位有限，车次无多。每只木箱都要称重，每个人的行李都不能太多。书箱里是多年的积累，我的皮箱里却只有几件换洗衣物与家书。', next: 'b2',
    },
    {
      id: 'b2', speaker: '竺可桢', chapter: '抉择三 · 轻重', date: '出发前一小时', place: '码头', scene: 'evacuation',
      text: '最后一辆车还能再装一只箱子。我可以先安顿自己的家眷与行李，也可以把位置让给图书和仪器。所谓轻重，平时写在纸上，战时却压在选择里。',
      choices: [
        { label: '先带走自己的行李与家人', detail: '假设结局：校长也是一位普通人', ending: 'luggage' },
        { label: '先运图书仪器，个人物件从简', detail: '历史主线：把公共之物放在私物之前', next: 'b3' },
      ],
    },
    {
      id: 'b3', speaker: '竺可桢', chapter: '同行', date: '1937年11月', place: '杭州码头', scene: 'evacuation',
      text: '名单上还有学生没有到齐。先走一步，沿途的接应或许更容易；再等一等，就可能错过最后的车船。我望着江雾，知道“全校”二字不是数字，而是一个个具体的人。', next: 'b4',
    },
    {
      id: 'b4', speaker: '竺可桢', chapter: '抉择四 · 独行或同行', date: '汽笛响起之前', place: '启程', scene: 'evacuation',
      text: '副官催我登船。我可以带少数人先探路，也可以留下接应，与最后一批师生同行。',
      choices: [
        { label: '带少数人先行，不再回头', detail: '假设结局：最轻的行装，最重的牵挂', ending: 'alone' },
        { label: '留下接应，与师生共同启程', detail: '主线结局：文军长征由此开始', ending: 'main' },
      ],
    },
  ],
}

export const INTERLUDES: Record<number, NovelScript> = {
  0: {
    title: '第1章 · 建德日记',
    nodes: [
      { id: 'j1', speaker: '竺可桢', chapter: '建德自述', date: '1937年11月', place: '浙江建德', scene: 'jiande', text: '建德的教室散在城中各处，复课却没有等待。我在日记里记天气、车次、住处和书箱，琐细事项连起来，便是一所大学仍在运转的证据。', note: FIRST_PERSON_NOTE, next: 'j2' },
      { id: 'j2', speaker: '竺可桢', chapter: '失散名单', date: '1937年12月', place: '浙赣铁路沿线', scene: 'jiande', text: '金华遭炸，运输受阻。有人报来失散师生的名字，也有人催我先保住图书仪器的运输线。我手里的铅笔停在两栏名单之间，哪一栏都不能划去。', next: 'j3' },
      { id: 'j3', speaker: '竺可桢', chapter: '抉择五 · 接应', date: '1937年12月', place: '临时校务处', scene: 'jiande', text: '人手只够先做成一件事。我该如何安排下一支队伍？', choices: [
        { label: '先派员寻找失散师生', detail: '让沿途每一个名字都有着落', next: 'j4a' },
        { label: '先疏通书箱运输，再沿线联络', detail: '保住复课所需，也不放弃寻人', next: 'j4b' },
      ] },
      { id: 'j4a', speaker: '竺可桢', chapter: '同行者', date: '当夜', place: '浙赣道上', scene: 'evacuation', text: '我把熟悉沿途村镇的人派了出去，又叮嘱他们带上干粮与药品。书可以晚到几日，人若在风雪里失散，便不是几日可以弥补。', next: 'j5' },
      { id: 'j4b', speaker: '竺可桢', chapter: '运输线', date: '当夜', place: '浙赣道上', scene: 'evacuation', text: '我先安排转运书箱，同时把寻人启事托给每一辆西行的车。公共之物与人的生命没有简单的先后，只能在有限的人手里尽力兼顾。', next: 'j5' },
      { id: 'j5', speaker: '竺可桢', chapter: '抉择六 · 改道', date: '1937年12月24日', place: '向吉安', scene: 'jiande', text: '原定线路再次中断。坚持原计划可以少受折腾，却可能让整支队伍困在战火与断轨之间。我必须决定，是等待，还是改道。', choices: [
        { label: '留在原地，等待旧线恢复', detail: '假设结局：把希望寄托于通车', ending: 'stranded' },
        { label: '改道西行，继续寻找复课之地', detail: '历史主线：船、车与步行交替前进', next: 'j6' },
      ] },
      { id: 'j6', speaker: '竺可桢', chapter: '继续西行', date: '1938年初', place: '向吉安与泰和', scene: 'evacuation', text: '我最终选择改道。七百余箱图书仪器曾滞留途中，又在师生职工的奔走中陆续西行。路不是地图上的一条线，而是许多人用脚步接起来的。' },
    ],
  },
  1: {
    title: '第2章 · 泰和日记',
    nodes: [
      { id: 't1', speaker: '竺可桢', chapter: '泰和自述', date: '1938年', place: '江西泰和', scene: 'taihe', text: '白鹭洲与上田村暂时接住了一所大学。借屋上课、延长学习时间，迁校并没有成为停学的理由。我看着学生坐下，才觉得一路的颠簸有了着落。', note: FIRST_PERSON_NOTE, next: 't2' },
      { id: 't2', speaker: '竺可桢', chapter: '抉择七 · 课外之责', date: '1938年', place: '赣江边', scene: 'taihe', text: '当地水患与失学儿童同样摆在眼前。有人主张专心保住大学，有人认为学校既然到了这里，就不能只做借住的客人。', choices: [
        { label: '组织师生修堤并兴办地方教育', detail: '让西迁的大学也服务沿途百姓', next: 't3a' },
        { label: '集中人力维持教学与研究', detail: '先守住大学最根本的使命', next: 't3b' },
      ] },
      { id: 't3a', speaker: '竺可桢', chapter: '江边之事', date: '1938年', place: '泰和乡间', scene: 'taihe', text: '我赞成师生修堤、办垦殖场与学校。大学不只是书箱中的学问，也应在国家与百姓需要之处落地。', next: 't4' },
      { id: 't3b', speaker: '竺可桢', chapter: '课堂之事', date: '1938年', place: '泰和教室', scene: 'taihe', text: '我把有限人力先集中到课程与研究，同时鼓励有余力的师生参与地方事务。非常时期，选择并非都要声势浩大，有时只是把每天的课上好。', next: 't4' },
      { id: 't4', speaker: '竺可桢', chapter: '病中的家书', date: '1938年夏', place: '泰和住处', scene: 'family', text: '校务之外，我也是丈夫和父亲。妻子与次子病中的消息接连而来，桌上的公文却仍在催我启程西迁。我反复读着家书，第一次觉得“负责”二字竟会指向相反的方向。', next: 't5' },
      { id: 't5', speaker: '竺可桢', chapter: '抉择八 · 公私之间', date: '1938年夏', place: '病榻与校务之间', scene: 'family', text: '我可以暂时放下校务，守在家人身旁；也可以把悲痛压进日记，继续主持迁校。没有一种选择能使我毫发无损。', choices: [
        { label: '告假守家人，把校务暂交同人', detail: '假设结局：这一次先做一个丈夫和父亲', ending: 'family' },
        { label: '留下主持迁校，把悲痛写进日记', detail: '历史主线：个人悲痛也被带入西迁岁月', next: 't6' },
      ] },
      { id: 't6', speaker: '竺可桢', chapter: '继续西行', date: '1938年8月', place: '向广西宜山', scene: 'evacuation', text: '妻子与次子后来相继病逝。我仍须处理两千多箱物资的启程，仍须回答师生的询问。旁人看见的是迁校公文，只有日记知道，那些字句之间还藏着怎样的失去。', next: 't7' },
      { id: 't7', speaker: '竺可桢', chapter: '未竟之路', date: '1938年秋', place: '赣江以西', scene: 'taihe', text: '我不能说自己的选择更重，也不能说别人的选择更轻。国难之中，每个人都带着无法与人分担的部分继续前行。' },
    ],
  },
  2: {
    title: '第3章 · 宜山日记',
    nodes: [
      { id: 'y1', speaker: '竺可桢', chapter: '宜山自述', date: '1938年11月', place: '广西宜山', scene: 'yishan', text: '两个月跋涉以后，学校在宜山开学。疟疾与空袭接踵而至，警报声常常打断了课。我明白，坚持办学不是假装危险不存在，而是在危险中仍把人放在最前面。', note: FIRST_PERSON_NOTE, next: 'y2' },
      { id: 'y2', speaker: '竺可桢 · 日记', chapter: '日记原文', date: '1938年11月19日', place: '校务会议', scene: 'yishan', text: '“决定校训为‘求是’两字，校歌请马一浮制。”', quote: true, note: '引自浙江大学公开的校史资料。', next: 'y3' },
      { id: 'y3', speaker: '竺可桢', chapter: '抉择九 · 警报响起', date: '1939年', place: '宜山校区', scene: 'shelter', text: '警报又响了。实验室里还有未及装箱的仪器，教室里的学生正在等待疏散指令。我必须在几息之间下令。', choices: [
        { label: '立即带师生疏散，仪器以后再议', detail: '历史主线：先人后物', next: 'y4a' },
        { label: '带人回实验室抢运仪器', detail: '假设结局：在警报中抢救学问的工具', ending: 'embers' },
      ] },
      { id: 'y4a', speaker: '竺可桢', chapter: '警报间隙', date: '1939年', place: '宜山临时课堂', scene: 'shelter', text: '我命师生先撤。仪器损坏可以添置，人的生命不能重来。警报之后，我们又在残破的屋子里复课，炭笔划过木板的声音比炮火更长久。', next: 'y5' },
      { id: 'y5', speaker: '竺可桢', chapter: '抉择十 · 何以立校', date: '1939年', place: '校务会议前夕', scene: 'yishan', text: '迁校途中，“求是”二字已在校务会议上确定。如今再遇重挫，我可以暂缓一切精神建制，只顾迁徙；也可以让这两个字成为困境中共同的准绳。', choices: [
        { label: '以“求是”为准绳，继续办学', detail: '历史主线：无曰已是，无曰遂真', next: 'y6' },
        { label: '暂缓校训与校歌，专心准备再迁', detail: '假设结局：把精神之事留待安定以后', ending: 'unsettled' },
      ] },
      { id: 'y6', speaker: '竺可桢', chapter: '向黔北', date: '1939年12月', place: '向遵义与湄潭', scene: 'evacuation', text: '再次迁校。遵义临时开课，湄潭筹备校舍。求是并不是一句挂在墙上的话，而是我们在每一次艰难选择之后，仍愿意如实面对世界。' },
    ],
  },
  3: {
    title: '第4章 · 湄潭日记',
    nodes: [
      { id: 'm1', speaker: '竺可桢', chapter: '湄潭自述', date: '1940年起', place: '贵州湄潭', scene: 'meitan', text: '庙宇、祠堂与民居成为教室。黔北山水给了学校喘息之地，却没有给出富足的条件。我常想，大学的尊严不在屋舍，而在艰难之中仍有人认真求证。', note: FIRST_PERSON_NOTE, next: 'm2' },
      { id: 'm2', speaker: '竺可桢', chapter: '东方剑桥', date: '1944年', place: '湄潭', scene: 'meitan', text: '李约瑟到访讲学，将这里的学术与人文氛围同剑桥相提并论。我欣慰的并非一句赞誉，而是世界终于看见：战火没有使这里的思考停止。', next: 'm3' },
      { id: 'm3', speaker: '竺可桢', chapter: '抉择十一 · 灯火大小', date: '黔北岁月', place: '校务处', scene: 'meitan', text: '经费与物资始终有限。我可以把力量集中于少数有望开展的研究，也可以缩减课程，只求让学校维持到复员之日。', choices: [
        { label: '坚持教学研究，让学术在困境中生长', detail: '历史主线：不是维持空壳，而是继续求真', next: 'm4a' },
        { label: '大幅停课减员，只保留学校名义', detail: '假设结局：把火种留到太平以后', ending: 'silence' },
      ] },
      { id: 'm4a', speaker: '竺可桢', chapter: '七年课堂', date: '1940—1946年', place: '遵义与湄潭', scene: 'meitan', text: '我选择让课堂与研究继续。七年的黔北岁月证明，一所大学可以在艰苦中发展，也可以在寂寞中保持求真的尺度。', next: 'm5' },
      { id: 'm5', speaker: '竺可桢', chapter: '抉择十二 · 回望', date: '复员杭州以后', place: '日记的一页', scene: 'archive', text: '多年以后，我再次翻到晚年的日记。若要把西迁的故事讲给今天的学生，我会先让他们看见哪一处求是园？', choices: [
        { label: '梧桐树下的玉泉', detail: '让旧路延伸到今天', next: 'm6' },
        { label: '水岸之间的紫金港', detail: '让灯火照亮今天', next: 'm6' },
      ] },
      { id: 'm6', speaker: '竺可桢', chapter: '回到今天', date: '跨越八十余年', place: '浙江大学', scene: 'modern', text: '无论玉泉还是紫金港，我都希望后来者记得：今日安放的课桌，曾被人从战火中一路护送。旧路已远，两问仍在回响。' },
    ],
  },
  4: {
    title: '第5章 · 今日求是园',
    nodes: [
      { id: 'z1', speaker: '竺可桢', chapter: '今日自述', date: '今天', place: '浙江大学', scene: 'modern', text: '我仿佛又走在熟悉的校园里。水岸明亮，青年匆匆，不再有人需要为下一堂课寻找躲避炮火的地方。我所牵挂的大学，终于把平常日子还给了学生。', note: FIRST_PERSON_NOTE, next: 'z2' },
      { id: 'z2', speaker: '竺可桢', chapter: '两问回响', date: '跨越八十余年', place: '求是园', scene: 'modern', text: '“第一，到浙大来做什么？第二，将来毕业后要做什么样的人？”', quote: true, next: 'z3' },
      { id: 'z3', speaker: '竺可桢', chapter: '最后的取舍', date: '校歌墙前', place: '今天', scene: 'modern', text: '大不自多，海纳江河。我可以在此合上日记，让后来者自己寻找答案；也可以把校歌交给他们，让未尽的问题随歌声继续。', choices: [
        { label: '合上日记，把答案留给后来者', detail: '支线结局：旅程止于长思', ending: 'archive' },
        { label: '让校歌响起，把节拍交给青年', detail: '进入《大不自多》音游', next: 'z4' },
      ] },
      { id: 'z4', speaker: '竺可桢', chapter: '终章', date: '现在', place: '把节拍交给后来者', scene: 'modern', text: '我愿再听一次这首歌。愿每一个音符都不只是准确的敲击，也是你们对“求是”二字的回答。' },
    ],
  },
}

export const ENDINGS = {
  main: {
    id: 'main', number: '主线结局', title: '文军启程', scene: 'evacuation' as NovelScene, place: '杭州码头',
    text: '我留下接应最后一批师生，又把个人行李减到最少。船离岸时，我知道被带走的并不只是图书与仪器，而是一所大学不肯中断的日常。',
  },
  scholar: {
    id: 'scholar', number: '假设结局 01', title: '未赴的校长约', scene: 'archive' as NovelScene, place: '气象书斋',
    text: '我谢绝任命，回到风云与观测之中。书斋依旧安静，但每当听到浙大的消息，我都会想起那份没有签下的校长之约。',
  },
  hangzhou: {
    id: 'hangzhou', number: '假设结局 02', title: '孤城讲台', scene: 'hangzhou' as NovelScene, place: '杭州校园',
    text: '我选择留守杭州，把最后几堂课讲完。校舍仍在，窗外却已不是原来的世界。坚守有时意味着留下，也意味着独自承担留下的代价。',
  },
  luggage: {
    id: 'luggage', number: '假设结局 03', title: '轻装之后', scene: 'evacuation' as NovelScene, place: '西行途中',
    text: '我先安顿了家人与自己的行李。西行路上，家眷得以周全，我却总在开箱时想起那些未能同船的书页。',
  },
  alone: {
    id: 'alone', number: '假设结局 04', title: '先行的脚步', scene: 'evacuation' as NovelScene, place: '江雾深处',
    text: '我带少数人先行探路，终于抵达安全之地。可那份未能到齐的同行名单，成为此后再也没有放下的行囊。',
  },
  stranded: {
    id: 'stranded', number: '假设结局 05', title: '滞留浙赣道', scene: 'jiande' as NovelScene, place: '断轨之前',
    text: '我决定等待旧线恢复。日子在一次次通车传闻中过去，书箱与人都停在原地。等待也是一种选择，只是战火从不因此停下。',
  },
  family: {
    id: 'family', number: '假设结局 06', title: '病榻前的相守', scene: 'family' as NovelScene, place: '泰和住处',
    text: '我把校务暂交同人，留在病榻旁陪伴家人。校长的职责可以托付，丈夫与父亲的陪伴却无法由别人替代。',
  },
  embers: {
    id: 'embers', number: '假设结局 07', title: '灰烬里的仪器', scene: 'shelter' as NovelScene, place: '宜山实验室',
    text: '我转身跑回实验室，想再抢出一箱仪器。警报声里，我终于明白，有些工具可以重建，有些生命却不能重来。',
  },
  unsettled: {
    id: 'unsettled', number: '假设结局 08', title: '未定的校训', scene: 'yishan' as NovelScene, place: '再迁途中',
    text: '我决定把精神建制留待安定以后。迁徙仍在继续，只是每当学生问起学校何以立校，我都觉得有一句话尚未说出口。',
  },
  silence: {
    id: 'silence', number: '假设结局 09', title: '熄灯的课堂', scene: 'meitan' as NovelScene, place: '黔北教室',
    text: '我缩减课程，只为保留学校的名义。校舍安静下来了，灯油也省下了，可我知道，被推迟的并不只是几堂课。',
  },
  archive: {
    id: 'archive', number: '支线结局 10', title: '合卷之后', scene: 'modern' as NovelScene, place: '今日求是园',
    text: '我在校歌墙前合上日记。问题已经留给后来者，答案不必由我写尽。风穿过今日校园，像翻开新的一页。',
  },
} as const

export type EndingId = keyof typeof ENDINGS

export type LevelConfig = {
  name: string
  shortName: string
  year: string
  subtitle: string
  duration: number
  speed: number
  sky: number
  far: number
  ground: number
  accent: number
  modern?: boolean
  relaxed?: boolean
}

export const LEVELS: LevelConfig[] = [
  { name: '初迁 · 天目山与建德', shortName: '建德', year: '1937', subtitle: '护住书箱，向浙赣道上前进', duration: 34, speed: 365, sky: 0xbec7bd, far: 0x76867a, ground: 0x263b39, accent: 0xe5b45b },
  { name: '再迁 · 吉安与泰和', shortName: '泰和', year: '1938', subtitle: '铁路中断，也要让课堂继续', duration: 38, speed: 405, sky: 0xb7c2c0, far: 0x647b78, ground: 0x293a3d, accent: 0xe5a75b },
  { name: '三迁 · 广西宜山', shortName: '宜山', year: '1938—1939', subtitle: '在警报间隙守住求是灯火', duration: 42, speed: 445, sky: 0x7e8586, far: 0x4c585a, ground: 0x242d32, accent: 0xe46f51 },
  { name: '终迁 · 遵义与湄潭', shortName: '湄潭', year: '1939—1940', subtitle: '越过黔北山路，抵达七年课堂', duration: 44, speed: 470, sky: 0x9fa99d, far: 0x5b7166, ground: 0x253c35, accent: 0xe5b45b },
  { name: '今天 · 求是园', shortName: '现代校园', year: '现代', subtitle: '旧路已远，两问仍在回响', duration: 24, speed: 400, sky: 0xa9c9d0, far: 0x78a29c, ground: 0x244e53, accent: 0xf0bd59, modern: true },
]

export const ROUTE = ['杭州', '天目山 · 建德', '吉安 · 泰和', '广西宜山', '遵义 · 湄潭', '现代求是园']

export const SOURCES = [
  { title: '浙江大学的“长征”', publisher: '浙江大学新闻网', url: 'http://www.news.zju.edu.cn/2008/0214/c775a74469/pagem.htm' },
  { title: '竺可桢日记首次以全貌呈现', publisher: '浙江大学新闻网', url: 'http://www.news.zju.edu.cn/2006/0228/c775a72058/pagem.htm' },
  { title: '竺可桢：一生求是 立身报国', publisher: '浙江大学', url: 'https://www.zju.edu.cn/2025/0624/c76699a3064079/page.htm' },
  { title: '校训', publisher: '浙江大学', url: 'https://www.zju.edu.cn/573/' },
  { title: '校歌', publisher: '浙江大学', url: 'https://www.zju.edu.cn/574/list.htm' },
  { title: '马一浮193件作品捐赠浙大', publisher: '浙江大学', url: 'https://www.zju.edu.cn/2012/0528/c41532a61871/pagem.htm' },
]
