import { useEffect, useState } from 'react'
import { storage } from './storage'
export type Preferences = { music: number; effects: number; textSpeed: number; fontSize: number }
const defaults: Preferences = { music: .6, effects: .65, textSpeed: 27, fontSize: 19 }
export function readPreferences(): Preferences {
  const v = storage.get<Partial<Preferences>>('preferences.v1', {})
  const clamp = (x: unknown, low: number, high: number, fallback: number) => typeof x === 'number' && Number.isFinite(x) ? Math.min(high, Math.max(low, x)) : fallback
  return { music: clamp(v?.music, 0, 1, defaults.music), effects: clamp(v?.effects, 0, 1, defaults.effects), textSpeed: clamp(v?.textSpeed, 0, 65, 27), fontSize: clamp(v?.fontSize, 16, 26, 19) }
}
export function setPreferences(value: Preferences) {
  storage.set('preferences.v1', value)
  window.dispatchEvent(new CustomEvent('game-preferences-change'))
}
export function usePreferences() {
  const [value, setValue] = useState(readPreferences)
  useEffect(() => {
    const sync = () => setValue(readPreferences())
    window.addEventListener('game-preferences-change', sync)
    return () => window.removeEventListener('game-preferences-change', sync)
  }, [])
  return value
}
