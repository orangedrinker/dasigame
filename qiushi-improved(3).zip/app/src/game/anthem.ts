import { readPreferences } from './preferences'
import chartData from './anthem-chart.json'
import { isBrief } from './edition'
import { assetUrl } from './asset'

export type AnthemNote = {
  time: number
  duration: number
  pitch: number
  lyric: string
  lane?: number
  chord?: boolean
  chordLane?: number | null
}

/** One sung character of the anthem, timed to its onset in the choir recording. */
export type LyricChar = {
  time: number
  char: string
  phrase: number
}

// 谱面来自对实际合唱录音的节拍、频谱起音与乐句分析，时间与音频共用同一时钟；
// 逐字歌词轨来自人声频段（250Hz–3.4kHz）的起音检测，每个字对准录音里真正唱出的时刻。
export function buildAnthem(): { notes: AnthemNote[]; duration: number; beat: number; lyrics: LyricChar[] } {
  const notes = isBrief ? chartData.notes.filter((note) => note.time < 52) : chartData.notes
  const lyrics = isBrief ? chartData.lyrics.filter((entry) => entry.time < 52) : chartData.lyrics
  const duration = isBrief ? 54 : chartData.duration
  return { notes, duration, beat: chartData.beat, lyrics }
}

export class AnthemPlayer {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private effects: GainNode | null = null
  private source: AudioBufferSourceNode | null = null
  private startAt = 0
  private muted = false
  private audioData: ArrayBuffer | null = null
  private loading: Promise<ArrayBuffer> | null = null
  private decodedDuration = 0

  private readonly syncSettings = () => {
    try { this.muted = localStorage.getItem('game.muted') === '1' } catch { /* retain */ }
    if (this.master) this.master.gain.value = this.muted ? 0 : .72 * readPreferences().music
    if (this.effects) this.effects.gain.value = this.muted ? 0 : .72 * readPreferences().effects
  }
  constructor() {
    try { this.muted = localStorage.getItem('game.muted') === '1' } catch { this.muted = false }
  }

  private load(): Promise<ArrayBuffer> {
    if (this.audioData) return Promise.resolve(this.audioData)
    if (!this.loading) {
      this.loading = fetch(assetUrl('/audio/zju-anthem-choir.mp3'))
        .then((response) => {
          if (!response.ok) throw new Error(`Anthem audio ${response.status}`)
          return response.arrayBuffer()
        })
        .then((data) => {
          this.audioData = data
          return data
        })
        .finally(() => { this.loading = null })
    }
    return this.loading
  }

  preload(): void {
    void this.load().catch(() => { /* start() retries the request after a user gesture */ })
  }

  async start(beat = 0.5): Promise<number> {
    const data = await this.load()
    this.stop()
    window.addEventListener('game-preferences-change', this.syncSettings)
    window.addEventListener('game-mute-change', this.syncSettings)
    this.ctx = new AudioContext()
    await this.ctx.resume()
    this.master = this.ctx.createGain()
    this.master.gain.value = this.muted ? 0 : 0.72 * readPreferences().music
    this.master.connect(this.ctx.destination)
    this.effects = this.ctx.createGain()
    this.effects.connect(this.ctx.destination)
    this.syncSettings()
    const buffer = await this.ctx.decodeAudioData(data.slice(0))
    this.decodedDuration = buffer.duration
    this.source = this.ctx.createBufferSource()
    this.source.buffer = buffer
    this.source.connect(this.master)
    // The 3s lead-in snaps to the chart's beat grid so the count-in ticks land
    // exactly on the pulse the first notes will follow.
    const leadIn = Math.max(2, Math.round(3 / beat) * beat)
    this.startAt = this.ctx.currentTime + leadIn
    this.source.start(this.startAt)
    for (let at = this.startAt - beat, i = 0; at > this.ctx.currentTime + 0.05; at -= beat, i += 1) {
      this.metronome(at, i % 4 === 0)
    }
    return this.startAt
  }

  private metronome(at: number, accent = false): void {
    if (!this.ctx || !this.master) return
    const osc = this.ctx.createOscillator()
    const gain = this.ctx.createGain()
    osc.frequency.value = accent ? 1174 : 880
    gain.gain.setValueAtTime(accent ? 0.14 : 0.09, at)
    gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.07)
    osc.connect(gain).connect(this.effects!)
    osc.start(at)
    osc.stop(at + 0.08)
  }

  judgement(kind: 'perfect' | 'good' | 'miss'): void {
    if (!this.ctx || !this.master || this.muted) return
    const at = this.ctx.currentTime
    const osc = this.ctx.createOscillator()
    const gain = this.ctx.createGain()
    osc.type = kind === 'miss' ? 'sawtooth' : 'sine'
    osc.frequency.setValueAtTime(kind === 'perfect' ? 1046 : kind === 'good' ? 660 : 145, at)
    if (kind === 'perfect') osc.frequency.exponentialRampToValueAtTime(1568, at + 0.07)
    const duration = kind === 'miss' ? 0.09 : 0.075
    gain.gain.setValueAtTime(kind === 'miss' ? 0.035 : 0.085, at)
    gain.gain.exponentialRampToValueAtTime(0.0001, at + duration)
    osc.connect(gain).connect(this.effects!)
    osc.start(at)
    osc.stop(at + duration + 0.01)
  }

  now(): number {
    return this.ctx?.currentTime ?? 0
  }

  /** Suspending the AudioContext freezes currentTime, which is the chart clock —
   *  so notes, lyrics and judgement all freeze exactly where they were. */
  suspend(): void {
    if (this.ctx && this.ctx.state === 'running') void this.ctx.suspend()
  }

  resume(): void {
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume()
  }

  bufferDuration(): number {
    return this.decodedDuration
  }

  toggleMute(): boolean {
    this.muted = !this.muted
    try { localStorage.setItem('game.muted', this.muted ? '1' : '0') } catch { /* settings remain available for this session */ }
    if (this.master) this.master.gain.value = this.muted ? 0 : 0.72 * readPreferences().music
    this.syncSettings()
    window.dispatchEvent(new CustomEvent('game-mute-change', { detail: this.muted }))
    return this.muted
  }

  stop(): void {
    window.removeEventListener('game-preferences-change', this.syncSettings)
    window.removeEventListener('game-mute-change', this.syncSettings)
    try { this.source?.stop() } catch { /* source may not have started */ }
    this.source?.disconnect()
    this.source = null
    const ctx = this.ctx
    this.ctx = null
    this.master = null
    this.effects = null
    if (ctx && ctx.state !== 'closed') void ctx.close()
  }
}
