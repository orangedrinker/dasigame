import Phaser from 'phaser'
import { AnthemPlayer, buildAnthem, type AnthemNote } from './anthem'
import type { GameEvent } from './types'
import { activePhraseIndex, introOffset, recordingTime, vocalTime } from './anthem-timing'

type ChartNote = AnthemNote & {
  lane: number
  obj: Phaser.GameObjects.Container
  hit: boolean
  missed: boolean
}

type LyricPhrase = {
  chars: Array<{ char: string; start: number; end: number }>
  texts: Phaser.GameObjects.Text[]
  start: number
  end: number
  text: string
}

type DebugField = 'time' | 'error' | 'offset'
// Seconds; positive values compensate delayed input.
const inputOffset = 0

export class RhythmScene extends Phaser.Scene {
  private onEvent!: (event: GameEvent) => void
  private notes: ChartNote[] = []
  private anthem = new AnthemPlayer()
  private started = false
  private completed = false
  private startAt = 0
  private score = 0
  private combo = 0
  private maxCombo = 0
  private perfect = 0
  private good = 0
  private miss = 0
  private judgedValue = 0
  private judgedCount = 0
  private judgeY = 0
  private laneWidth = 76
  private fieldWidth = 304
  private line!: Phaser.GameObjects.Graphics
  private laneGlow: Phaser.GameObjects.Rectangle[] = []
  private scoreText!: Phaser.GameObjects.Text
  private comboText!: Phaser.GameObjects.Text
  private lyricText!: Phaser.GameObjects.Text
  private lyricLine!: Phaser.GameObjects.Container
  private feedbackText!: Phaser.GameObjects.Text
  private countdownText!: Phaser.GameObjects.Text
  private progress!: Phaser.GameObjects.Graphics
  private duration = 0
  private beat = 0.5
  private phrases: LyricPhrase[] = []
  private activePhrase = -1
  private audioReady = false
  private paused = false
  private debugPanel: HTMLElement | null = null
  private debugFields: Record<DebugField, HTMLSpanElement> | null = null
  private debugNoteTop = 0
  private lastRawErrorMs: number | null = null
  private lastDebugStatus = '等待按键'
  private sceneGeneration = 0
  private disposed = false
  private rhythmProbe: NonNullable<Window['__rhythmProbe']> | null = null
  private readonly nativeKeyDown = (event: KeyboardEvent) => this.onNativeKey(event)

  constructor() {
    super('rhythm')
  }

  init(data: { onEvent: (event: GameEvent) => void }) {
    this.sceneGeneration += 1
    this.disposed = false
    this.onEvent = data.onEvent
    this.notes = []
    this.started = false
    this.completed = false
    this.score = 0
    this.combo = 0
    this.maxCombo = 0
    this.perfect = 0
    this.good = 0
    this.miss = 0
    this.judgedValue = 0
    this.judgedCount = 0
    this.phrases = []
    this.activePhrase = -1
    this.audioReady = false
    this.paused = false
    this.lastRawErrorMs = null
    this.lastDebugStatus = '等待按键'
  }

  create() {
    this.cameras.main.setBackgroundColor(0x101e2b)
    this.judgeY = this.scale.height * (this.scale.width < 600 ? 0.64 : 0.72)
    this.fieldWidth = Math.min(this.scale.width * 0.88, 460)
    this.laneWidth = this.fieldWidth / 4
    this.createBackground()
    this.createField()
    this.createChart()
    this.createHud()
    this.createDebugPanel()
    this.createInput()
    this.scale.on(Phaser.Scale.Events.RESIZE, this.onResize, this)
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this)
    this.events.once(Phaser.Scenes.Events.DESTROY, this.shutdown, this)
    this.anthem.preload()
    this.rhythmProbe = () => ({
      now: this.anthem.now(), startAt: this.startAt, duration: this.duration,
      ready: this.audioReady, sourceDuration: this.anthem.bufferDuration(), notes: this.notes.length,
      score: this.score, combo: this.combo, miss: this.miss,
      songTime: this.audioReady ? this.songTime() : 0,
      lastRawErrorMs: this.lastRawErrorMs,
      inputOffset,
      introOffset,
      fileTime: this.audioReady ? recordingTime(this.songTime()) : 0,
      firstNoteTime: this.notes[0]?.time ?? 0,
      firstSungNoteTime: this.notes.find((note) => note.vocal)?.time ?? 0,
      noteTargets: this.notes.map((note) => ({ time: note.time, fileTime: recordingTime(note.time), lane: note.lane, lyric: note.lyric, vocal: Boolean(note.vocal) })),
      firstLyricTime: (this.phrases[0]?.start ?? introOffset) - introOffset,
      countdown: this.countdownText.text,
      activePhrase: this.activePhrase,
      lyricText: this.phrases[this.activePhrase]?.text ?? '',
      lyricVisible: this.lyricLine.visible,
      phraseStart: this.phrases[this.activePhrase]?.start ?? null,
      phraseEnd: this.phrases[this.activePhrase]?.end ?? null,
    })
    window.__rhythmProbe = this.rhythmProbe
    window.__GAME_READY__ = true
  }

  private createBackground() {
    const w = this.scale.width
    const h = this.scale.height
    const g = this.add.graphics().setDepth(-5)
    g.fillStyle(0x162b39, 1)
    g.fillRect(0, 0, w, h)
    g.fillStyle(0x284754, 0.5)
    g.fillCircle(w * 0.82, h * 0.18, Math.min(w, h) * 0.18)
    g.lineStyle(1, 0xe7c471, 0.16)
    for (let r = 80; r < Math.max(w, h); r += 80) g.strokeCircle(w * 0.82, h * 0.18, r)
    this.add.text(w / 2, h * 0.25, '大不自多', {
      resolution: 2, fontFamily: 'Noto Serif SC, Songti SC, serif', fontSize: `${Math.min(94, w * 0.12)}px`, color: '#d8c99f', fontStyle: 'bold',
    }).setOrigin(0.5).setAlpha(0.07).setDepth(-3)
    const dust = this.add.graphics().setDepth(-2)
    dust.fillStyle(0xf4db9b, 0.35)
    for (let i = 0; i < 55; i += 1) dust.fillCircle((i * 137) % Math.max(w, 1), (i * 71) % Math.max(h, 1), i % 3 === 0 ? 2 : 1)
  }

  private createField() {
    const centerX = this.scale.width / 2
    for (let i = 0; i < 4; i += 1) {
      const x = centerX + (i - 1.5) * this.laneWidth
      const lane = this.add.rectangle(x, this.scale.height / 2, this.laneWidth - 3, this.scale.height, i % 2 ? 0x183342 : 0x142d3a, 0.48).setDepth(-1)
      void lane
      const glow = this.add.rectangle(x, this.judgeY, this.laneWidth - 6, 80, 0xf0c96c, 0).setDepth(2)
      this.laneGlow.push(glow)
      this.add.text(x, this.judgeY + 42, ['D', 'F', 'J', 'K'][i], {
        resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: '16px', color: '#d7e4df',
      }).setOrigin(0.5).setDepth(3).setAlpha(0.75)
    }
    this.line = this.add.graphics().setDepth(4)
    this.drawLine(0)
  }

  private drawLine(angle: number) {
    const centerX = this.scale.width / 2
    this.line.clear()
    this.line.lineStyle(3, 0xf3d98e, 0.95)
    this.line.beginPath()
    this.line.moveTo(centerX - this.fieldWidth * 0.65, this.judgeY)
    this.line.lineTo(centerX + this.fieldWidth * 0.65, this.judgeY)
    this.line.strokePath()
    this.line.lineStyle(1, 0x89d5cf, 0.65)
    this.line.beginPath()
    this.line.moveTo(centerX - this.fieldWidth * 0.65, this.judgeY + 7)
    this.line.lineTo(centerX + this.fieldWidth * 0.65, this.judgeY + 7)
    this.line.strokePath()
    this.line.setPosition(centerX, this.judgeY)
    // Graphics coordinates were already absolute; offset rotation around the judgement point requires a compensated position.
    this.line.setPosition(0, 0)
    this.line.setRotation(angle)
  }

  private createChart() {
    const song = buildAnthem()
    this.duration = song.duration
    this.beat = song.beat
    this.phrases = song.phrases.map((phrase) => ({
      ...phrase,
      chars: phrase.chars ?? Array.from(phrase.text, (char) => ({ char, start: phrase.start, end: phrase.end })),
      texts: [],
    }))
    const centerX = this.scale.width / 2
    const chart: Array<{ note: AnthemNote; lane: number; chord: boolean }> = []
    song.notes.forEach((note, index) => {
      const lane = note.lane ?? (note.pitch + index * 3) % 4
      chart.push({ note, lane, chord: Boolean(note.chord) })
      if (note.chord) {
        chart.push({
          note: { ...note, chord: false, chordLane: null },
          lane: note.chordLane ?? (lane + 2) % 4,
          chord: true,
        })
      }
    })
    chart.sort((a, b) => a.note.time - b.note.time || a.lane - b.lane)
    chart.forEach(({ note, lane, chord }) => {
      const x = centerX + (lane - 1.5) * this.laneWidth
      const obj = this.add.container(x, -100).setDepth(3).setVisible(false)
      const color = chord ? 0x83d8cf : 0xf1c96c
      const glow = this.add.rectangle(0, 0, this.laneWidth * 0.76, 22, color, 0.17)
      const bar = this.add.rectangle(0, 0, this.laneWidth * 0.7, chord ? 17 : 13, color, 1)
      bar.setStrokeStyle(2, 0xfff2c6, 0.78)
      const core = this.add.rectangle(0, 0, this.laneWidth * 0.38, 3, 0xffffff, 0.85)
      obj.add([glow, bar, core])
      this.notes.push({ ...note, lane, obj, hit: false, missed: false })
    })
  }

  private createHud() {
    const pad = this.scale.width < 600 ? 16 : 30
    this.scoreText = this.add.text(this.scale.width - pad, 22, '0000000', {
      resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: this.scale.width < 600 ? '23px' : '30px', color: '#f5ead0',
    }).setOrigin(1, 0).setDepth(5)
    this.comboText = this.add.text(this.scale.width / 2, this.scale.height * 0.22, '', {
      resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: this.scale.width < 600 ? '26px' : '36px', color: '#f4df9e', align: 'center',
    }).setOrigin(0.5).setDepth(5)
    const lyricY = this.scale.height / 2
    this.lyricText = this.add.text(this.scale.width / 2, lyricY, '', {
      resolution: 2, fontFamily: 'Noto Serif SC, Songti SC, serif', fontSize: this.scale.width < 600 ? '18px' : '24px', color: '#f1e6cc',
    }).setOrigin(0.5).setDepth(5).setVisible(false)
    this.lyricLine = this.add.container(this.scale.width / 2, lyricY).setDepth(5).setVisible(false)
    this.feedbackText = this.add.text(this.scale.width / 2, this.judgeY - 50, '', {
      resolution: 2, fontFamily: 'ui-monospace, monospace', fontSize: '17px', color: '#91e1d5',
    }).setOrigin(0.5).setDepth(5)
    this.countdownText = this.add.text(this.scale.width / 2, this.scale.height * 0.42, '准备', {
      resolution: 2, fontFamily: 'Noto Serif SC, Songti SC, serif', fontSize: '30px', color: '#f2d78e',
    }).setOrigin(0.5).setDepth(6)
    this.progress = this.add.graphics().setDepth(5)
    this.add.text(pad, 26, '浙江大学校歌 · 文琴合唱', {
      resolution: 2, fontFamily: 'Noto Sans SC, sans-serif', fontSize: this.scale.width < 600 ? '14px' : '17px', color: '#e1eee7', fontStyle: 'bold',
    }).setDepth(5).setStroke('#07131c', 3).setShadow(0, 2, '#000000', 5)
  }

  private createDebugPanel() {
    this.debugPanel?.remove()
    const compact = this.scale.width < 900
    const panel = document.createElement("aside")
    panel.id = "rhythm-debug-panel"
    panel.setAttribute("aria-label", "音游同步调试面板")
    Object.assign(panel.style, {
      position: "fixed",
      zIndex: "15",
      left: "max(12px, env(safe-area-inset-left, 0px))",
      top: "calc(60px + env(safe-area-inset-top, 0px))",
      width: "188px",
      padding: "8px 10px",
      boxSizing: "border-box",
      border: "1px solid rgba(145, 225, 213, 0.35)",
      borderRadius: "6px",
      background: "rgba(8, 20, 27, 0.88)",
      color: "#e1eee7",
      font: "11px/1.5 ui-monospace, SFMono-Regular, Consolas, monospace",
      fontVariantNumeric: "tabular-nums",
      pointerEvents: "none",
      userSelect: "none",
    })
    if (compact) {
      Object.assign(panel.style, {
        left: "max(8px, env(safe-area-inset-left, 0px))",
        right: "max(8px, env(safe-area-inset-right, 0px))",
        top: "calc(4px + env(safe-area-inset-top, 0px))",
        width: "auto",
        padding: "3px 6px",
        display: "grid",
        gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
        gap: "8px",
      })
    } else {
      const title = document.createElement("div")
      title.textContent = "SYNC DEBUG"
      Object.assign(title.style, { color: "#91e1d5", fontSize: "10px", marginBottom: "4px" })
      panel.appendChild(title)
    }
    const fields = {} as Record<DebugField, HTMLSpanElement>
    const metrics: Array<[DebugField, string, string]> = [
      ["time", "起唱时间", "基于 AudioContext.currentTime，已扣除开始时间、输出延迟和前奏；0 秒为首字起唱"],
      ["error", "原始按键误差", "未扣除 inputOffset；负数为早按，正数为晚按"],
      ["offset", "inputOffset", "当前输入延迟补偿值，正值抵消输入偏晚"],
    ]
    for (const [key, label, hint] of metrics) {
      const row = document.createElement("div")
      row.title = hint
      Object.assign(row.style, {
        display: "flex",
        justifyContent: "space-between",
        gap: "4px",
        minWidth: "0",
        whiteSpace: "nowrap",
      })
      const name = document.createElement("span")
      name.textContent = compact ? { time: "时间", error: "误差", offset: "偏移" }[key] : label
      Object.assign(name.style, {
        display: "inline",
        color: "#9fb4b9",
        fontSize: compact ? "9px" : "10px",
        lineHeight: compact ? "14px" : "16px",
      })
      const value = document.createElement("span")
      value.dataset.debugValue = key
      Object.assign(value.style, {
        display: "inline",
        fontSize: compact ? "10px" : "12px",
        lineHeight: compact ? "14px" : "16px",
      })
      row.append(name, value)
      panel.appendChild(row)
      fields[key] = value
    }
    document.body.appendChild(panel)
    this.debugPanel = panel
    this.debugFields = fields
    // 小屏预留顶部信息区，音符仍按绝对歌曲时间计算位置。
    this.debugNoteTop = compact ? panel.getBoundingClientRect().bottom + 16 : 0
    this.updateDebugPanel()
  }
  private updateDebugPanel(time = this.audioReady ? this.songTime() : 0) {
    if (!this.debugFields) return
    const signedMs = (value: number) => {
      const rounded = Number(value.toFixed(1))
      return `${rounded > 0 ? "+" : ""}${rounded.toFixed(1)} ms`
    }
    const values = {
      time: `${time.toFixed(3)} s`,
      error: this.lastRawErrorMs === null ? this.lastDebugStatus : signedMs(this.lastRawErrorMs),
      offset: signedMs(inputOffset * 1000),
    }
    for (const key of Object.keys(values) as DebugField[]) {
      const value = values[key]
      if (this.debugFields[key].textContent !== value) this.debugFields[key].textContent = value
    }
  }

  private createInput() {
    // Native listener: judgement latency must not wait for Phaser's per-frame key queue.
    window.addEventListener('keydown', this.nativeKeyDown)
  }

  private onNativeKey(event: KeyboardEvent) {
    const target = event.target as Element | null
    if (event.repeat || (typeof target?.closest === 'function' && target.closest('dialog, input, select, textarea, [contenteditable]:not([contenteditable="false"])'))) return
    if ((event.code === 'KeyP' || event.code === 'Escape') && this.started && !this.completed) {
      this.setPaused(!this.paused)
      return
    }
    const lane = ['KeyD', 'KeyF', 'KeyJ', 'KeyK'].indexOf(event.code)
    if (lane >= 0) this.hitLane(lane)
  }

  start() {
    if (this.started || this.completed || this.disposed) return
    const generation = this.sceneGeneration
    this.started = true
    this.audioReady = false
    this.countdownText.setText('载入校歌…')
    void this.anthem.start(this.beat).then((startAt) => {
      if (this.disposed || generation !== this.sceneGeneration || startAt === null) return
      this.startAt = startAt
      this.audioReady = true
      this.countdownText.setText('3')
      // Paused while the audio was still loading: keep the clock frozen.
      if (this.paused) this.anthem.suspend()
    }).catch(() => {
      if (this.disposed || generation !== this.sceneGeneration) return
      this.started = false
      this.audioReady = false
      this.onEvent({ type: 'reset' })
    })
  }

  setPaused(value: boolean) {
    if (this.completed) return
    if (value && !this.started) return // nothing playing yet on the intro screen
    if (this.paused === value) return
    this.paused = value
    if (value) this.anthem.suspend()
    else this.anthem.resume()
    this.onEvent({ type: 'paused', paused: value })
  }

  private songTime(): number {
    return vocalTime(this.anthem.now(), this.startAt, this.anthem.outputLatency())
  }

  hitLane(lane: number) {
    if (!this.started || !this.audioReady || this.completed || this.paused) return
    const sampledSongTime = this.songTime()
    const now = sampledSongTime - inputOffset
    this.tweens.killTweensOf(this.laneGlow[lane])
    this.laneGlow[lane].alpha = 0.32
    this.tweens.add({ targets: this.laneGlow[lane], alpha: 0, duration: 170 })
    let target: ChartNote | undefined
    let best = 0.135
    for (const note of this.notes) {
      if (note.lane !== lane || note.hit || note.missed) continue
      const distance = Math.abs(note.time - now)
      if (distance < best) {
        best = distance
        target = note
      }
    }
    if (!target) {
      this.lastRawErrorMs = null
      this.lastDebugStatus = '无匹配音符'
      this.updateDebugPanel(sampledSongTime)
      return
    }
    this.lastRawErrorMs = (sampledSongTime - target.time) * 1000
    this.updateDebugPanel(sampledSongTime)
    target.hit = true
    target.obj.setVisible(false)
    this.judgedCount += 1
    let value = 0.65
    let label = 'GOOD'
    let color = '#e7bb69'
    if (best <= 0.042) {
      value = 1
      label = 'PERFECT'
      color = '#91e1d5'
      this.perfect += 1
    } else {
      this.good += 1
      if (best <= 0.075) label = 'GREAT'
    }
    this.judgedValue += value
    this.combo += 1
    this.maxCombo = Math.max(this.maxCombo, this.combo)
    this.score = Math.round((this.judgedValue / this.notes.length) * 1_000_000)
    this.feedbackText.setText(label).setColor(color)
    this.anthem.judgement(value === 1 ? 'perfect' : 'good')
    this.hitBurst(target.obj.x, this.judgeY, value === 1 ? 0x91e1d5 : 0xe7bb69)
    this.updateHud()
  }

  private hitBurst(x: number, y: number, color: number) {
    for (let i = 0; i < 6; i += 1) {
      const p = this.add.circle(x, y, 3, color).setDepth(6)
      const angle = (Math.PI * 2 * i) / 6
      this.tweens.add({ targets: p, x: x + Math.cos(angle) * 42, y: y + Math.sin(angle) * 42, alpha: 0, scale: 0.2, duration: 240, onComplete: () => p.destroy() })
    }
  }

  update() {
    const sampledSongTime = this.audioReady ? this.songTime() : 0
    this.updateDebugPanel(sampledSongTime)
    if (!this.started || !this.audioReady || this.completed || this.paused) return
    const now = sampledSongTime
    const fileTime = recordingTime(now)
    const judgeTime = now - inputOffset
    if (fileTime < 0) {
      this.countdownText.setText(String(Math.max(1, Math.ceil(-fileTime))))
      return
    }
    this.countdownText.setText('')
    const speed = Math.min(680, this.scale.height * 0.92)
    // Keep the visible judgement line at the logical target height.
    this.line.setRotation(0)
    for (const note of this.notes) {
      if (note.hit || note.missed) continue
      const until = note.time - now
      if (until < 1.5 && until > -0.24 && this.judgeY - until * speed >= this.debugNoteTop) {
        note.obj.setVisible(true)
        note.obj.y = this.judgeY - until * speed
        note.obj.x = this.scale.width / 2 + (note.lane - 1.5) * this.laneWidth
        note.obj.rotation = 0
      } else {
        note.obj.setVisible(false)
      }
      if (judgeTime > note.time + 0.135) {
        note.missed = true
        note.obj.setVisible(false)
        this.miss += 1
        this.combo = 0
        this.judgedCount += 1
        this.feedbackText.setText('MISS').setColor('#df8975')
        this.anthem.judgement('miss')
        this.updateHud()
      }
    }
    this.updateLyrics(fileTime)
    this.progress.clear()
    this.progress.fillStyle(0xf0cb74, 0.8)
    this.progress.fillRect(0, 0, this.scale.width * Math.min(1, fileTime / recordingTime(this.duration)), 3)
    if (now >= this.duration && this.notes.every(note => note.hit || note.missed)) this.finish()
  }

  /** Show only the phrase whose aligned interval contains the actual recording
   * time. End times prevent stale lyrics during rests; future phrases stay hidden. */
  private updateLyrics(fileTime: number) {
    const index = activePhraseIndex(this.phrases, fileTime)
    if (index < 0) {
      this.lyricText.setVisible(false)
      this.lyricLine.setVisible(false)
      this.activePhrase = -1
      return
    }
    if (index !== this.activePhrase) {
      this.activePhrase = index
      this.lyricText.setVisible(false)
      this.lyricLine.removeAll(true)
      const phrase = this.phrases[index]
      const small = this.scale.width < 600
      const fontSize = Math.min(small ? 22 : 30, (this.scale.width - 32) / Math.max(1, phrase.chars.length * 1.14))
      const step = fontSize * 1.14
      const offset = -((phrase.chars.length - 1) / 2) * step
      phrase.texts = phrase.chars.map((entry, i) => {
        const text = this.add.text(offset + i * step, 0, entry.char, {
          resolution: 2, fontFamily: 'Noto Serif SC, Songti SC, serif', fontSize: `${fontSize}px`, color: '#8fa3a8', fontStyle: 'bold',
        }).setOrigin(0.5)
        text.setStroke('#07131c', 3).setShadow(0, 2, '#000000', 5)
        this.lyricLine.add(text)
        return text
      })
      this.lyricLine.setVisible(true)
      this.lyricLine.alpha = 0.8
    }
    const phrase = this.phrases[this.activePhrase]
    for (let i = 0; i < phrase.chars.length; i += 1) {
      const text = phrase.texts[i]
      if (!text) continue
      const sung = phrase.chars[i].start <= fileTime
      const targetColor = sung ? '#ffe9ad' : '#8fa3a8'
      if (text.style.color !== targetColor) text.setColor(targetColor)
      const isNow = sung && fileTime < phrase.chars[i].end
      const targetScale = isNow ? 1.18 : 1
      if (Math.abs(text.scale - targetScale) > 0.02) text.setScale(targetScale)
    }
  }

  private updateHud() {
    this.scoreText.setText(String(this.score).padStart(7, '0'))
    this.comboText.setText(this.combo > 1 ? `${this.combo}\nCOMBO` : '')
  }

  private finish() {
    if (this.completed) return
    this.completed = true
    const accuracy = this.notes.length ? (this.judgedValue / this.notes.length) * 100 : 0
    this.score = Math.round((this.judgedValue / this.notes.length) * 1_000_000)
    this.onEvent({ type: 'rhythm-result', score: this.score, combo: this.maxCombo, accuracy, perfect: this.perfect, good: this.good, miss: this.miss })
  }

  toggleMute() {
    return this.anthem.toggleMute()
  }

  private onResize(size: Phaser.Structs.Size) {
    this.judgeY = size.height * (size.width < 600 ? 0.64 : 0.72)
    this.fieldWidth = Math.min(size.width * 0.88, 460)
    this.laneWidth = this.fieldWidth / 4
    // Rebuild both the ready screen and an active chart after an orientation change.
    if (!this.completed) {
      if (this.started) this.onEvent({ type: 'reset' })
      this.scene.restart({ onEvent: this.onEvent })
    }
  }

  shutdown() {
    if (this.disposed) return
    this.disposed = true
    this.sceneGeneration += 1
    this.started = false
    this.audioReady = false
    this.events?.off(Phaser.Scenes.Events.SHUTDOWN, this.shutdown, this)
    this.events?.off(Phaser.Scenes.Events.DESTROY, this.shutdown, this)
    this.debugPanel?.remove()
    this.debugPanel = null
    this.debugFields = null
    this.debugNoteTop = 0
    window.removeEventListener('keydown', this.nativeKeyDown)
    this.scale?.off(Phaser.Scale.Events.RESIZE, this.onResize, this)
    this.anthem.stop()
    if (window.__rhythmProbe === this.rhythmProbe) {
      delete window.__rhythmProbe
      window.__GAME_READY__ = false
    }
    this.rhythmProbe = null
  }
}
