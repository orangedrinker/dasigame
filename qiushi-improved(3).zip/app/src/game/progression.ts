import type { SaveData } from './save'
export function recordSeals(current:SaveData,level:number,seals:number):SaveData {
 const safe=Math.max(0,Number.isFinite(seals)?seals:0)
 const previous=current.levelSeals[level]??0
 return {...current,levelSeals:{...current.levelSeals,[level]:Math.max(previous,safe)},totalSeals:current.totalSeals+Math.max(0,safe-previous)}
}
export function completeChapter(current:SaveData,level:number,next:number|null):SaveData {
 return {...current,completedLevels:[...new Set([...current.completedLevels,level])],unlockedLevel:Math.max(current.unlockedLevel,next??4)}
}
export function completeJourney(current:SaveData,score:number,combo:number):SaveData {
 return {...current,checkpoint:{kind:'complete'},completedGame:true,unlockedLevel:4,completedLevels:[0,1,2,3,4],bestRhythm:Math.max(current.bestRhythm,score),bestCombo:Math.max(current.bestCombo,combo)}
}
