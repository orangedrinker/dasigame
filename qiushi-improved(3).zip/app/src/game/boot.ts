import Phaser from 'phaser'
import { RunnerScene } from './RunnerScene'
import { RhythmScene } from './RhythmScene'
import type { LevelConfig } from './content'
import type { GameEvent, GameHandle } from './types'

declare global {
  interface Window {
    __gameProbe?: () => {
      x: number
      y: number
      z: number
      health?: number
      grounded?: boolean
      ducking?: boolean
      elapsed?: number
      jumpsLeft?: number
      obstacles?: Array<{ x: number; kind: string }>
    }
    __GAME_READY__?: boolean
    __rhythmProbe?: () => { now: number; startAt: number; duration: number; ready: boolean; sourceDuration: number; notes: number; score: number; combo: number; miss: number; songTime: number; lastRawErrorMs: number | null; inputOffset: number; introOffset: number; fileTime: number; firstNoteTime: number; firstSungNoteTime: number; noteTargets: Array<{time: number; fileTime: number; lane: number; lyric: string; vocal: boolean}>; firstLyricTime: number; countdown: string; activePhrase: number; lyricText: string; lyricVisible: boolean; phraseStart: number | null; phraseEnd: number | null }
  }
}

export type StartOptions = {
  mode: 'runner' | 'rhythm'
  level?: LevelConfig
  levelIndex?: number
  onEvent: (event: GameEvent) => void
}

let activeGame: Phaser.Game | null = null
let activeScene: RunnerScene | RhythmScene | null = null
let activeDpiCleanup: (() => void) | null = null

const GAME_RESOLUTION = 2
const RUNNER_PIXEL_BUDGET = 900_000

function configureHighDpiCanvas(canvas: HTMLCanvasElement, mode: StartOptions['mode']) {
  const context = canvas.getContext('2d', { alpha: false, desynchronized: true })
  const bounds = canvas.getBoundingClientRect()
  const cssPixels = Math.max(1, (bounds.width || window.innerWidth) * (bounds.height || window.innerHeight))
  // Keep small screens crisp without making a desktop canvas pay a 4x fill-rate cost on its first input.
  let resolution = mode === 'runner'
    ? Math.max(1, Math.min(GAME_RESOLUTION, Math.sqrt(RUNNER_PIXEL_BUDGET / cssPixels)))
    : GAME_RESOLUTION
  const resize = () => {
    const bounds = canvas.getBoundingClientRect()
    const width = Math.max(1, Math.round((bounds.width || window.innerWidth) * resolution))
    const height = Math.max(1, Math.round((bounds.height || window.innerHeight) * resolution))
    if (canvas.width !== width) canvas.width = width
    if (canvas.height !== height) canvas.height = height
  }
  if (!context) return { resize, setResolution: () => { /* canvas context is unavailable */ } }
  const nativeSetTransform = context.setTransform.bind(context)
  context.setTransform = ((a: number, b: number, c: number, d: number, e: number, f: number) => {
    nativeSetTransform(a * resolution, b * resolution, c * resolution, d * resolution, e * resolution, f * resolution)
  }) as typeof context.setTransform
  return {
    resize,
    setResolution: (value: number) => {
      if (value === resolution) return
      resolution = value
      resize()
    },
  }
}

export function startGame(canvas: HTMLCanvasElement, options: StartOptions): GameHandle {
  stopGame()
  window.__GAME_READY__ = false

  const scene = options.mode === 'runner' ? new RunnerScene() : new RhythmScene()
  activeScene = scene
  const data = options.mode === 'runner'
    ? { level: options.level!, levelIndex: options.levelIndex ?? 0, onEvent: options.onEvent }
    : { onEvent: options.onEvent }

  const highDpi = configureHighDpiCanvas(canvas, options.mode)
  highDpi.resize()
  activeGame = new Phaser.Game({
    type: Phaser.CANVAS,
    canvas,
    parent: canvas.parentElement ?? undefined,
    width: window.innerWidth,
    height: window.innerHeight,
    backgroundColor: '#14252d',
    scene: [],
    scale: { mode: Phaser.Scale.RESIZE, width: '100%', height: '100%' },
    render: { antialias: true, pixelArt: false, roundPixels: false },
    fps: { target: 60, smoothStep: true },
    disableContextMenu: true,
  })
  const game = activeGame
  const applyHighDpi = () => highDpi.resize()
  const dpiFrame = requestAnimationFrame(applyHighDpi)
  game.scale.on(Phaser.Scale.Events.RESIZE, applyHighDpi)
  game.events.once(Phaser.Core.Events.READY, applyHighDpi)
  const qualityTimer = options.mode === 'runner' ? window.setInterval(() => {
    if (game.loop.actualFps <= 0 || game.loop.actualFps >= 52) return
    const resolution = canvas.width / Math.max(1, canvas.clientWidth)
    if (resolution > 1.75) highDpi.setResolution(1.5)
    else if (resolution > 1.3) highDpi.setResolution(1.25)
    else if (resolution > 1.05) highDpi.setResolution(1)
  }, 600) : 0
  activeDpiCleanup = () => {
    cancelAnimationFrame(dpiFrame)
    window.clearInterval(qualityTimer)
    game.scale.off(Phaser.Scale.Events.RESIZE, applyHighDpi)
    game.events.off(Phaser.Core.Events.READY, applyHighDpi)
  }
  game.scene.add(options.mode === 'runner' ? 'runner' : 'rhythm', scene, true, data)

  return {
    jump: () => { if (scene instanceof RunnerScene) scene.jump() },
    setDuck: (value) => { if (scene instanceof RunnerScene) scene.setDuck(value) },
    setPaused: (value) => { scene.setPaused(value) },
    restart: () => { window.__GAME_READY__ = false; scene.scene.restart(data) },
    start: () => { if (scene instanceof RhythmScene) scene.start() },
    hitLane: (lane) => { if (scene instanceof RhythmScene) scene.hitLane(lane) },
    toggleMute: () => scene.toggleMute(),
  }
}

export function stopGame(): void {
  if (activeScene instanceof RhythmScene) activeScene.shutdown()
  document.getElementById('rhythm-debug-panel')?.remove()
  activeDpiCleanup?.()
  activeDpiCleanup = null
  if (activeGame) activeGame.destroy(true)
  activeGame = null
  activeScene = null
  delete window.__gameProbe
  delete window.__rhythmProbe
  window.__GAME_READY__ = false
}
