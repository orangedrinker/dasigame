import { storage } from './storage'
import { isBrief } from './edition'

const SAVE_KEY = isBrief ? 'qiushi.save.brief.v1' : 'qiushi.save.v1'
export type Checkpoint =
  | { kind: 'intro'; nodeId?: string }
  | { kind: 'runner'; level: number }
  | { kind: 'sprint'; level: number }
  | { kind: 'novel'; level: number; nodeId?: string }
  | { kind: 'rhythm' }
  | { kind: 'complete' }
export type SaveData = {
  version: 1; checkpoint: Checkpoint; endings: string[]; bestRhythm: number; bestCombo: number
  totalSeals: number; updatedAt: number; completedGame: boolean; unlockedLevel: number
  completedLevels: number[]; levelSeals: Record<number, number>
}
export const freshSave = (): SaveData => ({
  version: 1, checkpoint: { kind: 'intro' }, endings: [], bestRhythm: 0, bestCombo: 0,
  totalSeals: 0, updatedAt: Date.now(), completedGame: false, unlockedLevel: -1,
  completedLevels: [], levelSeals: {},
})
const validCheckpoint = (value: unknown): value is Checkpoint => {
  if (!value || typeof value !== 'object') return false
  const c = value as Checkpoint
  if (c.kind === 'intro' || c.kind === 'rhythm' || c.kind === 'complete') return true
  return (c.kind === 'runner' || c.kind === 'sprint' || c.kind === 'novel') && Number.isInteger(c.level) && c.level >= 0 && c.level <= 4
}
export function normalizeSave(value: unknown): SaveData {
  if (!value || typeof value !== 'object') return freshSave()
  const v = value as SaveData
  if (v.version !== 1 || !validCheckpoint(v.checkpoint)) return freshSave()
  const completedGame = v.completedGame === true || v.checkpoint.kind === 'complete'
  const checkpointLevel = 'level' in v.checkpoint ? v.checkpoint.level : v.checkpoint.kind === 'rhythm' ? 4 : -1
  const endings = Array.isArray(v.endings) ? v.endings.filter(x => typeof x === 'string') : []
  const unlockedLevel = completedGame ? 4 : Math.min(4, Math.max(-1, Number.isInteger(v.unlockedLevel) ? v.unlockedLevel : -1, checkpointLevel, endings.includes('main') ? 0 : -1))
  const count = (x: unknown) => typeof x === 'number' && Number.isFinite(x) ? Math.max(0, x) : 0
  const levelSeals: Record<number, number> = {}
  for (let i = 0; i < 5; i++) levelSeals[i] = count(v.levelSeals?.[i])
  return { ...freshSave(), checkpoint: v.checkpoint, endings: [...new Set(endings)],
    completedGame, unlockedLevel, levelSeals,
    completedLevels: completedGame ? [0, 1, 2, 3, 4] : Array.isArray(v.completedLevels) ? [...new Set(v.completedLevels.filter(x => Number.isInteger(x) && x >= 0 && x < 5))] : [],
    bestRhythm: count(v.bestRhythm), bestCombo: count(v.bestCombo), totalSeals: count(v.totalSeals), updatedAt: count(v.updatedAt),
  }
}
export const loadSave = (): SaveData => normalizeSave(storage.get<unknown>(SAVE_KEY, null))
export function writeSave(data: SaveData) { storage.set(SAVE_KEY, { ...data, updatedAt: Date.now() }) }
export function clearSave() { storage.remove(SAVE_KEY) }
