import { useCallback, useEffect, useState } from 'react'
import Archive from '@/components/Archive'
import ChapterSelect from '@/components/ChapterSelect'
import ChapterTask from '@/components/ChapterTask'
import Settings from '@/components/Settings'
import FinalScreen from '@/components/FinalScreen'
import GameView from '@/components/GameView'
import TitleScreen from '@/components/TitleScreen'
import VisualNovel from '@/components/VisualNovel'
import { type EndingId } from '@/game/content'
import { activeInterlude, activeIntro, activeLevel, editionName, nextRunnerLevel } from '@/game/edition'
import { completeChapter, completeJourney, recordSeals } from '@/game/progression'
import { clearSave, freshSave, loadSave, writeSave, type Checkpoint, type SaveData } from '@/game/save'
import type { GameEvent } from '@/game/types'
import '@/game/audio'

type Screen = Checkpoint | {kind:'title'} | {kind:'chapters'}
type RhythmResult = Extract<GameEvent,{type:'rhythm-result'}>
function readMuted(){try{return localStorage.getItem('game.muted')==='1'}catch{return false}}
export default function Home(){
 const [save,setSave]=useState<SaveData>(loadSave)
 const [screen,setScreen]=useState<Screen>({kind:'title'})
 const [archiveOpen,setArchiveOpen]=useState(false)
 const [settingsOpen,setSettingsOpen]=useState(false)
 const [muted,setMuted]=useState(readMuted)
 const [lastResult,setLastResult]=useState<RhythmResult|null>(null)
 useEffect(()=>{document.title=`求是 · 文军长征｜${editionName}`;const sync=()=>setMuted(readMuted());window.addEventListener('game-mute-change',sync);return()=>window.removeEventListener('game-mute-change',sync)},[])
 const update=useCallback((transform:(current:SaveData)=>SaveData)=>setSave(current=>{const next={...transform(current),updatedAt:Date.now()};writeSave(next);return next}),[])
 const go=useCallback((checkpoint:Checkpoint)=>{
  update(current=>({...current,checkpoint}));setScreen(checkpoint)
 },[update])
 const discoverEnding=useCallback((ending:EndingId)=>update(current=>({...current,endings:[...new Set([...current.endings,ending])]})),[update])
 const finishIntro=(ending?:EndingId)=>{
  if(ending==='main'){
   discoverEnding('main');update(current=>({...current,unlockedLevel:Math.max(0,current.unlockedLevel)}));go({kind:'runner',level:0})
  }else setScreen({kind:'title'})
 }
 const finishRunner=(level:number,_score:number,seals:number)=>{
  update(current=>recordSeals(current,level,seals))
  go({kind:'novel',level})
 }
 const finishNovel=(level:number)=>{
  const next=nextRunnerLevel(level)
  update(current=>completeChapter(current,level,next))
  go(next===null?{kind:'rhythm'}:{kind:'runner',level:next})
 }
 const finishRhythm=(result:RhythmResult)=>{
  setLastResult(result)
  update(current=>completeJourney(current,result.score,result.combo))
  setScreen({kind:'complete'})
 }
 const reset=()=>{clearSave();setSave(freshSave());setLastResult(null);setScreen({kind:'title'})}
 const toggleMute=()=>{const next=!muted;setMuted(next);try{localStorage.setItem('game.muted',next?'1':'0')}catch{}window.dispatchEvent(new CustomEvent('game-mute-change',{detail:next}))}
 const exit=()=>setScreen({kind:'title'})
 const chapters=()=>setScreen({kind:'chapters'})
 const archive=()=>setArchiveOpen(true)
 const settings=()=>setSettingsOpen(true)
 return <div id="game-root">
  {screen.kind==='title'&&<TitleScreen save={save} onStart={()=>go({kind:'intro'})} onContinue={()=>setScreen(save.checkpoint)} onArchive={archive} onReset={reset} muted={muted} onToggleMute={toggleMute} onChapters={chapters} onSettings={settings}/>}
  {screen.kind==='chapters'&&<ChapterSelect save={save} onSelect={go} onBack={exit}/>}
  {screen.kind==='intro'&&<VisualNovel key="intro" script={activeIntro} initialNodeId={screen.nodeId} onProgress={nodeId=>update(current=>({...current,checkpoint:{kind:'intro',nodeId}}))} onFinish={finishIntro} onDiscover={discoverEnding} onExit={exit} onArchive={archive} onSettings={settings} onChapters={chapters} suspended={archiveOpen||settingsOpen}/>}
  {screen.kind==='runner'&&<ChapterTask key={`task-${screen.level}`} level={screen.level} onComplete={()=>screen.level===0?go({kind:'sprint',level:0}):go({kind:'novel',level:screen.level})} onExit={exit} onArchive={archive} onSettings={settings} suspended={archiveOpen||settingsOpen}/>}
  {screen.kind==='sprint'&&<GameView key={`runner-${screen.level}`} mode="runner" level={activeLevel(screen.level)} levelIndex={screen.level} onComplete={(score,seals)=>finishRunner(screen.level,score,seals)} onRhythmFinish={()=>undefined} onExit={exit} onChapters={chapters} onSettings={settings} suspended={settingsOpen}/>}
  {screen.kind==='novel'&&<VisualNovel key={`novel-${screen.level}`} script={activeInterlude(screen.level)} initialNodeId={screen.nodeId} onProgress={nodeId=>update(current=>({...current,checkpoint:{kind:'novel',level:screen.level,nodeId}}))} onFinish={()=>finishNovel(screen.level)} onDiscover={discoverEnding} onExit={exit} onArchive={archive} onSettings={settings} onChapters={chapters} suspended={archiveOpen||settingsOpen}/>}
  {screen.kind==='rhythm'&&<GameView mode="rhythm" onComplete={()=>undefined} onRhythmFinish={finishRhythm} onExit={exit} onChapters={chapters} onSettings={settings} suspended={settingsOpen}/>}
  {screen.kind==='complete'&&<FinalScreen score={Math.max(save.bestRhythm,lastResult?.score??0)} combo={Math.max(save.bestCombo,lastResult?.combo??0)} onArchive={archive} onTitle={exit} onReplay={()=>go({kind:'rhythm'})} onChapters={chapters}/>}
  {archiveOpen&&<Archive onClose={()=>setArchiveOpen(false)}/>}
  {settingsOpen&&<Settings onClose={()=>setSettingsOpen(false)}/>}
 </div>
}
