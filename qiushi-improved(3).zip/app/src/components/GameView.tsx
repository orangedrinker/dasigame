import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowLeft, ArrowUp, Home, Music2, Pause, Play, RotateCcw, Volume2, VolumeX, X, Map, Settings2 } from 'lucide-react'
import { startGame, stopGame } from '@/game/boot'
import type { LevelConfig } from '@/game/content'
import type { GameEvent, GameHandle } from '@/game/types'
import { isBrief } from '@/game/edition'

type RhythmResult = Extract<GameEvent, { type: 'rhythm-result' }>

export default function GameView({ mode, level, levelIndex, onComplete, onRhythmFinish, onExit, onChapters, onSettings, suspended }: {
  mode: 'runner' | 'rhythm'
  level?: LevelConfig
  levelIndex?: number
  onComplete: (score: number, seals: number) => void
  onRhythmFinish: (result: RhythmResult) => void
  onExit: () => void
  onChapters: () => void
  onSettings: () => void
  suspended?: boolean
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const handleRef = useRef<GameHandle | null>(null)
  const callbackRef = useRef({ onComplete, onRhythmFinish })
  callbackRef.current = { onComplete, onRhythmFinish }
  const [status, setStatus] = useState<'ready' | 'playing' | 'paused' | 'gameover' | 'result'>(mode === 'rhythm' ? 'ready' : 'playing')
  const [muted, setMuted] = useState(() => {
    try { return localStorage.getItem('game.muted') === '1' } catch { return false }
  })
  const [result, setResult] = useState<RhythmResult | null>(null)

  useEffect(() => {
    if (!canvasRef.current) return
    let completionTimer = 0
    const handle = startGame(canvasRef.current, {
      mode,
      level,
      levelIndex,
      onEvent: (event) => {
        if (event.type === 'paused') setStatus(event.paused ? 'paused' : 'playing')
        if (event.type === 'reset') { setResult(null); setStatus('ready') }
        if (event.type === 'gameover') setStatus('gameover')
        if (event.type === 'complete') {
          setStatus('result')
          completionTimer = window.setTimeout(() => callbackRef.current.onComplete(event.score, event.seals), 650)
        }
        if (event.type === 'rhythm-result') {
          setResult(event)
          setStatus('result')
        }
      },
    })
    handleRef.current = handle
    return () => {
      window.clearTimeout(completionTimer)
      stopGame()
      handleRef.current = null
    }
  }, [mode, level, levelIndex])

  useEffect(() => { if (suspended) handleRef.current?.setPaused(true) }, [suspended])
  useEffect(() => {
    const pause = () => { if (document.hidden) handleRef.current?.setPaused(true) }
    document.addEventListener('visibilitychange', pause)
    return () => document.removeEventListener('visibilitychange', pause)
  }, [])
  const restart = () => {
    setResult(null)
    setStatus(mode === 'rhythm' ? 'ready' : 'playing')
    handleRef.current?.restart()
  }

  const rank = result ? (result.accuracy >= 96 ? 'S' : result.accuracy >= 90 ? 'A' : result.accuracy >= 80 ? 'B' : result.accuracy >= 65 ? 'C' : 'D') : ''

  return (
    <main className={`game-view ${mode}-view`}>
      <canvas id="game-canvas" ref={canvasRef} aria-label={mode === 'runner' ? '西迁跑酷游戏画布' : '浙江大学校歌音游画布'} />
      <div className="game-toolbar">
        <button className="icon-button dark" onClick={onChapters} aria-label="章节回溯"><Map size={18}/></button>
        <button className="icon-button dark" onClick={onSettings} aria-label="声音与阅读"><Settings2 size={18}/></button>
        {status === 'playing' && <button className="icon-button dark" onClick={() => handleRef.current?.setPaused(true)} aria-label="暂停"><Pause size={20} /></button>}
        <button className="icon-button dark" onClick={() => setMuted(handleRef.current?.toggleMute() ?? false)} aria-label={muted ? '开启声音' : '静音'}>{muted ? <VolumeX size={20} /> : <Volume2 size={20} />}</button>
      </div>

      {mode === 'runner' && status === 'playing' && (
        <div className="runner-controls">
          <button className="duck-button" onPointerDown={event => {event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);handleRef.current?.setDuck(true)}} onPointerUp={() => handleRef.current?.setDuck(false)} onPointerCancel={() => handleRef.current?.setDuck(false)} onPointerLeave={() => handleRef.current?.setDuck(false)}><ArrowDown size={25} /><span>下蹲</span></button>
          <button className="jump-button" onPointerDown={(event) => { event.preventDefault(); handleRef.current?.jump() }}><ArrowUp size={28} /><span>跳跃</span></button>
        </div>
      )}

      {mode === 'runner' && status === 'playing' && <div className="runner-start-hint"><span>护送书箱，向右前进</span><small>空格 / ↑ 连按两次可二段跳 · ↓ 下蹲</small></div>}

      {mode === 'rhythm' && status === 'playing' && (
        <div className="rhythm-touch" aria-label="触屏音符轨道">
          {['D', 'F', 'J', 'K'].map((key, lane) => <button key={key} onPointerDown={() => handleRef.current?.hitLane(lane)} aria-label={`轨道 ${key}`}>{key}</button>)}
        </div>
      )}

      {mode === 'rhythm' && status === 'ready' && (
        <div className="game-overlay">
          <section className="rhythm-intro">
            <span className="section-kicker">ZHEJIANG UNIVERSITY ANTHEM</span>
            <Music2 size={38} />
            <h1>大不自多</h1>
            <p>马一浮 词 · 应尚能 曲</p>
            <div className="rhythm-rules"><span>四轨点击</span><span>越接近判定线，评价越高</span><span>支持 D F J K 与触屏</span></div>
            <p className="synth-note">{isBrief ? '体验节选 · ' : ''}网易云音频 · 浙江大学文琴合唱团人声录音 · 依真实录音制谱</p>
            <button className="primary-button large" onClick={() => { handleRef.current?.start(); setStatus('playing') }}><Play size={20} fill="currentColor" /> 开始演奏</button>
            <button className="text-button" onClick={onExit}><ArrowLeft size={17} /> 返回封面</button>
          </section>
        </div>
      )}

      {status === 'paused' && (
        <div className="game-overlay"><section className="pause-card"><span>{mode === 'rhythm' ? '演奏暂歇' : '旅程暂歇'}</span><h2>暂停</h2><p>{mode === 'rhythm' ? '校歌会停在这一拍，直到你准备好继续。' : '日记会停在这一页，直到你准备好继续。'}</p><button className="primary-button" onClick={() => handleRef.current?.setPaused(false)}><Play size={18} /> {mode === 'rhythm' ? '继续演奏' : '继续前进'}</button><button className="secondary-button" onClick={restart}><RotateCcw size={18} /> {mode === 'rhythm' ? '重新开始演奏' : '重走本关'}</button><button className="text-button" onClick={onExit}><Home size={17} /> 保存并返回封面</button></section></div>
      )}

      {status === 'gameover' && (
        <div className="game-overlay"><section className="pause-card gameover-card"><span>书箱需要重新整理</span><h2>旅程中断</h2><p>观察陷阱节奏：地面障碍跳过去，低空炮火蹲下避开。</p><button className="primary-button" onClick={restart}><RotateCcw size={18} /> 从本关起点重试</button><button className="text-button" onClick={onExit}><Home size={17} /> 返回封面</button></section></div>
      )}

      {mode === 'rhythm' && status === 'result' && result && (
        <div className="game-overlay"><section className="result-card"><span className="section-kicker">演奏完成</span><div className="result-rank">{rank}</div><h2>大不自多，海纳江河</h2><div className="result-score">{String(result.score).padStart(7, '0')}</div><div className="result-grid"><div><strong>{result.accuracy.toFixed(1)}%</strong><span>准确率</span></div><div><strong>{result.combo}</strong><span>最大连击</span></div><div><strong>{result.perfect}</strong><span>PERFECT</span></div><div><strong>{result.miss}</strong><span>MISS</span></div></div><button className="primary-button" onClick={() => onRhythmFinish(result)}>完成旅程 <Play size={18} /></button><button className="secondary-button" onClick={restart}><RotateCcw size={17} /> 再演奏一次</button></section></div>
      )}

      <button className="game-exit-mobile" onClick={onExit} aria-label="退出到封面"><X size={18} /></button>
    </main>
  )
}
