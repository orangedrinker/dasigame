import { useEffect, useState } from 'react'
import { ArrowLeft, ArrowRight, BookOpen, Check, Lock } from 'lucide-react'
import { uiAudio } from '@/game/audio'
import { assetUrl } from '@/game/asset'
import { ENDINGS, LEVELS, type EndingId } from '@/game/content'
import type { Checkpoint, SaveData } from '@/game/save'
import { isBrief } from '@/game/edition'
const modes = ['物资装箱 · 护送跑酷', '西迁路线规划', '警报与掩护', '点亮七年课堂', '日记时间线']
const art = ['jiande', 'taihe', 'yishan', 'meitan', 'modern']
export default function ChapterSelect({ save, onSelect, onBack }: { save: SaveData; onSelect: (c: Checkpoint) => void; onBack: () => void }) {
  useEffect(() => { uiAudio.playMusic('lantern'); return () => uiAudio.stopMusic() }, [])
  const [tab, setTab] = useState<'chapters' | 'endings'>('chapters')
  return <main className="chapter-screen"><header className="chapter-header"><button className="icon-button dark" onClick={onBack} aria-label="返回封面"><ArrowLeft size={20}/></button><div><span className="section-kicker">PAGES OF THE JOURNEY</span><h1>重访来时路</h1></div><span className="chapter-status">{save.completedGame ? '全章节已解锁' : '通关后，可自由回到任意章节'}</span></header>
    <nav className="chapter-tabs"><button aria-pressed={tab === 'chapters'} onClick={() => setTab('chapters')}>章节回溯</button><button aria-pressed={tab === 'endings'} onClick={() => setTab('endings')}>结局收藏 · {save.endings.length}/{Object.keys(ENDINGS).length}</button></nav>
    {tab === 'chapters' ? <section className="chapter-grid"><article className="chapter-card prologue"><div className="chapter-card-content"><span>序章 · 1936—1937</span><h2>国难中的选择</h2><p>一册日记，一所大学的启程。</p><button className="secondary-button" onClick={() => onSelect({kind:'intro'})}><BookOpen size={16}/>重读序章</button></div></article>
      {LEVELS.map((level, i) => { if (isBrief && i !== 0 && i !== 4) return null
        const unlocked = save.completedGame || i <= save.unlockedLevel
        return <article className={`chapter-card ${unlocked ? '' : 'locked'}`} key={level.name} style={{backgroundImage:`linear-gradient(0deg,#0a2029 3%,#0a202926 100%),url("${assetUrl(`/art/${art[i]}.webp`)}")`}}><div className="chapter-card-content"><span>第 {String(i+1).padStart(2,'0')} 章 · {level.year} {save.completedLevels.includes(i) && <Check size={15}/>}</span><h2>{level.name.split(' · ')[1]}</h2><p>{modes[i]}</p><div className="chapter-card-actions"><button className="primary-button" disabled={!unlocked} onClick={() => onSelect({kind:'runner',level:i})}>{unlocked ? '重访本章' : <><Lock size={14}/>尚未抵达</>}{unlocked && <ArrowRight size={16}/>}</button>{unlocked && <button className="text-button" onClick={() => onSelect({kind:'novel',level:i})}>阅读日记</button>}<button className="text-button" disabled={!unlocked} onClick={() => onSelect({kind:'sprint',level:i})}>护送跑酷</button></div></div></article> })}
      <article className="chapter-card finale"><div className="chapter-card-content"><span>终章 · 今天</span><h2>大不自多</h2><p>把节拍交给后来者。</p><button className="secondary-button" disabled={!save.completedGame && save.checkpoint.kind !== 'rhythm'} onClick={() => onSelect({kind:'rhythm'})}>再奏校歌 <ArrowRight size={16}/></button></div></article></section>
      : <section className="ending-grid">{Object.entries(ENDINGS).map(([id,data]) => {const found = save.endings.includes(id as EndingId); return <article key={id} className={found ? 'found' : ''}><span>{found ? data.number : '尚未发现'}</span><h2>{found ? data.title : '未翻开的日记'}</h2><p>{found ? data.text : '重访不同章节，看看另一种选择会把故事带往何处。'}</p>{found && <button className="text-button" onClick={() => onSelect(id === 'main' || ['scholar','hangzhou','luggage','alone'].includes(id) ? {kind:'intro'} : {kind:'novel', level: id === 'stranded' ? 0 : id === 'family' ? 1 : ['embers','unsettled'].includes(id) ? 2 : id === 'silence' ? 3 : 4})}>回到所属章节 <ArrowRight size={15}/></button>}</article>})}</section>}
    <footer className="chapter-footnote">重访章节会更新继续位置；已解锁章节、结局收藏和最好成绩始终保留。</footer>
  </main>
}
