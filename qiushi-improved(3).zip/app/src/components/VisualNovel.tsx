import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, RotateCcw, BookOpen, Map, Settings2 } from 'lucide-react'
import { ENDINGS, type EndingId, type NovelScene, type NovelScript } from '@/game/content'
import { usePreferences } from '@/game/preferences'
import { storage } from '@/game/storage'
import { uiAudio, type MusicMood } from '@/game/audio'
import { assetUrl } from '@/game/asset'

/** 每种场景对应的音乐氛围。 */
const MOOD_BY_SCENE: Record<NovelScene, MusicMood> = {
  archive: 'archive',
  hangzhou: 'wartime',
  evacuation: 'wartime',
  jiande: 'wartime',
  taihe: 'lantern',
  family: 'sorrow',
  yishan: 'rain',
  shelter: 'alarm',
  meitan: 'lantern',
  modern: 'modern',
}

const SCENE_IMAGES: Record<NovelScene, string> = {
  archive: '/art/novel-archive.webp',
  hangzhou: '/art/novel-hangzhou.webp',
  evacuation: '/art/novel-evacuation.webp',
  jiande: '/art/jiande.webp',
  taihe: '/art/novel-taihe.webp',
  family: '/art/novel-family.webp',
  yishan: '/art/yishan.webp',
  shelter: '/art/novel-shelter.webp',
  meitan: '/art/novel-meitan.webp',
  modern: '/art/modern.webp',
}

function SceneArt({ scene }: { scene: NovelScene }) {
  return (
    <div className={`novel-art art-${scene}`} aria-hidden="true">
      <img key={scene} className="novel-scene-image" src={assetUrl(SCENE_IMAGES[scene])} alt="" decoding="async" />
      <div className="novel-scene-shade" />
      <div className="paper-grain" />
    </div>
  )
}

type Props = {
  script: NovelScript
  onFinish: (ending?: EndingId) => void
  onExit: () => void
  initialNodeId?: string
  onProgress?: (nodeId: string) => void
  onArchive: () => void
  onSettings: () => void
  onChapters: () => void
  suspended?: boolean
  onDiscover?: (ending: EndingId) => void
}

export default function VisualNovel({ script, onFinish, onExit, onDiscover, initialNodeId, onProgress, onArchive, onSettings, onChapters, suspended }: Props) {
  const [nodeId, setNodeId] = useState(script.nodes.some(n => n.id === initialNodeId) ? initialNodeId! : script.nodes[0].id)
  const prefs = usePreferences()
  const [history, setHistory] = useState<string[]>([])
  const progressRef = useRef(onProgress)
  progressRef.current = onProgress
  const [seen, setSeen] = useState<string[]>(() => {const value=storage.get<unknown>('read-nodes.v1', []);return Array.isArray(value)?value.filter(x=>typeof x==='string'):[]})
  useEffect(() => { progressRef.current?.(nodeId) }, [nodeId])
  const visit = useCallback((id: string) => { setHistory(current => [...current, nodeId]); setNodeId(id) }, [nodeId])
  const [visible, setVisible] = useState(0)
  const [ending, setEnding] = useState<EndingId | null>(null)
  const nodeIndex = script.nodes.findIndex((n) => n.id === nodeId)
  const node = script.nodes[nodeIndex] ?? script.nodes[0]
  const complete = visible >= node.text.length
  const shownText = useMemo(() => node.text.slice(0, visible), [node.text, visible])
  const moodRef = useRef<MusicMood | null>(null)

  // 场景氛围音乐：随当前节点的场景切换，离开小说时停止
  const sceneMood = MOOD_BY_SCENE[node.scene]
  useEffect(() => {
    if (moodRef.current !== sceneMood) {
      moodRef.current = sceneMood
      uiAudio.playMusic(sceneMood)
    }
  }, [sceneMood])
  useEffect(() => () => {
    moodRef.current = null
    uiAudio.stopMusic()
  }, [])

  useEffect(() => { setVisible(0) }, [nodeId])
  useEffect(() => {
    if (suspended) return
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduced || prefs.textSpeed === 0) {
      setVisible(node.text.length)
      return
    }
    const timer = window.setInterval(() => {
      setVisible(current => {
        if (current >= node.text.length) { window.clearInterval(timer); return current }
        return current + 1
      })
    }, prefs.textSpeed)
    return () => window.clearInterval(timer)
  }, [nodeId, node.text, prefs.textSpeed, suspended])
  useEffect(() => {
    if (!complete || seen.includes(node.id)) return
    const next = [...seen, node.id]
    setSeen(next); storage.set('read-nodes.v1', next)
  }, [complete, node.id, seen])

  /** 翻页声；跨场景时换成场景切换的风声。 */
  const pageSfx = useCallback((target: { scene: NovelScene } | undefined) => {
    uiAudio.sfx(target && target.scene !== node.scene ? 'scene' : 'page')
  }, [node.scene])

  const advance = useCallback(() => {
    if (ending || suspended) return
    if (!complete) {
      setVisible(node.text.length)
      return
    }
    if (node.choices) return
    const nextNode = node.next
      ? script.nodes.find((n) => n.id === node.next)
      : nodeIndex < script.nodes.length - 1 ? script.nodes[nodeIndex + 1] : undefined
    pageSfx(nextNode)
    if (nextNode) visit(nextNode.id)
    else onFinish()
  }, [complete, ending, node, nodeIndex, onFinish, pageSfx, script.nodes, visit, suspended])

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if ((event.code === 'Space' || event.code === 'Enter') && !event.repeat) {
        const target = event.target as HTMLElement
        if (target.closest('button, input, select, dialog') || suspended) return
        event.preventDefault()
        advance()
      }
      if (event.code === 'Escape' && !suspended) onExit()
    }
    window.addEventListener('keydown', listener)
    return () => window.removeEventListener('keydown', listener)
  }, [advance, onExit, suspended])

  const choose = (next?: string, selectedEnding?: EndingId) => {
    if (selectedEnding) {
      uiAudio.sfx('scene')
      setEnding(selectedEnding)
      onDiscover?.(selectedEnding)
    } else if (next) {
      pageSfx(script.nodes.find((n) => n.id === next))
      visit(next)
    }
  }

  if (ending) {
    const data = ENDINGS[ending]
    return (
      <main className={`ending-screen ending-${ending}`}>
        <SceneArt scene={data.scene} />
        <section className="ending-card" aria-labelledby="ending-title">
          <span className="section-kicker">{data.number} · {ending === 'main' ? '剧情演绎' : '非史实分支'}</span><h1 id="ending-title">{data.title}</h1>
          <p>{data.text}</p>
          <div className="ending-actions">
            {ending === 'main' ? (
              <button className="primary-button" onClick={() => onFinish('main')}>踏上西迁之路 <ArrowRight size={19} /></button>
            ) : (
              <button className="primary-button" onClick={() => { setEnding(null); setVisible(node.text.length) }}><RotateCcw size={18} /> 返回刚才的选择</button>
            )}
            <button className="text-button" onClick={onExit}><ArrowLeft size={18} /> 回到封面</button>
          </div>
        </section>
      </main>
    )
  }

  return (
    <main className="novel-screen" onClick={advance}>
      <SceneArt scene={node.scene} />
      <header className="novel-header">
        <button className="icon-button dark" onClick={(event) => { event.stopPropagation(); onExit() }} aria-label="返回封面"><ArrowLeft size={20} /></button>
        <div><span>{script.title}</span><strong>{node.date} · {node.place}</strong></div>
        <div className="novel-tools" onClick={e => e.stopPropagation()}><button className="icon-button dark" onClick={onArchive} aria-label="查看校史档案"><BookOpen size={17}/></button><button className="icon-button dark" onClick={onChapters} aria-label="章节回溯"><Map size={17}/></button><button className="icon-button dark" onClick={onSettings} aria-label="声音与阅读"><Settings2 size={17}/></button></div><span className="novel-progress">{String(nodeIndex + 1).padStart(2, '0')} / {String(script.nodes.length).padStart(2, '0')}</span>
      </header>

      <section className={`dialogue-panel ${node.quote ? 'is-quote' : ''}`} aria-label="剧情阅读">
        <div className="speaker-row">
          <span className="speaker-name">{node.speaker}</span>
          <span className="chapter-label">{node.chapter}</span><span className="history-badge">{node.quote ? '史料引文' : '剧情演绎 · 非日记原文'}</span>
        </div>
        <p className="dialogue-text" style={{fontSize:`clamp(16px, 3.8vw, ${prefs.fontSize}px)`}} aria-label={node.text}>{shownText}<span className={complete ? 'cursor hidden' : 'cursor'}>▍</span></p>
        {complete && node.choices && (
          <div className="novel-choices">
            {node.choices.map((choice) => (
              <button key={choice.label} onClick={(event) => { event.stopPropagation(); choose(choice.next, choice.ending) }}>
                <span>{choice.label}</span>{choice.detail && <small>{choice.detail}</small>}<ArrowRight size={18} />
              </button>
            ))}
          </div>
        )}
        {node.note && <small className="source-note">{node.note}</small>}
        <div className="reading-actions" onClick={e => e.stopPropagation()}>
          <button className="text-button" disabled={history.length === 0} onClick={() => {setNodeId(history[history.length-1]);setHistory(history.slice(0,-1))}}><ArrowLeft size={15}/>上一段</button>
          {!complete && <button className="text-button" onClick={() => setVisible(node.text.length)}>显示全文</button>}
          {complete && !node.choices && <button className="text-button" onClick={advance}>下一段 <ArrowRight size={16}/></button>}
          {!complete && seen.includes(node.id) && <span className="read-badge">已读</span>}
        </div>
      </section>
    </main>
  )
}
