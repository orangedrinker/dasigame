import { useEffect, useState } from 'react'
import { BookOpen, ChevronRight, Play, RotateCcw, Volume2, VolumeX, Map, Settings2 } from 'lucide-react'
import { uiAudio } from '@/game/audio'
import { ENDINGS, ROUTE } from '@/game/content'
import type { SaveData } from '@/game/save'
import { editionName, isBrief } from '@/game/edition'

function continueLabel(save: SaveData) {
  const c = save.checkpoint
  if (c.kind === 'runner' || c.kind === 'sprint') return c.level === 4 ? '继续 · 现代求是园' : `继续 · 第${c.level + 1}段西迁`
  if (c.kind === 'novel') return '继续 · 关间日记'
  if (c.kind === 'rhythm') return '继续 · 大不自多'
  if (c.kind === 'complete') return '回看 · 旅程终章'
  return '开始旅程'
}

export default function TitleScreen({ save, onStart, onContinue, onArchive, onReset, muted, onToggleMute, onChapters, onSettings }: {
  save: SaveData
  onStart: () => void
  onContinue: () => void
  onArchive: () => void
  onReset: () => void
  muted: boolean
  onToggleMute: () => void
  onChapters: () => void
  onSettings: () => void
}) {
  useEffect(() => { uiAudio.playMusic('archive'); return () => uiAudio.stopMusic() }, [])
  const [confirmReset, setConfirmReset] = useState(false)
  const hasProgress = save.checkpoint.kind !== 'intro'
  useEffect(() => {
    if (!confirmReset) return
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setConfirmReset(false) }
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [confirmReset])
  return (
    <main className="title-screen">
      <div className="title-map" aria-hidden="true">
        <svg viewBox="0 0 1000 700" preserveAspectRatio="xMidYMid slice">
          <path className="map-contour" d="M-30 520C150 390 270 550 420 420S650 260 790 380 1000 420 1100 280" />
          <path className="map-contour faint" d="M-50 570C160 450 290 610 450 480S690 330 820 450 1010 470 1100 350" />
          <path className="map-river" d="M0 140C210 230 250 80 430 170S690 280 1000 130" />
          <path className="map-route" d="M120 510C220 490 235 400 340 420S480 520 570 400 650 265 760 320 830 260 910 170" />
          {[[120,510],[340,420],[570,400],[720,295],[830,260],[910,170]].map(([x,y], i) => <g key={i} transform={`translate(${x} ${y})`}><circle r="10" /><circle r="3" className="route-core" /></g>)}
        </svg>
        <span className="map-label label-0">杭州</span><span className="map-label label-1">建德</span><span className="map-label label-2">泰和</span><span className="map-label label-3">宜山</span><span className="map-label label-4">湄潭</span>
      </div>
      <div className="title-grain" aria-hidden="true" />
      <header className="title-topbar">
        <div className="mini-brand"><span>求是</span><small>ZJU · 1897</small></div>
        <div className="title-tools">
          <button className="icon-button dark" onClick={onSettings} aria-label="声音与阅读"><Settings2 size={20}/></button>
          <button className="icon-button dark" onClick={onToggleMute} aria-label={muted ? '开启声音' : '静音'}>{muted ? <VolumeX size={20} /> : <Volume2 size={20} />}</button>
          <button className="archive-link" onClick={onArchive}><BookOpen size={18} /> 校史档案</button>
        </div>
      </header>

      <section className="title-content">
        <div className="title-era"><span>1937</span><i /><span>1940</span></div>
        <h1><span>求是</span><em>·</em><span>文军长征</span></h1>
        <p className="title-english">THE WESTWARD JOURNEY</p>
        <span className="title-edition">互动校史 · 序章 / 五章 / 校歌终章</span>
        <p className="title-description">从一册日记出发，护送书箱穿越烽火。<br />让八十余年前的课堂，在今天的歌声里重逢。</p>
        <div className="title-actions">
          {hasProgress && <button className="primary-button large" onClick={onContinue}><Play size={20} fill="currentColor" />{continueLabel(save)}<ChevronRight size={20} /></button>}
          <button className={hasProgress ? 'secondary-button large' : 'primary-button large'} onClick={onStart}><BookOpen size={19} />{hasProgress ? '从序章重新开始' : '翻开日记'}</button>
        </div>
        <button className="chapter-cover-link" onClick={onChapters}><Map size={17}/>章节回溯与结局收藏 <ChevronRight size={16}/></button>
        <p className="cover-modes">装箱 · 护送 · 改道 · 掩护 · 点灯 · 校歌</p>
      </section>

      <aside className="route-index" aria-label="西迁路线">
        <span className="route-index-title">文军长征 · 路线</span>
        <ol>{ROUTE.map((place, index) => <li key={place} className={save.checkpoint.kind === 'runner' && save.checkpoint.level + 1 === index ? 'current' : ''}><i>{String(index + 1).padStart(2, '0')}</i><span>{place}</span></li>)}</ol>
        <div className="ending-record"><span>已发现结局</span><strong>{Math.min(Object.keys(ENDINGS).length, save.endings.filter((id) => id in ENDINGS).length)} / {Object.keys(ENDINGS).length}</strong></div>
      </aside>

      <footer className="title-footer">
        <span>历史题材剧情演绎 · 引文与参考资料见校史档案</span>
        <button onClick={() => setConfirmReset(true)} disabled={!hasProgress && save.endings.length === 0}><RotateCcw size={14} /> 清除存档</button>
        <span>存档仅保留在此浏览器</span>
      </footer>

      {confirmReset && <div className="confirm-backdrop" role="dialog" aria-modal="true" aria-labelledby="reset-title" onMouseDown={(event) => { if (event.target === event.currentTarget) setConfirmReset(false) }}><div className="confirm-card"><h2 id="reset-title">清除这段旅程？</h2><p>关卡进度、已发现结局与音游最好成绩都会从此浏览器中移除。</p><div><button className="danger-button" onClick={() => { onReset(); setConfirmReset(false) }}>确认清除</button><button className="secondary-button" onClick={() => setConfirmReset(false)}>保留存档</button></div></div></div>}
    </main>
  )
}
