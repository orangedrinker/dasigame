import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, BookOpen, Check, RotateCcw, Settings2 } from 'lucide-react'
import { uiAudio } from '@/game/audio'
import { assetUrl } from '@/game/asset'
import { BASE, connectedTiles } from '@/game/classroom'
import { LEVELS } from '@/game/content'
const ITEMS = [
  { id:'books', name:'图书', weight:3, text:'让课程有据可循', icon:'册' },
  { id:'tools', name:'科学仪器', weight:3, text:'把实验带到下一站', icon:'仪' },
  { id:'medicine', name:'医药', weight:2, text:'照顾同行者', icon:'药' },
  { id:'water', name:'饮水', weight:2, text:'多备一段路的补给', icon:'水' },
  { id:'letter', name:'家书', weight:1, text:'留住牵挂与记忆', icon:'信' },
  { id:'coat', name:'御寒衣物', weight:2, text:'应对山路与夜寒', icon:'衣' },
]
const CONNECTIONS = [[1,2,3],[4],[4,5],[5],[6],[6],[]]
const STOPS = [
 { name:'建德 · 启程', cost:0, text:'书箱装妥，开始规划。' },
 { name:'铁路转运点', cost:2, text:'铁路运输省力，但前方线路中断。' },
 { name:'江边码头', cost:3, text:'借船转运，提前用油布包好书箱。' },
 { name:'山路接应点', cost:5, text:'绕行较远，补给消耗更大。' },
 { name:'断轨区段', cost:99, text:'已确认中断；此段暂不可通行。' },
 { name:'乡间接应站', cost:2, text:'接力转运，补给足够继续西行。' },
 { name:'吉安 · 泰和', cost:2, text:'人和书箱抵达，可以准备复课。' },
]
const DIARY = [
 { id:0, title:'离开杭州', text:'师生与图书仪器分批西迁。', date:'1937年11月' },
 { id:1, title:'借屋复课', text:'在吉安、泰和继续教学。', date:'1938年初' },
 { id:2, title:'校训确定', text:'宜山校务会议确定“求是”。', date:'1938年11月19日' },
 { id:3, title:'黔北灯火', text:'陆续迁抵遵义、湄潭。', date:'1939年底—1940年' },
 { id:4, title:'复员杭州', text:'西迁结束，回到杭州。', date:'1946年' },
]
export default function ChapterTask({ level, onComplete, onExit, onArchive, onSettings, suspended = false }: { suspended?:boolean; level:number; onComplete:()=>void; onExit:()=>void; onArchive:()=>void; onSettings:()=>void }) {
 const [selected,setSelected]=useState<string[]>([])
 const [path,setPath]=useState([0])
 const [turns,setTurns]=useState([1,2,3,1,2,1,3,2,1,3,2,1,2,1,3,2])
 const [order,setOrder]=useState([2,0,4,1,3])
 const [checked,setChecked]=useState(false)
 const [feedback,setFeedback]=useState('')
 const [done,setDone]=useState(false)
 const [running,setRunning]=useState(false)
 const [hidden,setHidden]=useState(document.hidden)
 useEffect(()=> {const sync=()=>setHidden(document.hidden);document.addEventListener('visibilitychange',sync);return ()=>document.removeEventListener('visibilitychange',sync)},[])
 const [elapsed,setElapsed]=useState(0)
 const [sheltered,setSheltered]=useState(false)
 const [health,setHealth]=useState(2)
 const [supplies,setSupplies]=useState(0)
 const shelteredRef=useRef(false); shelteredRef.current=sheltered
 const dealt=useRef(new Set<number>())
 const grabbed=useRef(new Set<number>())
 useEffect(()=> {uiAudio.playMusic(level===0?'archive':level===1?'wartime':level===2?'rain':level===3?'lantern':'modern'); return ()=>uiAudio.stopMusic()},[level])
 useEffect(()=> {
  if(!running || suspended || hidden)return
  const start=performance.now()-elapsed*1000
  const timer=window.setInterval(()=>{
   const t=Math.min(24,(performance.now()-start)/1000);setElapsed(t)
   const wave=Math.floor(t/12);const phase=t%12
   if(phase>=8&&!dealt.current.has(wave)) {dealt.current.add(wave); if(!shelteredRef.current){setHealth(h=>Math.max(0,h-1));setFeedback('这次撤离晚了一步。下一轮请在警报阶段进入掩护。');uiAudio.sfx('hit')}else {setFeedback('这一轮师生已安全掩护。等警报解除后再行动。');uiAudio.sfx('pickup')}}
   if(t>=24){setRunning(false);setDone(true);setFeedback('两轮警报已过，师生可以按序返回课堂。')}
  },100)
  return ()=>window.clearInterval(timer)
 // The interval uses refs for live cover state and a fixed start clock.
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[running,suspended,hidden])
 useEffect(()=> {
  if(health<=0){setRunning(false);setDone(false);setFeedback('先照顾同行者。请重新演练，听到警报就带队进入掩护。')}
 },[health])
 const weight=ITEMS.filter(i=>selected.includes(i.id)).reduce((n,i)=>n+i.weight,0)
 const cost=path.reduce((n,i)=>n+STOPS[i].cost,0)
 const circuit=connectedTiles(turns)
 const phase=elapsed%12<4?'clear':elapsed%12<8?'warning':'strike'
 const titles=['启程前，装好这一箱','断开的路，要怎样接起','警报之后，仍有课堂','让黔北的课堂亮起来','把散落的日记重新排好']
 const subtitles=['带走复课所需，也为同行者留下余地。','观察通行情报，用有限补给把书箱送到泰和。','先人后物。在警报间隙行动，及时带队掩护。','旋转接线，让左上角的灯火连到右下角的课堂。','沿着时间重新走一遍，看看这所大学如何继续。']
 const finish=()=>{uiAudio.sfx('win');setDone(true)}
 return <main className={`task-screen task-${level}`} style={{backgroundImage:`linear-gradient(90deg,#0d2229f5,#0d2229b8),url("${assetUrl(`/art/${['jiande','taihe','yishan','meitan','modern'][level]}.webp`)}")`}}>
  <header className="task-header"><button className="icon-button dark" onClick={onExit} aria-label="保存并返回封面"><ArrowLeft size={20}/></button><span>第 {level+1} 章 / 5 · {LEVELS[level].shortName}</span><div><button className="text-button" onClick={onArchive}><BookOpen size={17}/>校史</button><button className="icon-button dark" onClick={onSettings} aria-label="声音与阅读"><Settings2 size={18}/></button></div></header>
  <section className="task-body"><div className="task-introduction"><span className="section-kicker">{['PACK FOR THE JOURNEY','FIND A WAY FORWARD','SHELTER TOGETHER','KEEP THE LIGHT ALIVE','PIECE THE MEMORY TOGETHER'][level]}</span><h1>{titles[level]}</h1><p>{subtitles[level]}</p><span className="task-fiction">历史情境互动 · 任务规则与资源数值为玩法设计</span></div>
  {level===0&&<><div className="packing-summary"><span>行装容量</span><strong>{weight} / 11</strong><div className="capacity-track"><i style={{width:`${weight/11*100}%`}}/></div></div><div className="packing-grid">{ITEMS.map(item=><button key={item.id} className={selected.includes(item.id)?'selected':''} aria-pressed={selected.includes(item.id)} onClick={()=>{setFeedback('');setDone(false); if(selected.includes(item.id))setSelected(selected.filter(id=>id!==item.id));else if(weight+item.weight<=11)setSelected([...selected,item.id]);else setFeedback('容量不够了。可以先取下一件物品，再作安排。')}}><span className="item-stamp">{item.icon}</span><span><strong>{item.name}</strong><small>{item.text}</small></span><span className="item-weight">{item.weight} 格 {selected.includes(item.id)&&<Check size={15}/>}</span></button>)}</div><p className="task-instruction">任务：带上图书、科学仪器和医药。剩余空间由你安排，个人记忆同样值得珍惜。</p>{!done&&<button className="primary-button" onClick={()=>{if(['books','tools','medicine'].every(id=>selected.includes(id))){finish();setFeedback(selected.includes('letter')?'家书也放进了行装。带着牵挂，与书箱一起出发。':'复课所需和医药已齐备。这份行装将陪伴下一段旅程。')}else setFeedback('再核对一次：图书、科学仪器和医药都需要带上。')}}>核对装箱单 <Check size={17}/></button>}</>}
  {level===1&&<><div className="route-resource"><span>剩余补给 <strong>{9-cost} / 9</strong></span><span>目的地：吉安 · 泰和</span></div><ol className="route-path">{path.map((n,i)=><li key={i}><span>{STOPS[n].name}</span>{i<path.length-1&&<ArrowRight size={15}/>}</li>)}</ol><div className="route-options">{CONNECTIONS[path[path.length-1]].map(n=><button key={n} disabled={n===4||cost+STOPS[n].cost>9} onClick={()=>{setPath([...path,n]);setFeedback(STOPS[n].text);if(n===6)finish()}}><span>{n===4?'线路中断':'可通行'} · 消耗 {n===4?'—':STOPS[n].cost} 份补给</span><h2>{STOPS[n].name}</h2><p>{STOPS[n].text}</p>{cost+STOPS[n].cost>9&&n!==4?<small>补给不足，请返回上一站改道。</small>:<ArrowRight size={20}/>}</button>)}</div><div className="task-actions"><button className="secondary-button" disabled={path.length<2} onClick={()=>{setPath(path.slice(0,-1));setDone(false);setFeedback('已回到上一站，可以重新安排路线。')}}><ArrowLeft size={16}/>返回上一站</button><button className="text-button" onClick={()=>{setPath([0]);setDone(false);setFeedback('')}}><RotateCcw size={16}/>重新规划</button></div><p className="task-instruction">这是运输决策示意，节点和补给并非真实逐日行程。遇到断轨或补给不足时，可回退并改走水路接力。</p></>}
  {level===2&&<><div className={`shelter-stage phase-${phase}`}><div className="shelter-sky"><span>{!running&&!done?'先读规则，再开始':phase==='clear'?'警报解除 · 可行动':phase==='warning'?'警报响起 · 立即掩护':'空袭经过 · 留在掩护内'}</span><strong>{done?'平安复课':`${Math.max(0,Math.ceil((phase==='clear'?4:phase==='warning'?8:12)-elapsed%12))} 秒`}</strong></div><div className="shelter-scene"><div className={`school-group ${sheltered?'in-cover':''}`} aria-label={sheltered?'师生在掩护内':'师生在室外'}><i/><i/><i/></div><div className="shelter-roof"><span>临时掩护</span></div></div><div className="shelter-status"><span>同行灯火 {'◆'.repeat(health)}{'◇'.repeat(2-health)}</span><span>补给 {supplies} · {Math.min(2,Math.floor(elapsed/12))}/2 轮</span></div></div><div className="task-actions">{!running&&!done?<button className="primary-button" onClick={()=>{dealt.current.clear();grabbed.current.clear();setElapsed(0);setHealth(2);setSupplies(0);setSheltered(false);shelteredRef.current=false;setFeedback('');setRunning(true)}}>开始防空演练 <ArrowRight size={17}/></button>:!done&&<><button className="primary-button" disabled={sheltered} onClick={()=>{setSheltered(true);setFeedback('师生已进入掩护。请等待警报解除。')}}>带队进入掩护</button><button className="secondary-button" disabled={phase!=='clear'} onClick={()=>{setSheltered(false);const wave=Math.floor(elapsed/12);if(!grabbed.current.has(wave)){grabbed.current.add(wave);setSupplies(s=>s+1);uiAudio.sfx('pickup');setFeedback('取回了一份补给。留意警报，及时返回。')}else setFeedback('这一轮补给已取回，准备带队掩护。')}}>出掩护取补给</button></>}</div><p className="task-instruction">每轮：4 秒行动 → 4 秒警报 → 4 秒掩护。共两轮。补给可选，师生安全优先；切换页面或打开档案、设置时自动暂停。</p></>}
  {level===3&&<><div className="circuit-label"><span>油灯 → 左上角</span><span>{circuit.solved?'课堂已点亮':'连接灯火'} → 右下角</span></div><div className="circuit-grid">{turns.map((t,i)=><button key={i} className={`${circuit.found.has(i)?'powered':''} ${i===15?'destination':''}`} aria-label={`接线 ${Math.floor(i/4)+1} 行 ${i%4+1} 列，旋转`} onClick={()=>{const next=turns.map((x,j)=>i===j?(x+1)%4:x);setTurns(next);const solved=connectedTiles(next).solved;setDone(solved);if(solved){uiAudio.sfx('win');setFeedback('灯亮了。陋室也可以安放一张认真求学的课桌。')}}}><svg viewBox="0 0 100 100" aria-hidden="true"><g transform={`rotate(${t*90} 50 50)`}>{BASE[i].map(d=><line key={d} x1="50" y1="50" x2={[50,100,50,0][d]} y2={[0,50,100,50][d]}/>)}</g><circle cx="50" cy="50" r="9"/></svg>{i===0&&<span>灯</span>}{i===15&&<span>课</span>}</button>)}</div><p className="task-instruction">点按接线块，每次顺时针旋转 90°。金色表示已接通；让光从左上角进入，从右下角右侧通向课堂。接线是坚持办学的象征性谜题。</p><button className="text-button" onClick={()=>{setFeedback('提示：从左上角向右，再沿第二列向下，沿底行向右连接。每块接线的开口必须相对。')}}>查看接线提示</button></>}
  {level===4&&<><ol className="diary-sort">{order.map((id,i)=><li key={id}><span className="diary-number">{String(i+1).padStart(2,'0')}</span><div><strong>{DIARY[id].title}</strong><p>{DIARY[id].text}</p>{checked&&<small>{DIARY[id].date}</small>}</div><div className="sort-actions"><button className="icon-button dark" disabled={i===0} aria-label={`上移${DIARY[id].title}`} onClick={()=>{const next=[...order];[next[i-1],next[i]]=[next[i],next[i-1]];setOrder(next);setDone(false);setChecked(false)}}><ArrowUp size={16}/></button><button className="icon-button dark" disabled={i===4} aria-label={`下移${DIARY[id].title}`} onClick={()=>{const next=[...order];[next[i+1],next[i]]=[next[i],next[i+1]];setOrder(next);setDone(false);setChecked(false)}}><ArrowDown size={16}/></button></div></li>)}</ol>{!done&&<button className="primary-button" onClick={()=>{setChecked(true);if(order.every((id,i)=>id===i)){finish();setFeedback('日记归位。从西迁到复员，课堂始终没有停下。')}else setFeedback('还有几页次序不同。已展开日期提示，可以继续调整。')}}>核对时间线 <Check size={17}/></button>}</>}
  <div role="status" className={`task-feedback ${done?'success':''}`}>{feedback&&<>{done&&<Check size={18}/>}<span>{feedback}</span></>}</div>
  {done&&<button className="primary-button large task-continue" onClick={onComplete}>{level===0?'开始护送跑酷':'翻开本章日记'} <ArrowRight size={19}/></button>}
  </section><footer className="task-footer">一章，一种守护的方式。<button className="text-button" onClick={onExit}>保存并返回封面</button></footer>
 </main>
}
