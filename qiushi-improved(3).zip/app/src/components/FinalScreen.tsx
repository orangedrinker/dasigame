import { useEffect, useState } from 'react'
import { BookOpen, Check, Home, Music2, RotateCcw, Share2, Map } from 'lucide-react'
import { uiAudio } from '@/game/audio'
import { isBrief } from '@/game/edition'

export default function FinalScreen({ score, combo, onArchive, onTitle, onReplay, onChapters }: {
  score: number
  combo: number
  onArchive: () => void
  onTitle: () => void
  onReplay: () => void
  onChapters: () => void
}) {
  useEffect(() => { uiAudio.playMusic('modern'); return () => uiAudio.stopMusic() }, [])
  const [shared, setShared] = useState(false)
  const share = async () => {
    const data = { title: '求是 · 文军长征', text: '从一册日记出发，走完浙江大学西迁之旅。', url: window.location.href }
    try {
      if (navigator.share) await navigator.share(data)
      else await navigator.clipboard.writeText(`${data.text} ${data.url}`)
      setShared(true)
      window.setTimeout(() => setShared(false), 2200)
    } catch { /* 用户取消系统分享时保留当前页面 */ }
  }
  return (
    <main className="final-screen">
      <div className="final-rings" aria-hidden="true"><i /><i /><i /></div>
      <section className="final-content">
        <span className="section-kicker">旅程完成 · THE JOURNEY CONTINUES</span>
        <div className="final-seal">求<br />是</div>
        <h1>大不自多<br /><span>海纳江河</span></h1>
        <p>从1937年的书箱，到今天的校歌。<br />你接住的不是一段远去的往事，而是仍在被回答的两个问题。</p>
        <blockquote>“到浙大来做什么？<br />将来毕业后要做什么样的人？”</blockquote>
        <div className="final-stats"><div><span>最佳演奏</span><strong>{String(score).padStart(7, '0')}</strong></div><div><span>最大连击</span><strong>{combo}</strong></div></div>
        <p className="unlock-notice"><Check size={16}/> 全章节已解锁，可随时重访任意一章</p><div className="final-actions"><button className="primary-button" onClick={onChapters}><Map size={18}/> 章节回溯</button><button className="primary-button" onClick={onTitle}><Home size={18} /> 回到封面</button><button className="secondary-button" onClick={onReplay}><Music2 size={18} /> 再奏校歌</button>{!isBrief && <button className="secondary-button" onClick={share}>{shared ? <Check size={18} /> : <Share2 size={18} />}{shared ? '链接已复制' : '分享旅程'}</button>}<button className="text-button" onClick={onArchive}><BookOpen size={17} /> 查阅校史档案</button></div>
      </section>
      <footer>历史会翻页，求是没有终章。<RotateCcw size={14} /></footer>
    </main>
  )
}
