import { useEffect, useRef } from 'react'
import { X } from 'lucide-react'
import { setPreferences, usePreferences } from '@/game/preferences'
export default function Settings({ onClose }: { onClose: () => void }) {
  const prefs = usePreferences()
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => { ref.current?.showModal() }, [])
  return <dialog ref={ref} className="settings-dialog" onCancel={onClose} onClick={e => { if (e.target === e.currentTarget) onClose() }} aria-labelledby="settings-title">
    <header><div><span className="section-kicker">MAKE YOURSELF AT HOME</span><h2 id="settings-title">声音与阅读</h2></div><button className="icon-button" onClick={onClose} aria-label="关闭设置"><X size={20}/></button></header>
    <p>调低音量，慢慢读完这一页。</p>
    <label>背景音乐 <output>{Math.round(prefs.music * 100)}%</output><input aria-label="背景音乐音量" type="range" min="0" max="1" step=".05" value={prefs.music} onChange={e => setPreferences({ ...prefs, music: +e.target.value })}/></label>
    <label>动作与界面音效 <output>{Math.round(prefs.effects * 100)}%</output><input aria-label="音效音量" type="range" min="0" max="1" step=".05" value={prefs.effects} onChange={e => setPreferences({ ...prefs, effects: +e.target.value })}/></label>
    <label>文字显示<select aria-label="文字显示速度" value={prefs.textSpeed} onChange={e => setPreferences({ ...prefs, textSpeed: +e.target.value })}><option value="0">立即显示全文</option><option value="15">快速</option><option value="27">标准</option><option value="50">慢速</option></select></label>
    <label>阅读字号 <output>{prefs.fontSize}px</output><input aria-label="阅读字号" type="range" min="16" max="26" step="1" value={prefs.fontSize} onChange={e => setPreferences({ ...prefs, fontSize: +e.target.value })}/></label>
    <small>设置和旅程进度保存在当前浏览器。</small><button className="primary-button" onClick={onClose}>保存并返回</button>
  </dialog>
}
