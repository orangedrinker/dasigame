import { useEffect, useState } from 'react'
import { ArrowUpRight, BookOpen, CalendarDays, CloudSun, Music2, UserRound, X } from 'lucide-react'
import { SOURCES } from '@/game/content'

const tabs = [
  { id: 'route', label: '西迁路线', icon: CalendarDays },
  { id: 'zhu', label: '竺可桢', icon: UserRound },
  { id: 'diary', label: '日记', icon: CloudSun },
  { id: 'anthem', label: '校歌', icon: Music2 },
] as const

type Tab = (typeof tabs)[number]['id']

export default function Archive({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('route')
  useEffect(() => {
    const listener = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }
    window.addEventListener('keydown', listener)
    return () => window.removeEventListener('keydown', listener)
  }, [onClose])

  return (
    <div className="archive-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}>
      <section className="archive-modal" role="dialog" aria-modal="true" aria-labelledby="archive-title">
        <header className="archive-header">
          <div><span className="section-kicker">ZHEJIANG UNIVERSITY ARCHIVES</span><h2 id="archive-title"><BookOpen size={26} /> 校史档案</h2></div>
          <button className="icon-button" onClick={onClose} aria-label="关闭校史档案"><X size={22} /></button>
        </header>
        <nav className="archive-tabs" aria-label="档案分类">
          {tabs.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}><Icon size={17} />{label}</button>)}
        </nav>
        <div className="archive-content">
          {tab === 'route' && (
            <div className="archive-article">
              <p className="archive-lead">一所大学在战火中迁徙，也在每一站重新开课。游戏主线依此顺序展开，原创人物与对白为剧情演绎。</p>
              <ol className="history-timeline">
                <li><time>1937年9月</time><div><strong>天目山</strong><p>一年级新生迁至西天目禅源寺上课，导师制由此发端。</p></div></li>
                <li><time>1937年11月</time><div><strong>杭州 → 建德</strong><p>师生分批撤离，图书仪器由汽车与船只转运；抵达后即分散借屋复课。</p></div></li>
                <li><time>1937年12月—1938年</time><div><strong>吉安 · 泰和</strong><p>沿浙赣线西行，借白鹭洲与上田村办学，并参与修堤、垦殖和当地教育。</p></div></li>
                <li><time>1938年8月—1939年</time><div><strong>广西宜山</strong><p>正式开学后仍面对疟疾与空袭。1938年11月19日，“求是”被确定为校训。</p></div></li>
                <li><time>1939年12月—1940年</time><div><strong>遵义 · 湄潭</strong><p>先在遵义临时开课，随后陆续迁抵湄潭，在黔北坚持办学七年。</p></div></li>
                <li><time>1946年</time><div><strong>复员杭州</strong><p>西迁历程结束。路程、日记与课堂，共同构成“文军长征”的历史记忆。</p></div></li>
              </ol>
            </div>
          )}
          {tab === 'zhu' && (
            <div className="archive-article two-column-article">
              <div className="zhu-portrait" aria-hidden="true"><span>竺</span><small>1890—1974</small></div>
              <div>
                <h3>科学家、教育家与“问天”者</h3>
                <p>竺可桢，字藕舫，浙江绍兴人，是我国近代地理学与气象学的奠基者之一。1918年获哈佛大学博士学位，1936至1949年任国立浙江大学校长。</p>
                <p>抗战全面爆发后，他带领师生举校西迁。迁校不是单纯转移地点：勘察校舍、安排交通、保护图书仪器、尽快复课，构成了他的日常。</p>
                <blockquote>“第一，到浙大来做什么？第二，将来毕业后要做什么样的人？”</blockquote>
                <p>1938年11月19日，在他的倡议下，校务会议确定“求是”为校训。其后他多次从科学精神、奋斗精神与牺牲精神等层面阐释“求是”。</p>
              </div>
            </div>
          )}
          {tab === 'diary' && (
            <div className="archive-article">
              <div className="diary-page">
                <span>1938年11月19日 · 宜山</span>
                <blockquote>“决定校训为‘求是’两字，校歌请马一浮制。”</blockquote>
                <small>浙江大学公开校史资料所载日记原文</small>
              </div>
              <h3>一册日记，也是一部社会史</h3>
              <p>现存竺可桢日记从1936年持续到1974年2月6日，约一千万字。气象与物候只是其中一部分，更多内容涉及工作、生活、师友往来和考察见闻。</p>
              <p>日记中的细小事项——风向、温度、车次、住处与书箱——让宏大的迁徙重新落到具体日常。游戏以此为叙事线索，但除明确标注的引文外，人物对白均为创作。</p>
            </div>
          )}
          {tab === 'anthem' && (
            <div className="archive-article anthem-article">
              <div>
                <h3>《大不自多》</h3>
                <p>1938年11月19日，校务会议决定请马一浮撰写校歌歌词，后由应尚能谱曲。歌词采用文言，围绕求真、会通与创新展开。</p>
                <p>游戏终章沿用项目原有的文琴合唱团校歌录音及对应谱面；新增章节背景音乐为原创合成器乐。录音来源及权属说明见项目 CREDITS.md。</p>
              </div>
              <blockquote className="anthem-lyrics">大不自多　海纳江河<br />惟学无际　际于天地<br />形上谓道兮　形下谓器<br />礼主别异兮　乐主和同<br />知其不二兮　尔听斯聪<br /><br />国有成均　在浙之滨<br />昔言求是　实启尔求真<br />习坎示教　始见经纶<br />无曰已是　无曰遂真</blockquote>
            </div>
          )}
          <footer className="source-list">
            <h3>参考资料</h3>
            <div>{SOURCES.map((source) => <a key={source.url} href={source.url} target="_blank" rel="noreferrer"><span><strong>{source.title}</strong><small>{source.publisher}</small></span><ArrowUpRight size={18} /></a>)}</div>
          </footer>
        </div>
      </section>
    </div>
  )
}
