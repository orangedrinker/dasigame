import { Routes, Route } from 'react-router'
import Home from './pages/Home'

/** The whole game lives on one screen, so any URL renders it: that keeps the standalone
 *  single-file build working when it is opened from a phone's local file (file://…/x.html)
 *  and keeps static hosting under a sub-path from showing a blank page. */
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="*" element={<Home />} />
    </Routes>
  )
}
