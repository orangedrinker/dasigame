import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { buildAnthem } from '../src/game/anthem'
import originalChart from '../src/game/anthem-chart.json'
import phraseData from '../src/game/anthem-phrases.json'
import confirmedPhrases from './fixtures/confirmed-lyrics.json'
import { activePhraseIndex, chartVocalOrigin, introOffset, recordingTime, vocalTime } from '../src/game/anthem-timing'

const close = (actual: number, expected: number) => assert.ok(Math.abs(actual - expected) < 1e-9, `${actual} != ${expected}`)

describe('recording and vocal timeline', () => {
  it('places time zero at the audible first vocal, including output latency', () => {
    close(vocalTime(10 + .075 + introOffset, 10, .075), 0)
    close(recordingTime(vocalTime(10 + .075, 10, .075)), 0)
  })
  it('preserves the actual countdown and playable negative prelude times', () => {
    close(recordingTime(vocalTime(7.5, 10, .075)), -2.575)
    const introNote = buildAnthem().notes[0]
    assert.ok(introNote.time < 0)
    close(introNote.time, originalChart.notes[0].time - chartVocalOrigin)
    assert.ok(recordingTime(introNote.time) > 0)
    close(recordingTime(introNote.time), 9.021)
  })
  it('normalizes note and lyric anchors once, retaining relative spacing', () => {
    const song = buildAnthem()
    assert.ok(Math.abs(song.lyrics[0].time) <= .05)
    close(song.notes[1].time, originalChart.notes[1].time - chartVocalOrigin)
    for (let i = 0; i < song.notes.length; i++) {
      close(song.notes[i].time, originalChart.notes[i].time - chartVocalOrigin)
    }
    const alignedChars = phraseData.flatMap((phrase) => phrase.chars)
    for (let i = 0; i < song.lyrics.length; i++) close(song.lyrics[i].time, alignedChars[i].start - introOffset)
    close(recordingTime(song.lyrics[0].time), phraseData[0].chars[0].start)
  })
  it('ends at the unchanged recording duration with all lyrics reachable', () => {
    const song = buildAnthem()
    close(recordingTime(song.duration), originalChart.duration)
    assert.ok(song.lyrics.every((entry) => entry.time < song.duration))
    assert.ok(song.notes.every((note) => note.time < song.duration))
  })
  it('advances the chart by elapsed audio time without accumulating frame drift', () => {
    const before = vocalTime(30, 4, .04)
    const after = vocalTime(30.7, 4, .04)
    close(after - before, .7)
    close(vocalTime(30.7, 4, .04), after) // a suspended context keeps all targets frozen
  })
  it('shows phrases only during their start-inclusive, end-exclusive intervals', () => {
    const phrases = [{ start: 28.4, end: 31.7 }, { start: 40, end: 44.2 }]
    assert.equal(activePhraseIndex(phrases, 28.399), -1)
    assert.equal(activePhraseIndex(phrases, 28.4), 0)
    assert.equal(activePhraseIndex(phrases, 31.699), 0)
    assert.equal(activePhraseIndex(phrases, 31.7), -1)
    assert.equal(activePhraseIndex(phrases, 39.999), -1)
    assert.equal(activePhraseIndex(phrases, 40), 1)
    assert.equal(activePhraseIndex(phrases, 44.2), -1)
  })
  it('keeps aligned phrase text, characters and intervals consistent', () => {
    for (let i = 0; i < phraseData.length; i++) {
      const phrase = phraseData[i]
      assert.ok(phrase.start < phrase.end)
      if (i) assert.ok(phrase.start >= phraseData[i - 1].end)
      assert.equal(phrase.chars.map((entry) => entry.char).join(''), phrase.text)
      for (const entry of phrase.chars) assert.ok(entry.start >= phrase.start && entry.start < entry.end && entry.end <= phrase.end)
      assert.equal(activePhraseIndex(phraseData, phrase.start), i)
      assert.notEqual(activePhraseIndex(phraseData, phrase.end), i)
      close(phrase.start * 10, Math.round(phrase.start * 10))
      close(phrase.end * 10, Math.round(phrase.end * 10))
    }
  })
  it('includes every user-confirmed phrase and repeated final refrain', () => {
    assert.deepEqual(phraseData.map((phrase) => phrase.text), confirmedPhrases)
    assert.equal(phraseData.length, 37)
    assert.equal(phraseData.flatMap((phrase) => phrase.chars).length, 153)
    assert.deepEqual(phraseData.slice(-2).map((phrase) => phrase.text), ['天下来同', '天下来同'])
  })
  it('places each sung note at its actual aligned character attack', () => {
    const song = buildAnthem()
    const vocalNotes = song.notes.filter((note) => note.vocal)
    const chars = phraseData.flatMap((phrase) => phrase.chars)
    assert.equal(vocalNotes.length, chars.length)
    assert.equal(song.notes.filter((note) => !note.vocal).length, 1)
    close(chartVocalOrigin, introOffset)
    for (let i = 0; i < chars.length; i++) {
      close(recordingTime(vocalNotes[i].time), chars[i].start)
      assert.equal(vocalNotes[i].lyric, chars[i].char)
    }
    assert.equal(vocalNotes.filter((note) => note.chord).length, phraseData.length)
  })
})
