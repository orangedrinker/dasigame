import { describe, it } from 'node:test'
import assert from 'node:assert/strict'
import { freshSave, normalizeSave } from '../src/game/save'
import { completeChapter, completeJourney, recordSeals } from '../src/game/progression'
import { connectedTiles } from '../src/game/classroom'
describe('persistent journey progress',()=>{
 it('migrates an old completed save into permanently unlocked chapters',()=>{
  const v=normalizeSave({version:1,checkpoint:{kind:'complete'},endings:['main'],bestRhythm:99})
  assert.equal(v.completedGame,true);assert.equal(v.unlockedLevel,4);assert.equal(v.bestRhythm,99);assert.deepEqual(v.completedLevels,[0,1,2,3,4])
 })
 it('recovers the unlocked chapter from an old checkpoint',()=>{
  assert.equal(normalizeSave({version:1,checkpoint:{kind:'novel',level:3}}).unlockedLevel,3)
 })
 it('does not unlock chapters on a new save',()=>{assert.equal(normalizeSave(null).unlockedLevel,-1)})
 it('rejects corrupt or invalid checkpoint levels',()=>{
  for(const level of [-1,5,1.5,'2'])assert.deepEqual(normalizeSave({version:1,checkpoint:{kind:'runner',level}}).checkpoint,{kind:'intro'})
 })
 it('supports a runner checkpoint after packing',()=>{
  assert.deepEqual(normalizeSave({...freshSave(),checkpoint:{kind:'sprint',level:0}}).checkpoint,{kind:'sprint',level:0})
 })
 it('preserves full access when replaying and reloading an earlier chapter',()=>{
  const done=completeJourney(freshSave(),1000,50)
  const replay=normalizeSave(JSON.parse(JSON.stringify(completeChapter({...done,checkpoint:{kind:'runner',level:0}},0,1))))
  assert.equal(replay.completedGame,true);assert.equal(replay.unlockedLevel,4);assert.equal(replay.bestRhythm,1000);assert.equal(replay.bestCombo,50)
 })
 it('keeps the best performance after a weaker replay',()=>{
  const v=completeJourney(completeJourney(freshSave(),1000,50),200,8)
  assert.equal(v.bestRhythm,1000);assert.equal(v.bestCombo,50)
 })
 it('does not farm collection totals by replaying a stage',()=>{
  const first=recordSeals(freshSave(),0,5);const second=recordSeals(first,0,3)
  assert.equal(second.totalSeals,5);assert.equal(recordSeals(second,0,7).totalSeals,7);assert.equal(recordSeals(second,1,4).totalSeals,9)
 })
 it('sanitizes malformed legacy statistics without discarding the checkpoint',()=>{
  const v=normalizeSave({...freshSave(),checkpoint:{kind:'rhythm'},endings:['main','main',null],bestRhythm:Infinity,bestCombo:-1,levelSeals:{0:-4}})
  assert.equal(v.bestRhythm,0);assert.equal(v.bestCombo,0);assert.deepEqual(v.endings,['main']);assert.equal(v.unlockedLevel,4);assert.equal(v.levelSeals[0],0)
 })
})
describe('classroom puzzle',()=>{
 it('starts unsolved',()=>{assert.equal(connectedTiles([1,2,3,1,2,1,3,2,1,3,2,1,2,1,3,2]).solved,false)})
 it('has a valid continuous path from the lamp to the classroom',()=>{
  const turns=Array(16).fill(0);turns[1]=1;turns[13]=1;assert.equal(connectedTiles(turns).solved,true)
 })
 it('does not complete when the source or destination is disconnected',()=>{
  const turns=Array(16).fill(0);turns[1]=1;turns[13]=1;turns[15]=1
  assert.equal(connectedTiles(turns).solved,false)
  turns[15]=0;turns[0]=1;assert.equal(connectedTiles(turns).found.size,0)
 })
})
